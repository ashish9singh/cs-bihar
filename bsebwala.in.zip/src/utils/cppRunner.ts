import { cppProgramPresets } from '../data/cppPrograms';

export interface CppRunResult {
  success: boolean;
  output: string;
  errorsHindi: string[];
  warningsHindi: string[];
  executionTimeMs: number;
}

export function validateAndRunCpp(code: string, userInput: string = ''): CppRunResult {
  const startTime = performance.now();
  const errorsHindi: string[] = [];
  const warningsHindi: string[] = [];

  const cleanCode = code.trim();

  // 1. Basic C++ Syntax Checks
  if (!cleanCode.includes('#include')) {
    errorsHindi.push('हेडर फ़ाइल अनुपस्थित: C++ प्रोग्राम में सबसे ऊपर `#include <iostream>` होना अनिवार्य है।');
  }

  if (!cleanCode.includes('main(') && !cleanCode.includes('main ()')) {
    errorsHindi.push('main() फ़ंक्शन नहीं मिला: C++ प्रोग्राम का निष्पादन हमेशा `int main()` से प्रारंभ होता है।');
  }

  // Count braces
  const openBraces = (cleanCode.match(/\{/g) || []).length;
  const closeBraces = (cleanCode.match(/\}/g) || []).length;
  if (openBraces !== closeBraces) {
    errorsHindi.push(`कोष्ठक (Braces) असंतुलित हैं: प्रोग्राम में ${openBraces} '{' और ${closeBraces} '}' हैं। सभी खुले कोष्ठकों को बंद करना आवश्यक है।`);
  }

  // Semicolon check on simple lines
  const lines = cleanCode.split('\n');
  lines.forEach((line, index) => {
    const trimmed = line.trim();
    if (
      trimmed &&
      !trimmed.startsWith('//') &&
      !trimmed.startsWith('/*') &&
      !trimmed.startsWith('*') &&
      !trimmed.startsWith('#') &&
      !trimmed.endsWith('{') &&
      !trimmed.endsWith('}') &&
      !trimmed.endsWith(':') &&
      !trimmed.startsWith('if') &&
      !trimmed.startsWith('for') &&
      !trimmed.startsWith('while') &&
      !trimmed.startsWith('else') &&
      !trimmed.endsWith(';')
    ) {
      if (trimmed.includes('cout') || trimmed.includes('cin') || trimmed.includes('return') || trimmed.includes('=')) {
        errorsHindi.push(`पंक्ति ${index + 1}: सेमीकोलन (;) छूटा हुआ प्रतीत होता है -> "${trimmed}"`);
      }
    }

    // Check single = in if statement
    if (trimmed.match(/if\s*\([^=!<>]=[^=]/)) {
      warningsHindi.push(`पंक्ति ${index + 1}: 'if' में '=' का प्रयोग हुआ है। मान की तुलना के लिए '==' का उपयोग करें।`);
    }
  });

  if (errorsHindi.length > 0) {
    return {
      success: false,
      output: `[कंपाइलर एरर / Compilation Error]\n${errorsHindi.join('\n')}`,
      errorsHindi,
      warningsHindi,
      executionTimeMs: Math.round(performance.now() - startTime),
    };
  }

  // 2. Program Execution Simulation
  // Check if it matches one of our 10 official presets
  const matchedPreset = cppProgramPresets.find((p) => {
    // Normalise whitespace
    const normCode = cleanCode.replace(/\s+/g, ' ');
    const normPreset = p.code.replace(/\s+/g, ' ');
    return normCode === normPreset || normCode.includes(p.id) || p.title.toLowerCase() === cleanCode.toLowerCase();
  });

  if (matchedPreset) {
    let customOutput = matchedPreset.expectedOutput;

    // If user supplied input for dynamic calculation
    if (userInput.trim()) {
      const inputs = userInput.trim().split(/\s+/).map(Number);
      if (matchedPreset.id === 'prog-2' && inputs.length >= 2 && !isNaN(inputs[0]) && !isNaN(inputs[1])) {
        customOutput = `पहली संख्या दर्ज करें: ${inputs[0]}\nदूसरी संख्या दर्ज करें: ${inputs[1]}\nकुल जोड़ (Sum) = ${inputs[0] + inputs[1]}`;
      } else if (matchedPreset.id === 'prog-3' && inputs.length >= 1 && !isNaN(inputs[0])) {
        const n = inputs[0];
        customOutput = `एक संख्या दर्ज करें: ${n}\n${n} एक ${n % 2 === 0 ? 'सम संख्या (Even Number)' : 'विषम संख्या (Odd Number)'} है।`;
      } else if (matchedPreset.id === 'prog-5' && inputs.length >= 1 && !isNaN(inputs[0])) {
        const n = inputs[0];
        let tableStr = `जिस संख्या का पहाड़ा चाहिए, दर्ज करें: ${n}\n--- ${n} का पहाड़ा ---\n`;
        for (let i = 1; i <= 10; i++) {
          tableStr += `${n} x ${i} = ${n * i}\n`;
        }
        customOutput = tableStr.trim();
      } else if (matchedPreset.id === 'prog-6' && inputs.length >= 1 && !isNaN(inputs[0])) {
        const n = Math.min(20, Math.max(0, inputs[0]));
        let f = 1;
        for (let i = 1; i <= n; i++) f *= i;
        customOutput = `एक धनात्मक संख्या दर्ज करें: ${n}\n${n} का फैक्टोरियल (${n}!) = ${f}`;
      } else if (matchedPreset.id === 'prog-8' && inputs.length >= 1 && !isNaN(inputs[0])) {
        const n = inputs[0];
        let isPrime = n > 1;
        for (let i = 2; i * i <= n; i++) {
          if (n % i === 0) {
            isPrime = false;
            break;
          }
        }
        customOutput = `${n} एक ${isPrime ? 'अभाज्य (Prime)' : 'भाज्य (Composite)'} संख्या है।`;
      }
    }

    return {
      success: true,
      output: customOutput,
      errorsHindi: [],
      warningsHindi,
      executionTimeMs: Math.round(performance.now() - startTime) + 12,
    };
  }

  // 3. Fallback General Interpreter for custom student code
  let customConsoleOutput = '';
  const coutMatches = cleanCode.match(/cout\s*<<\s*([^;]+);/g);
  if (coutMatches && coutMatches.length > 0) {
    coutMatches.forEach((coutStmt) => {
      // Extract parts between <<
      const parts = coutStmt
        .replace(/^cout\s*<</, '')
        .replace(/;$/, '')
        .split('<<')
        .map((p) => p.trim());

      parts.forEach((p) => {
        if (p === 'endl' || p === '"\\n"') {
          customConsoleOutput += '\n';
        } else if (p.startsWith('"') && p.endsWith('"')) {
          customConsoleOutput += p.slice(1, -1);
        } else if (!isNaN(Number(p))) {
          customConsoleOutput += p;
        } else {
          // Check if it looks like an expression (e.g. 5 + 10)
          try {
            // safe eval only for numbers and arithmetic
            if (/^[0-9\s+\-*/%()]+$/.test(p)) {
              // eslint-disable-next-line no-eval
              const res = Function(`"use strict"; return (${p});`)();
              customConsoleOutput += res;
            } else {
              customConsoleOutput += `[${p}]`;
            }
          } catch {
            customConsoleOutput += `[${p}]`;
          }
        }
      });
    });
  } else {
    customConsoleOutput = `प्रोग्राम सफलतापूर्वक कंपाइल हुआ (Process returned 0).\n(नोट: प्रोग्राम में कोई cout आउटपुट स्टेटमेंट नहीं मिला)`;
  }

  return {
    success: true,
    output: customConsoleOutput.trim(),
    errorsHindi: [],
    warningsHindi,
    executionTimeMs: Math.round(performance.now() - startTime) + 18,
  };
}
