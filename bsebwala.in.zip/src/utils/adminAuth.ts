// BSEB Computer Science Companion - Admin Authentication Utility
// Handles Admin ID 'Ashish9Singh' and password change on first login

const ADMIN_STORAGE_KEY = 'bseb_admin_credentials_v1';
const ADMIN_SESSION_KEY = 'bseb_admin_session_active';

export interface AdminCredentials {
  adminId: string;
  passwordHash: string; // stored value
  isFirstLoginDone: boolean;
  lastUpdated: string;
}

const DEFAULT_ADMIN_CONFIG: AdminCredentials = {
  adminId: 'Ashish9Singh',
  passwordHash: '123456',
  isFirstLoginDone: false,
  lastUpdated: new Date().toISOString(),
};

export function getAdminCredentials(): AdminCredentials {
  try {
    const raw = localStorage.getItem(ADMIN_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(ADMIN_STORAGE_KEY, JSON.stringify(DEFAULT_ADMIN_CONFIG));
      return DEFAULT_ADMIN_CONFIG;
    }
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_ADMIN_CONFIG, ...parsed };
  } catch (e) {
    return DEFAULT_ADMIN_CONFIG;
  }
}

export function saveAdminCredentials(creds: AdminCredentials): void {
  try {
    localStorage.setItem(ADMIN_STORAGE_KEY, JSON.stringify(creds));
  } catch (e) {
    console.warn('Could not save admin credentials:', e);
  }
}

export function verifyAdminLogin(idInput: string, passwordInput: string): { success: boolean; requiresPasswordChange: boolean; errorHindi?: string } {
  const current = getAdminCredentials();
  
  const idMatch = current.adminId.trim() === idInput.trim();
  const passMatch = current.passwordHash === passwordInput.trim();

  if (!idMatch || !passMatch) {
    return {
      success: false,
      requiresPasswordChange: false,
      errorHindi: 'अमान्य एडमिन ID या पासवर्ड! कृपया सही विवरण दर्ज करें।',
    };
  }

  // If credentials match, check if first login password change is required
  const requiresChange = !current.isFirstLoginDone || current.passwordHash === '123456';

  return {
    success: true,
    requiresPasswordChange: requiresChange,
  };
}

export function updateAdminPassword(newPassword: string): { success: boolean; errorHindi?: string } {
  if (!newPassword || newPassword.trim().length < 6) {
    return {
      success: false,
      errorHindi: 'नया पासवर्ड कम से कम 6 अक्षरों का होना अनिवार्य है।',
    };
  }

  if (newPassword.trim() === '123456') {
    return {
      success: false,
      errorHindi: 'सुरक्षा हेतु आप डिफ़ॉल्ट पासवर्ड (123456) नहीं रख सकते। कृपया नया मजबूत पासवर्ड चुनें।',
    };
  }

  const current = getAdminCredentials();
  const updated: AdminCredentials = {
    ...current,
    passwordHash: newPassword.trim(),
    isFirstLoginDone: true,
    lastUpdated: new Date().toISOString(),
  };

  saveAdminCredentials(updated);
  setAdminSession(true);

  return { success: true };
}

export function isAdminSessionActive(): boolean {
  try {
    return sessionStorage.getItem(ADMIN_SESSION_KEY) === 'true';
  } catch {
    return false;
  }
}

export function setAdminSession(isActive: boolean): void {
  try {
    if (isActive) {
      sessionStorage.setItem(ADMIN_SESSION_KEY, 'true');
    } else {
      sessionStorage.removeItem(ADMIN_SESSION_KEY);
    }
  } catch (e) {
    console.warn('SessionStorage error:', e);
  }
}

export function logoutAdmin(): void {
  setAdminSession(false);
}
