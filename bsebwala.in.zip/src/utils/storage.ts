import { StudentProgress } from '../types';

const STORAGE_KEY = 'bseb_cs_student_progress_v1';

export const initialProgress: StudentProgress = {
  completedChapterIds: ['c11-cpp-intro'],
  quizScores: {
    'c11-cpp-intro': { score: 4, total: 5, date: '2026-10-31' },
  },
  savedNotes: {},
  bookmarkedQuestions: ['q11-1', 'q11-l1'],
  streakDays: 3,
  lastStudiedDate: new Date().toISOString().split('T')[0],
  sqlRunCount: 4,
  cppRunCount: 6,
  masteredFlashcardIds: ['fc-c11-token', 'fc-c12-class'],
};

export function loadStudentProgress(): StudentProgress {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return initialProgress;
    const parsed = JSON.parse(raw);
    return {
      ...initialProgress,
      ...parsed,
      masteredFlashcardIds: parsed.masteredFlashcardIds || initialProgress.masteredFlashcardIds,
    };
  } catch (e) {
    console.warn('Could not read from local storage:', e);
    return initialProgress;
  }
}

export function saveStudentProgress(progress: StudentProgress): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (e) {
    console.warn('Could not save to local storage:', e);
  }
}

export function recordChapterComplete(chapterId: string): StudentProgress {
  const current = loadStudentProgress();
  if (!current.completedChapterIds.includes(chapterId)) {
    current.completedChapterIds.push(chapterId);
    saveStudentProgress(current);
  }
  return current;
}

export function recordQuizScore(chapterOrTestId: string, score: number, total: number): StudentProgress {
  const current = loadStudentProgress();
  current.quizScores[chapterOrTestId] = {
    score,
    total,
    date: new Date().toISOString().split('T')[0],
  };
  saveStudentProgress(current);
  return current;
}

export function toggleBookmarkQuestion(questionId: string): { progress: StudentProgress; isBookmarked: boolean } {
  const current = loadStudentProgress();
  const index = current.bookmarkedQuestions.indexOf(questionId);
  let isBookmarked = false;
  if (index >= 0) {
    current.bookmarkedQuestions.splice(index, 1);
  } else {
    current.bookmarkedQuestions.push(questionId);
    isBookmarked = true;
  }
  saveStudentProgress(current);
  return { progress: current, isBookmarked };
}

export function incrementLabCount(type: 'sql' | 'cpp'): StudentProgress {
  const current = loadStudentProgress();
  if (type === 'sql') current.sqlRunCount = (current.sqlRunCount || 0) + 1;
  if (type === 'cpp') current.cppRunCount = (current.cppRunCount || 0) + 1;
  saveStudentProgress(current);
  return current;
}

export function toggleMasteredFlashcard(cardId: string): { progress: StudentProgress; isMastered: boolean } {
  const current = loadStudentProgress();
  if (!current.masteredFlashcardIds) current.masteredFlashcardIds = [];
  const idx = current.masteredFlashcardIds.indexOf(cardId);
  let isMastered = false;
  if (idx >= 0) {
    current.masteredFlashcardIds.splice(idx, 1);
  } else {
    current.masteredFlashcardIds.push(cardId);
    isMastered = true;
  }
  saveStudentProgress(current);
  return { progress: current, isMastered };
}

