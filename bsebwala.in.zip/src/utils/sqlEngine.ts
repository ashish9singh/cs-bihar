import { SqlExercise } from '../types';

export interface SqlResult {
  success: boolean;
  columns: string[];
  rows: (string | number | null)[][];
  rowCount: number;
  messageHindi: string;
  errorHindi?: string;
  executionTimeMs: number;
}

export interface TableSchema {
  name: string;
  type: string;
}

export interface TableData {
  schema: TableSchema[];
  rows: Record<string, any>[];
}

export const INITIAL_STUDENT_DATA: TableData = {
  schema: [
    { name: 'Roll_No', type: 'INT' },
    { name: 'Name', type: 'VARCHAR(50)' },
    { name: 'Class', type: 'INT' },
    { name: 'Marks', type: 'INT' },
  ],
  rows: [
    { Roll_No: 1, Name: 'Rahul', Class: 11, Marks: 85 },
    { Roll_No: 2, Name: 'Priya', Class: 11, Marks: 92 },
    { Roll_No: 3, Name: 'Amit', Class: 12, Marks: 76 },
    { Roll_No: 4, Name: 'Neha', Class: 12, Marks: 89 },
  ],
};

export class ClientSqlEngine {
  private tables: Record<string, TableData> = {};

  constructor() {
    this.reset();
  }

  public reset() {
    this.tables = {
      STUDENT: JSON.parse(JSON.stringify(INITIAL_STUDENT_DATA)),
    };
  }

  public getTableList(): string[] {
    return Object.keys(this.tables);
  }

  public getTableData(tableName: string): TableData | null {
    const key = Object.keys(this.tables).find(
      (k) => k.toLowerCase() === tableName.toLowerCase()
    );
    return key ? this.tables[key] : null;
  }

  public execute(rawQuery: string): SqlResult {
    const startTime = performance.now();
    const query = rawQuery.trim().replace(/;+$/, '').trim();

    if (!query) {
      return {
        success: false,
        columns: [],
        rows: [],
        rowCount: 0,
        messageHindi: 'कोई SQL क्वेरी नहीं दी गई।',
        errorHindi: 'कृपया अपनी SQL क्वेरी टाइप करें (जैसे: SELECT * FROM STUDENT;)',
        executionTimeMs: 0,
      };
    }

    try {
      const upperQuery = query.toUpperCase();

      if (upperQuery.startsWith('SELECT')) {
        return this.handleSelect(query, startTime);
      } else if (upperQuery.startsWith('INSERT INTO')) {
        return this.handleInsert(query, startTime);
      } else if (upperQuery.startsWith('UPDATE')) {
        return this.handleUpdate(query, startTime);
      } else if (upperQuery.startsWith('DELETE')) {
        return this.handleDelete(query, startTime);
      } else if (upperQuery.startsWith('CREATE TABLE')) {
        return this.handleCreateTable(query, startTime);
      } else if (upperQuery.startsWith('DROP TABLE')) {
        return this.handleDropTable(query, startTime);
      } else {
        return {
          success: false,
          columns: [],
          rows: [],
          rowCount: 0,
          messageHindi: 'अमान्य SQL कमांड।',
          errorHindi: 'केवल SELECT, INSERT, UPDATE, DELETE, CREATE TABLE या DROP TABLE कमांड्स समर्थित हैं। कृपया सिंटैक्स जाँचें।',
          executionTimeMs: Math.round(performance.now() - startTime),
        };
      }
    } catch (err: any) {
      return {
        success: false,
        columns: [],
        rows: [],
        rowCount: 0,
        messageHindi: 'क्वेरी निष्पादन में त्रुटि हुई।',
        errorHindi: `सिंटैक्स त्रुटि: ${err.message || 'क्वेरी का प्रारूप सही नहीं है।'}`,
        executionTimeMs: Math.round(performance.now() - startTime),
      };
    }
  }

  private handleSelect(query: string, startTime: number): SqlResult {
    // Basic regex parser for SELECT [columns] FROM [table] [WHERE condition] [GROUP BY groupCol] [ORDER BY orderCol [ASC|DESC]]
    const fromIndex = query.search(/\bFROM\b/i);
    if (fromIndex === -1) {
      throw new Error('SELECT क्वेरी में FROM क्लॉज अनिवार्य है। उदाहरण: SELECT * FROM STUDENT;');
    }

    const selectPart = query.substring(6, fromIndex).trim();
    let remaining = query.substring(fromIndex + 4).trim();

    // Check for ORDER BY
    let orderByCol: string | null = null;
    let orderDirection: 'ASC' | 'DESC' = 'ASC';
    const orderMatch = remaining.match(/\bORDER\s+BY\s+([a-zA-Z0-9_]+)(\s+(ASC|DESC))?/i);
    if (orderMatch) {
      orderByCol = orderMatch[1];
      if (orderMatch[3] && orderMatch[3].toUpperCase() === 'DESC') {
        orderDirection = 'DESC';
      }
      remaining = remaining.substring(0, orderMatch.index).trim();
    }

    // Check for GROUP BY
    let groupByCol: string | null = null;
    const groupMatch = remaining.match(/\bGROUP\s+BY\s+([a-zA-Z0-9_]+)/i);
    if (groupMatch) {
      groupByCol = groupMatch[1];
      remaining = remaining.substring(0, groupMatch.index).trim();
    }

    // Check for WHERE
    let whereClause: string | null = null;
    const whereMatch = remaining.match(/\bWHERE\s+(.+)$/i);
    let tableName = remaining;
    if (whereMatch) {
      whereClause = whereMatch[1].trim();
      tableName = remaining.substring(0, whereMatch.index).trim();
    }

    tableName = tableName.replace(/[^a-zA-Z0-9_]/g, '');

    const table = this.getTableData(tableName);
    if (!table) {
      throw new Error(`टेबल '${tableName}' नहीं मिली। क्या आप 'STUDENT' टेबल का उपयोग करना चाहते हैं?`);
    }

    // Filter rows with WHERE
    let matchedRows = [...table.rows];
    if (whereClause) {
      matchedRows = matchedRows.filter((row) => this.evalWhere(row, whereClause!));
    }

    // Handle GROUP BY and Aggregates
    if (groupByCol) {
      const groupColReal = Object.keys(table.rows[0] || {}).find(
        (k) => k.toLowerCase() === groupByCol?.toLowerCase()
      );
      if (!groupColReal) {
        throw new Error(`GROUP BY के लिए कॉलम '${groupByCol}' टेबल में मौजूद नहीं है।`);
      }

      const groups: Record<string, Record<string, any>[]> = {};
      matchedRows.forEach((row) => {
        const key = String(row[groupColReal]);
        if (!groups[key]) groups[key] = [];
        groups[key].push(row);
      });

      // Parse aggregate projections
      const colTokens = selectPart.split(',').map((s) => s.trim());
      const resCols: string[] = [];
      const resRows: (string | number | null)[][] = [];

      for (const token of colTokens) {
        resCols.push(token);
      }

      Object.entries(groups).forEach(([groupVal, rowsInGroup]) => {
        const rowResult: (string | number | null)[] = [];
        for (const token of colTokens) {
          const upper = token.toUpperCase();
          if (token.toLowerCase() === groupColReal.toLowerCase()) {
            rowResult.push(groupVal);
          } else if (upper.startsWith('COUNT(')) {
            rowResult.push(rowsInGroup.length);
          } else if (upper.startsWith('SUM(')) {
            const col = token.match(/\(([^)]+)\)/)?.[1].trim() || '';
            const sum = rowsInGroup.reduce((acc, r) => acc + (Number(r[this.getColName(r, col)]) || 0), 0);
            rowResult.push(sum);
          } else if (upper.startsWith('AVG(')) {
            const col = token.match(/\(([^)]+)\)/)?.[1].trim() || '';
            const sum = rowsInGroup.reduce((acc, r) => acc + (Number(r[this.getColName(r, col)]) || 0), 0);
            const avg = rowsInGroup.length ? Number((sum / rowsInGroup.length).toFixed(1)) : 0;
            rowResult.push(avg);
          } else if (upper.startsWith('MAX(')) {
            const col = token.match(/\(([^)]+)\)/)?.[1].trim() || '';
            const max = Math.max(...rowsInGroup.map((r) => Number(r[this.getColName(r, col)]) || 0));
            rowResult.push(max);
          } else if (upper.startsWith('MIN(')) {
            const col = token.match(/\(([^)]+)\)/)?.[1].trim() || '';
            const min = Math.min(...rowsInGroup.map((r) => Number(r[this.getColName(r, col)]) || 0));
            rowResult.push(min);
          } else {
            rowResult.push(rowsInGroup[0]?.[this.getColName(rowsInGroup[0], token)] ?? null);
          }
        }
        resRows.push(rowResult);
      });

      return {
        success: true,
        columns: resCols,
        rows: resRows,
        rowCount: resRows.length,
        messageHindi: `सफलतापूर्वक समूह बनाकर ${resRows.length} परिणाम प्राप्त हुए!`,
        executionTimeMs: Math.round(performance.now() - startTime),
      };
    }

    // Check single aggregates if no GROUP BY
    const isSingleAggregate =
      selectPart.toUpperCase().includes('COUNT(') ||
      selectPart.toUpperCase().includes('SUM(') ||
      selectPart.toUpperCase().includes('AVG(') ||
      selectPart.toUpperCase().includes('MAX(') ||
      selectPart.toUpperCase().includes('MIN(');

    if (isSingleAggregate) {
      const colTokens = selectPart.split(',').map((s) => s.trim());
      const resCols: string[] = colTokens;
      const rowResult: (string | number | null)[] = [];

      for (const token of colTokens) {
        const upper = token.toUpperCase();
        if (upper.startsWith('COUNT(')) {
          rowResult.push(matchedRows.length);
        } else if (upper.startsWith('SUM(')) {
          const col = token.match(/\(([^)]+)\)/)?.[1].trim() || '';
          const sum = matchedRows.reduce((acc, r) => acc + (Number(r[this.getColName(r, col)]) || 0), 0);
          rowResult.push(sum);
        } else if (upper.startsWith('AVG(')) {
          const col = token.match(/\(([^)]+)\)/)?.[1].trim() || '';
          const sum = matchedRows.reduce((acc, r) => acc + (Number(r[this.getColName(r, col)]) || 0), 0);
          rowResult.push(matchedRows.length ? Number((sum / matchedRows.length).toFixed(1)) : 0);
        } else if (upper.startsWith('MAX(')) {
          const col = token.match(/\(([^)]+)\)/)?.[1].trim() || '';
          const vals = matchedRows.map((r) => Number(r[this.getColName(r, col)]) || 0);
          rowResult.push(vals.length ? Math.max(...vals) : 0);
        } else if (upper.startsWith('MIN(')) {
          const col = token.match(/\(([^)]+)\)/)?.[1].trim() || '';
          const vals = matchedRows.map((r) => Number(r[this.getColName(r, col)]) || 0);
          rowResult.push(vals.length ? Math.min(...vals) : 0);
        } else {
          rowResult.push(matchedRows[0]?.[this.getColName(matchedRows[0], token)] ?? null);
        }
      }

      return {
        success: true,
        columns: resCols,
        rows: [rowResult],
        rowCount: 1,
        messageHindi: 'Aggregate फ़ंक्शन द्वारा गणना पूर्ण हुई!',
        executionTimeMs: Math.round(performance.now() - startTime),
      };
    }

    // Normal column projection
    let outputColumns: string[] = [];
    if (selectPart === '*') {
      outputColumns = table.schema.map((s) => s.name);
    } else {
      const requested = selectPart.split(',').map((c) => c.trim());
      outputColumns = requested.map((req) => {
        const found = table.schema.find((s) => s.name.toLowerCase() === req.toLowerCase());
        if (!found) throw new Error(`कॉलम '${req}' टेबल '${tableName}' में नहीं मिला।`);
        return found.name;
      });
    }

    // Sort if ORDER BY requested
    if (orderByCol) {
      const realOrderCol = table.schema.find((s) => s.name.toLowerCase() === orderByCol?.toLowerCase())?.name;
      if (!realOrderCol) {
        throw new Error(`ORDER BY के लिए कॉलम '${orderByCol}' मौजूद नहीं है।`);
      }
      matchedRows.sort((a, b) => {
        const valA = a[realOrderCol];
        const valB = b[realOrderCol];
        if (typeof valA === 'number' && typeof valB === 'number') {
          return orderDirection === 'ASC' ? valA - valB : valB - valA;
        }
        return orderDirection === 'ASC'
          ? String(valA).localeCompare(String(valB))
          : String(valB).localeCompare(String(valA));
      });
    }

    const outputRows = matchedRows.map((row) =>
      outputColumns.map((col) => (row[col] !== undefined ? row[col] : null))
    );

    return {
      success: true,
      columns: outputColumns,
      rows: outputRows,
      rowCount: outputRows.length,
      messageHindi: `सफलतापूर्वक ${outputRows.length} पंक्तियाँ (Rows) प्राप्त हुईं!`,
      executionTimeMs: Math.round(performance.now() - startTime),
    };
  }

  private handleInsert(query: string, startTime: number): SqlResult {
    // Pattern: INSERT INTO table [(cols)] VALUES (vals)
    const match = query.match(/INSERT\s+INTO\s+([a-zA-Z0-9_]+)\s*(\(([^)]+)\))?\s*VALUES\s*\((.+)\)/i);
    if (!match) {
      throw new Error("INSERT सिंटैक्स गलत है। सही प्रारूप: INSERT INTO STUDENT VALUES (5, 'Anjali', 11, 95);");
    }

    const tableName = match[1];
    const customCols = match[3] ? match[3].split(',').map((c) => c.trim()) : null;
    const rawVals = match[4].split(',').map((v) => v.trim().replace(/^['"]|['"]$/g, ''));

    const table = this.getTableData(tableName);
    if (!table) {
      throw new Error(`टेबल '${tableName}' नहीं मिली।`);
    }

    const newRow: Record<string, any> = {};

    if (customCols) {
      if (customCols.length !== rawVals.length) {
        throw new Error('दिए गए कॉलम और वैल्यूज की संख्या मेल नहीं खाती।');
      }
      customCols.forEach((col, idx) => {
        const schemaCol = table.schema.find((s) => s.name.toLowerCase() === col.toLowerCase());
        if (!schemaCol) throw new Error(`कॉलम '${col}' टेबल में नहीं है।`);
        const val = rawVals[idx];
        newRow[schemaCol.name] = schemaCol.type.includes('INT') ? Number(val) : val;
      });
    } else {
      if (rawVals.length !== table.schema.length) {
        throw new Error(`टेबल '${tableName}' में ${table.schema.length} कॉलम हैं, लेकिन आपने ${rawVals.length} वैल्यू दी हैं।`);
      }
      table.schema.forEach((col, idx) => {
        const val = rawVals[idx];
        newRow[col.name] = col.type.includes('INT') ? Number(val) : val;
      });
    }

    // Check primary key duplicate if Roll_No
    if (newRow.Roll_No !== undefined) {
      const exists = table.rows.some((r) => r.Roll_No === newRow.Roll_No);
      if (exists) {
        throw new Error(`Primary Key त्रुटि! Roll_No = ${newRow.Roll_No} पहले से ही मौजूद है।`);
      }
    }

    table.rows.push(newRow);

    return {
      success: true,
      columns: table.schema.map((s) => s.name),
      rows: table.rows.map((r) => table.schema.map((s) => r[s.name])),
      rowCount: 1,
      messageHindi: `सफलतापूर्वक 1 नई पंक्ति जोड़ी गई! वर्तमान में कुल ${table.rows.length} रिकॉर्ड हैं।`,
      executionTimeMs: Math.round(performance.now() - startTime),
    };
  }

  private handleUpdate(query: string, startTime: number): SqlResult {
    // Pattern: UPDATE table SET col=val, ... [WHERE condition]
    const match = query.match(/UPDATE\s+([a-zA-Z0-9_]+)\s+SET\s+(.+?)(\s+WHERE\s+(.+))?$/i);
    if (!match) {
      throw new Error("UPDATE सिंटैक्स गलत है। उदाहरण: UPDATE STUDENT SET Marks = 95 WHERE Roll_No = 3;");
    }

    const tableName = match[1];
    const setClause = match[2];
    const whereClause = match[4];

    const table = this.getTableData(tableName);
    if (!table) throw new Error(`टेबल '${tableName}' नहीं मिली।`);

    const setAssignments = setClause.split(',').map((s) => s.trim());
    let updatedCount = 0;

    table.rows.forEach((row) => {
      if (!whereClause || this.evalWhere(row, whereClause)) {
        setAssignments.forEach((assign) => {
          const [col, rawVal] = assign.split('=').map((x) => x.trim());
          const cleanVal = rawVal.replace(/^['"]|['"]$/g, '');
          const schemaCol = table.schema.find((s) => s.name.toLowerCase() === col.toLowerCase());
          if (schemaCol) {
            row[schemaCol.name] = schemaCol.type.includes('INT') ? Number(cleanVal) : cleanVal;
          }
        });
        updatedCount++;
      }
    });

    return {
      success: true,
      columns: table.schema.map((s) => s.name),
      rows: table.rows.map((r) => table.schema.map((s) => r[s.name])),
      rowCount: updatedCount,
      messageHindi: `सफलतापूर्वक ${updatedCount} पंक्ति(याँ) अपडेट की गईं!`,
      executionTimeMs: Math.round(performance.now() - startTime),
    };
  }

  private handleDelete(query: string, startTime: number): SqlResult {
    // Pattern: DELETE FROM table [WHERE condition]
    const match = query.match(/DELETE\s+FROM\s+([a-zA-Z0-9_]+)(\s+WHERE\s+(.+))?$/i);
    if (!match) {
      throw new Error("DELETE सिंटैक्स गलत है। उदाहरण: DELETE FROM STUDENT WHERE Roll_No = 1;");
    }

    const tableName = match[1];
    const whereClause = match[3];

    const table = this.getTableData(tableName);
    if (!table) throw new Error(`टेबल '${tableName}' नहीं मिली।`);

    const initialLength = table.rows.length;
    if (whereClause) {
      table.rows = table.rows.filter((row) => !this.evalWhere(row, whereClause));
    } else {
      table.rows = [];
    }

    const deletedCount = initialLength - table.rows.length;

    return {
      success: true,
      columns: table.schema.map((s) => s.name),
      rows: table.rows.map((r) => table.schema.map((s) => r[s.name])),
      rowCount: deletedCount,
      messageHindi: `सफलतापूर्वक ${deletedCount} पंक्ति(याँ) हटाई गईं।`,
      executionTimeMs: Math.round(performance.now() - startTime),
    };
  }

  private handleCreateTable(query: string, startTime: number): SqlResult {
    // Pattern: CREATE TABLE name (col1 type, col2 type...)
    const match = query.match(/CREATE\s+TABLE\s+([a-zA-Z0-9_]+)\s*\((.+)\)/i);
    if (!match) {
      throw new Error("CREATE TABLE सिंटैक्स गलत है। उदाहरण: CREATE TABLE TEACHER (ID INT PRIMARY KEY, Name VARCHAR(50));");
    }

    const tableName = match[1].toUpperCase();
    const colDefs = match[2].split(',').map((c) => c.trim());

    if (this.tables[tableName]) {
      throw new Error(`टेबल '${tableName}' पहले से मौजूद है!`);
    }

    const schema: TableSchema[] = colDefs.map((def) => {
      const parts = def.split(/\s+/);
      return {
        name: parts[0],
        type: parts.slice(1).join(' ').toUpperCase(),
      };
    });

    this.tables[tableName] = {
      schema,
      rows: [],
    };

    return {
      success: true,
      columns: schema.map((s) => s.name),
      rows: [],
      rowCount: 0,
      messageHindi: `नई टेबल '${tableName}' सफलतापूर्वक बनाई गई!`,
      executionTimeMs: Math.round(performance.now() - startTime),
    };
  }

  private handleDropTable(query: string, startTime: number): SqlResult {
    const match = query.match(/DROP\s+TABLE\s+([a-zA-Z0-9_]+)/i);
    if (!match) throw new Error("DROP TABLE प्रारूप: DROP TABLE tablename;");

    const tableName = match[1].toUpperCase();
    if (!this.tables[tableName]) {
      throw new Error(`टेबल '${tableName}' मौजूद नहीं है।`);
    }

    delete this.tables[tableName];

    return {
      success: true,
      columns: [],
      rows: [],
      rowCount: 0,
      messageHindi: `टेबल '${tableName}' सफलतापूर्वक हटा दी गई (Dropped)।`,
      executionTimeMs: Math.round(performance.now() - startTime),
    };
  }

  private evalWhere(row: Record<string, any>, conditionStr: string): boolean {
    const orParts = conditionStr.split(/\bOR\b/i);
    return orParts.some((orClause) => {
      const andParts = orClause.split(/\bAND\b/i);
      return andParts.every((andClause) => this.evalSingleComparison(row, andClause.trim()));
    });
  }

  private evalSingleComparison(row: Record<string, any>, expr: string): boolean {
    const operators = ['>=', '<=', '!=', '<>', '>', '<', '=', 'LIKE'];
    let opFound: string | null = null;

    for (const op of operators) {
      if (expr.includes(op)) {
        opFound = op;
        break;
      }
    }

    if (!opFound) return true;

    const parts = expr.split(new RegExp(`\\s*${opFound}\\s*`, 'i'));
    if (parts.length < 2) return true;

    const colName = parts[0].trim();
    let targetVal = parts[1].trim().replace(/^['"]|['"]$/g, '');

    const realCol = this.getColName(row, colName);
    const rowVal = row[realCol];

    if (opFound === 'LIKE') {
      const regexStr = '^' + targetVal.replace(/%/g, '.*').replace(/_/g, '.') + '$';
      return new RegExp(regexStr, 'i').test(String(rowVal));
    }

    const numRow = Number(rowVal);
    const numTarget = Number(targetVal);
    const isNumeric = !isNaN(numRow) && !isNaN(numTarget) && rowVal !== '' && targetVal !== '';

    switch (opFound) {
      case '=':
        return isNumeric ? numRow === numTarget : String(rowVal).toLowerCase() === targetVal.toLowerCase();
      case '!=':
      case '<>':
        return isNumeric ? numRow !== numTarget : String(rowVal).toLowerCase() !== targetVal.toLowerCase();
      case '>':
        return isNumeric ? numRow > numTarget : String(rowVal) > targetVal;
      case '<':
        return isNumeric ? numRow < numTarget : String(rowVal) < targetVal;
      case '>=':
        return isNumeric ? numRow >= numTarget : String(rowVal) >= targetVal;
      case '<=':
        return isNumeric ? numRow <= numTarget : String(rowVal) <= targetVal;
      default:
        return true;
    }
  }

  private getColName(row: Record<string, any>, col: string): string {
    const key = Object.keys(row).find((k) => k.toLowerCase() === col.toLowerCase());
    return key || col;
  }
}

// 12 BSEB Practical SQL Exercises
export const bsebSqlExercises: SqlExercise[] = [
  {
    id: 'sql-1',
    title: 'Show All Students',
    titleHindi: '1. सभी छात्रों का विवरण देखें',
    difficulty: 'Beginner',
    concept: 'SELECT * FROM table',
    query: 'SELECT * FROM STUDENT;',
    explanationHindi: 'यह पूरी STUDENT टेबल के सभी कॉलम्स और रिकॉर्ड्स को प्रदर्शित करता है। * का अर्थ है "सभी कॉलम"।',
  },
  {
    id: 'sql-2',
    title: 'Filter by Marks',
    titleHindi: '2. 80 से अधिक अंक वाले छात्र',
    difficulty: 'Beginner',
    concept: 'WHERE Clause',
    query: 'SELECT Name, Marks FROM STUDENT WHERE Marks > 80;',
    explanationHindi: 'WHERE क्लॉज केवल उन पंक्तियों को छाँटता है जहाँ Marks का मान 80 से बड़ा हो।',
  },
  {
    id: 'sql-3',
    title: 'Sort by Marks Descending',
    titleHindi: '3. अंकों के घटते क्रम में सूची',
    difficulty: 'Beginner',
    concept: 'ORDER BY DESC',
    query: 'SELECT * FROM STUDENT ORDER BY Marks DESC;',
    explanationHindi: 'ORDER BY Marks DESC से सबसे अधिक अंक वाले छात्र (Topper) का रिकॉर्ड सबसे ऊपर आता है।',
  },
  {
    id: 'sql-4',
    title: 'Class 12 Students',
    titleHindi: '4. कक्षा 12 के छात्रों की सूची',
    difficulty: 'Beginner',
    concept: 'WHERE Class = 12',
    query: 'SELECT Roll_No, Name FROM STUDENT WHERE Class = 12;',
    explanationHindi: 'केवल कक्षा 12 के छात्रों का रोल नंबर और नाम प्रदर्शित करता है।',
  },
  {
    id: 'sql-5',
    title: 'Count Total Students',
    titleHindi: '5. कुल छात्रों की संख्या गिनना',
    difficulty: 'Intermediate',
    concept: 'COUNT() Aggregate Function',
    query: 'SELECT COUNT(*) FROM STUDENT;',
    explanationHindi: 'COUNT(*) फ़ंक्शन टेबल में मौजूद कुल रिकॉर्ड्स (पंक्तियों) की संख्या गिनता है।',
  },
  {
    id: 'sql-6',
    title: 'Average Marks',
    titleHindi: '6. सभी छात्रों के औसत अंक',
    difficulty: 'Intermediate',
    concept: 'AVG() Function',
    query: 'SELECT AVG(Marks) FROM STUDENT;',
    explanationHindi: 'AVG(Marks) सभी छात्रों के प्राप्तांकों का औसत (Average) निकालता है।',
  },
  {
    id: 'sql-7',
    title: 'Highest and Lowest Marks',
    titleHindi: '7. उच्चतम और न्यूनतम अंक',
    difficulty: 'Intermediate',
    concept: 'MAX() and MIN() Functions',
    query: 'SELECT MAX(Marks), MIN(Marks) FROM STUDENT;',
    explanationHindi: 'MAX() सबसे अधिक अंक और MIN() सबसे कम अंक प्राप्त करने के लिए प्रयोग किया जाता है।',
  },
  {
    id: 'sql-8',
    title: 'Average Marks by Class',
    titleHindi: '8. कक्षा-वार औसत प्राप्तांक (GROUP BY)',
    difficulty: 'BSEB Exam Special',
    concept: 'GROUP BY with AVG()',
    query: 'SELECT Class, AVG(Marks) FROM STUDENT GROUP BY Class;',
    explanationHindi: 'यह कक्षा 11 और कक्षा 12 का अलग-अलग समूह बनाकर प्रत्येक कक्षा का औसत अंक दिखाता है। BSEB परीक्षा में अक्सर पूछा जाता है।',
  },
  {
    id: 'sql-9',
    title: 'Insert a New Student',
    titleHindi: '9. नया छात्र जोड़ना (INSERT INTO)',
    difficulty: 'Intermediate',
    concept: 'INSERT INTO',
    query: "INSERT INTO STUDENT VALUES (5, 'Anjali', 11, 95);",
    explanationHindi: 'INSERT INTO कमांड से डेटाबेस में नया रिकॉर्ड जोड़ा जाता है। इसके बाद आप SELECT * चलाकर देख सकते हैं।',
  },
  {
    id: 'sql-10',
    title: 'Update Student Marks',
    titleHindi: '10. प्राप्तांक सुधारना (UPDATE)',
    difficulty: 'Intermediate',
    concept: 'UPDATE with WHERE',
    query: 'UPDATE STUDENT SET Marks = 90 WHERE Roll_No = 3;',
    explanationHindi: 'UPDATE कमांड से किसी छात्र के प्राप्तांक बदले जाते हैं। ध्यान रहे, बिना WHERE के सभी के अंक बदल जाते हैं!',
  },
  {
    id: 'sql-11',
    title: 'Delete a Record',
    titleHindi: '11. छात्र का रिकॉर्ड हटाना (DELETE)',
    difficulty: 'Intermediate',
    concept: 'DELETE with WHERE',
    query: 'DELETE FROM STUDENT WHERE Roll_No = 1;',
    explanationHindi: 'DELETE FROM कमांड से रोल नंबर 1 का छात्र टेबल से हटा दिया जाएगा।',
  },
  {
    id: 'sql-12',
    title: 'Create a New Table',
    titleHindi: '12. नई टेबल बनाना (CREATE TABLE)',
    difficulty: 'BSEB Exam Special',
    concept: 'DDL - CREATE TABLE',
    query: 'CREATE TABLE TEACHER (Emp_Id INT, Name VARCHAR(50), Subject VARCHAR(30));',
    explanationHindi: 'CREATE TABLE एक DDL कमांड है जिससे डेटाबेस में नए शिक्षकों की टेबल बनाई जाती है।',
  },
];
