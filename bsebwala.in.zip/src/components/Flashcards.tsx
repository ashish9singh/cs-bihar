import React, { useState, useEffect, useMemo } from 'react';
import { 
  RotateCw, 
  Volume2, 
  CheckCircle2, 
  XCircle, 
  Shuffle, 
  Sparkles, 
  ChevronLeft, 
  ChevronRight, 
  BookOpen, 
  Layers, 
  Trophy, 
  Search,
  Filter,
  Play,
  Pause,
  RotateCcw,
  Lightbulb,
  GraduationCap
} from 'lucide-react';
import { ClassGrade, FlashcardItem, Chapter } from '../types';
import { initialFlashcards } from '../data/flashcardsData';

interface FlashcardsProps {
  selectedClass: ClassGrade;
  chapters: Chapter[];
  masteredIds: string[];
  onToggleMastered: (id: string) => void;
  onAskAI: (term: string) => void;
  isDarkMode?: boolean;
}

export const Flashcards: React.FC<FlashcardsProps> = ({
  selectedClass,
  chapters,
  masteredIds,
  onToggleMastered,
  onAskAI,
  isDarkMode = true,
}) => {
  // Aggregate static flashcards + dynamic technical terms from chapters
  const allCards = useMemo(() => {
    const combined: FlashcardItem[] = [...initialFlashcards];
    const existingTerms = new Set(combined.map((c) => c.term.toLowerCase()));

    chapters.forEach((ch) => {
      ch.technicalTerms.forEach((tt, idx) => {
        if (!existingTerms.has(tt.term.toLowerCase())) {
          existingTerms.add(tt.term.toLowerCase());
          combined.push({
            id: `dyn-${ch.id}-${idx}`,
            term: tt.term,
            hindiMeaning: tt.hindiMeaning,
            explanationHindi: tt.explanation,
            classGrade: ch.classGrade,
            category: ch.moduleTitle.split(':')[0] || 'पाठ्यक्रम शब्दावली',
            exampleOrAnalogy: ch.realLifeExample?.analogy,
            examTip: ch.importantPoints?.[0],
          });
        }
      });
    });

    return combined;
  }, [chapters]);

  // Filtering state
  const [filterClass, setFilterClass] = useState<ClassGrade | 'all'>(selectedClass);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'unmastered' | 'mastered'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewMode, setViewMode] = useState<'drill' | 'grid'>('drill');

  // Sync with prop when parent class changes
  useEffect(() => {
    setFilterClass(selectedClass);
  }, [selectedClass]);

  // Extract unique categories
  const categories = useMemo(() => {
    const cats = new Set<string>();
    allCards.forEach((c) => {
      if (filterClass === 'all' || c.classGrade === filterClass) {
        cats.add(c.category);
      }
    });
    return Array.from(cats);
  }, [allCards, filterClass]);

  // Filtered card list
  const filteredCards = useMemo(() => {
    return allCards.filter((card) => {
      if (filterClass !== 'all' && card.classGrade !== filterClass) return false;
      if (filterCategory !== 'all' && card.category !== filterCategory) return false;
      
      const isMastered = masteredIds.includes(card.id);
      if (filterStatus === 'mastered' && !isMastered) return false;
      if (filterStatus === 'unmastered' && isMastered) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTerm = card.term.toLowerCase().includes(q);
        const matchHindi = card.hindiMeaning.toLowerCase().includes(q);
        const matchExp = card.explanationHindi.toLowerCase().includes(q);
        if (!matchTerm && !matchHindi && !matchExp) return false;
      }
      return true;
    });
  }, [allCards, filterClass, filterCategory, filterStatus, searchQuery, masteredIds]);

  // Active Card Index & Flip state
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(false);

  // Keep currentIndex bounded
  useEffect(() => {
    if (currentIndex >= filteredCards.length) {
      setCurrentIndex(Math.max(0, filteredCards.length - 1));
    }
    setIsFlipped(false);
  }, [filteredCards.length]);

  const activeCard: FlashcardItem | undefined = filteredCards[currentIndex];
  const isCurrentMastered = activeCard ? masteredIds.includes(activeCard.id) : false;

  // Auto-play slideshow timer
  useEffect(() => {
    if (!isAutoPlaying || filteredCards.length === 0) return;

    const timer = setInterval(() => {
      setIsFlipped((prev) => {
        if (!prev) {
          // Flip to back
          return true;
        } else {
          // Go to next card
          setCurrentIndex((curr) => (curr + 1) % filteredCards.length);
          return false;
        }
      });
    }, 3500);

    return () => clearInterval(timer);
  }, [isAutoPlaying, filteredCards.length]);

  // Keyboard Navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) return;
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        setIsFlipped((f) => !f);
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        handleNext();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        handlePrev();
      } else if (e.code === 'KeyM' && activeCard) {
        e.preventDefault();
        onToggleMastered(activeCard.id);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeCard, filteredCards.length]);

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % filteredCards.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + filteredCards.length) % filteredCards.length);
  };

  const handleShuffle = () => {
    setIsFlipped(false);
    setCurrentIndex(Math.floor(Math.random() * filteredCards.length));
  };

  // Text-To-Speech Pronunciation
  const handleSpeakTerm = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text.split('(')[0]);
      utterance.lang = 'en-US';
      utterance.rate = 0.9;
      window.speechSynthesis.speak(utterance);
    }
  };

  const masteredCountInFilter = filteredCards.filter((c) => masteredIds.includes(c.id)).length;
  const masteryPercentage = filteredCards.length > 0 
    ? Math.round((masteredCountInFilter / filteredCards.length) * 100) 
    : 0;

  return (
    <div className="max-w-4xl mx-auto space-y-5 pb-16">
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 rounded-3xl p-4 sm:p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="bg-amber-400 text-slate-950 text-[10px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider">
                BSEB REVISION
              </span>
              <span className="text-xs text-indigo-300 font-semibold">
                तकनीकी शब्दावली त्वरित रिवीजन
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white flex items-center space-x-2">
              <Layers className="w-6 h-6 text-indigo-400" />
              <span>कम्प्यूटर साइंस फ्लैशकार्ड्स (Flashcards)</span>
            </h1>
            <p className="text-xs text-slate-300">
              क्लिक करके कार्ड पलटें (Flip Card), परिभाषा समझें और परीक्षा में शत-प्रतिशत अंक प्राप्त करें।
            </p>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center space-x-1.5 self-start sm:self-auto bg-slate-950/80 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setViewMode('drill')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                viewMode === 'drill'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              कार्ड ड्रिल
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                viewMode === 'grid'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              शब्दावली सूची ({filteredCards.length})
            </button>
          </div>
        </div>

        {/* Progress Tracker */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div className="flex items-center space-x-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="text-slate-300">याद किया गया:</span>
            <span className="font-bold text-emerald-400">{masteredCountInFilter}</span>
            <span className="text-slate-500">/</span>
            <span className="text-slate-300">{filteredCards.length} शब्द</span>
            <span className="text-amber-300 font-bold ml-1">({masteryPercentage}%)</span>
          </div>

          <div className="w-full sm:w-48 bg-slate-800 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-300"
              style={{ width: `${masteryPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* 2. Filters & Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 space-y-3 shadow-md">
        <div className="flex flex-col sm:flex-row gap-2.5">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="तकनीकी शब्द या हिंदी परिभाषा खोजें (उदा. LIFO, Array, IPOS)..."
              className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Class Filter */}
          <div className="flex items-center space-x-1 overflow-x-auto no-scrollbar shrink-0">
            {(['all', '9', '10', '11', '12'] as (ClassGrade | 'all')[]).map((c) => (
              <button
                key={c}
                onClick={() => setFilterClass(c)}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg whitespace-nowrap transition-all ${
                  filterClass === c
                    ? 'bg-blue-600 text-white shadow'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {c === 'all' ? 'सभी कक्षाएं' : `कक्षा ${c}`}
              </button>
            ))}
          </div>
        </div>

        {/* Category & Status Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/60 text-xs">
          {/* Status Buttons */}
          <div className="flex items-center space-x-1.5">
            <span className="text-[11px] text-slate-400 font-medium">दशा:</span>
            {[
              { id: 'all', label: 'सभी' },
              { id: 'unmastered', label: 'दोबारा देखें' },
              { id: 'mastered', label: 'समझ लिया ✅' },
            ].map((st) => (
              <button
                key={st.id}
                onClick={() => setFilterStatus(st.id as any)}
                className={`px-2 py-0.5 rounded-md text-[11px] font-semibold transition-all ${
                  filterStatus === st.id
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>

          {/* Category Dropdown if available */}
          {categories.length > 0 && (
            <div className="flex items-center space-x-1.5 ml-auto">
              <span className="text-[11px] text-slate-400">विषय:</span>
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-lg px-2 py-1 focus:outline-none focus:border-indigo-500 max-w-[180px] truncate"
              >
                <option value="all">सभी श्रेणियाँ ({categories.length})</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* 3. Main Flashcard Section */}
      {filteredCards.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-3">
          <BookOpen className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white">कोई फ्लैशकार्ड नहीं मिला</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            आपके चुने हुए फ़िल्टर या खोज के अनुसार कोई शब्द उपलब्ध नहीं है। कृपया फ़िल्टर रीसेट करें।
          </p>
          <button
            onClick={() => {
              setFilterClass('all');
              setFilterCategory('all');
              setFilterStatus('all');
              setSearchQuery('');
            }}
            className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold"
          >
            फ़िल्टर रीसेट करें
          </button>
        </div>
      ) : viewMode === 'drill' ? (
        /* Single Card Drill Mode with Tactile Flip */
        <div className="space-y-4">
          {/* Card Meta Indicator */}
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span className="font-semibold text-slate-300">
              कार्ड <span className="text-amber-400 font-bold">{currentIndex + 1}</span> / {filteredCards.length}
            </span>
            <div className="flex items-center space-x-2">
              <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full text-[10px] font-bold">
                कक्षा {activeCard?.classGrade}
              </span>
              <span className="bg-slate-800 text-indigo-300 px-2 py-0.5 rounded-full text-[10px] font-bold">
                {activeCard?.category}
              </span>
            </div>
          </div>

          {/* Interactive Card */}
          <div
            onClick={() => setIsFlipped(!isFlipped)}
            className={`cursor-pointer select-none relative min-h-[300px] sm:min-h-[320px] rounded-3xl p-6 sm:p-8 transition-all duration-300 transform active:scale-[0.99] shadow-2xl flex flex-col justify-between border ${
              isDarkMode ? '' : 'shadow-indigo-500/10'
            }`}
            style={{
              background: isDarkMode
                ? (isFlipped
                    ? 'linear-gradient(135deg, #091e3a 0%, #0f172a 100%)'
                    : 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%)')
                : (isFlipped
                    ? 'linear-gradient(135deg, #eff6ff 0%, #e0e7ff 100%)'
                    : 'linear-gradient(135deg, #ffffff 0%, #f5f3ff 100%)'),
              borderColor: isDarkMode
                ? (isFlipped ? '#3b82f6' : '#6366f1')
                : (isFlipped ? '#60a5fa' : '#818cf8'),
            }}
          >
            {/* Top Status & Controls */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full flex items-center space-x-1 ${
                  isFlipped 
                    ? (isDarkMode ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' : 'bg-blue-100 text-blue-800 border border-blue-300')
                    : (isDarkMode ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : 'bg-indigo-100 text-indigo-800 border border-indigo-300')
                }`}>
                  <RotateCw className="w-3 h-3 animate-spin-slow" />
                  <span>{isFlipped ? 'परिभाषा (Back)' : 'शब्दावली (Front)'}</span>
                </span>
                
                {isCurrentMastered && (
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center space-x-1 ${
                    isDarkMode ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  }`}>
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                    <span>याद हो गया</span>
                  </span>
                )}
              </div>

              {/* English Speech Button */}
              {activeCard && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSpeakTerm(activeCard.term);
                  }}
                  className={`p-2 rounded-xl transition-colors ${
                    isDarkMode ? 'bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700' : 'bg-white/90 text-slate-700 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 shadow-sm'
                  }`}
                  title="उच्चारण सुनें (Listen Pronunciation)"
                >
                  <Volume2 className="w-4 h-4 text-amber-500" />
                </button>
              )}
            </div>

            {/* Main Card Content */}
            {!isFlipped ? (
              /* FRONT: The Technical Term */
              <div className="py-6 text-center space-y-3">
                <p className={`text-xs font-bold uppercase tracking-widest ${
                  isDarkMode ? 'text-indigo-300' : 'text-indigo-600 font-extrabold'
                }`}>
                  TECHNICAL TERM • शब्दावली
                </p>
                <h2 className={`text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight leading-tight ${
                  isDarkMode ? 'text-white' : 'text-slate-900'
                }`}>
                  {activeCard?.term}
                </h2>
                <div className={`inline-block border px-3 py-1 rounded-xl text-xs font-semibold ${
                  isDarkMode 
                    ? 'bg-slate-900/80 border-slate-700/80 text-amber-300' 
                    : 'bg-white border-amber-300 text-amber-800 shadow-sm'
                }`}>
                  {activeCard?.hindiMeaning}
                </div>
                <div className={`pt-4 flex items-center justify-center space-x-1.5 text-xs ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-500 font-medium'
                }`}>
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>कार्ड पर कहीं भी क्लिक करें या <kbd className={`px-1.5 py-0.5 rounded text-[10px] ${
                    isDarkMode ? 'bg-slate-800 text-slate-200' : 'bg-slate-200 text-slate-700 border border-slate-300'
                  }`}>Space</kbd> दबाकर उत्तर देखें</span>
                </div>
              </div>
            ) : (
              /* BACK: Simple Hindi Definition, Real-life Analogy & Exam Tip */
              <div className="py-3 space-y-3.5 text-left animate-fadeIn">
                <div className={`border-b pb-2 ${isDarkMode ? 'border-slate-800' : 'border-blue-200'}`}>
                  <h3 className={`text-lg sm:text-xl font-bold flex items-center space-x-2 ${
                    isDarkMode ? 'text-white' : 'text-slate-900'
                  }`}>
                    <span className={`${isDarkMode ? 'text-blue-400' : 'text-blue-700'} font-mono font-black`}>{activeCard?.term}</span>
                    <span className={`text-xs font-normal ${isDarkMode ? 'text-amber-300' : 'text-amber-800 font-bold'}`}>({activeCard?.hindiMeaning})</span>
                  </h3>
                </div>

                {/* Explanation */}
                <div className={`border rounded-2xl p-3 sm:p-4 space-y-1 ${
                  isDarkMode ? 'bg-slate-900/90 border-slate-800 text-slate-200' : 'bg-white border-blue-200 text-slate-800 shadow-sm'
                }`}>
                  <h4 className={`text-[11px] font-bold uppercase tracking-wider ${
                    isDarkMode ? 'text-blue-300' : 'text-blue-700'
                  }`}>
                    सरल हिंदी व्याख्या:
                  </h4>
                  <p className="text-xs sm:text-sm leading-relaxed">
                    {activeCard?.explanationHindi}
                  </p>
                </div>

                {/* Analogy if available */}
                {activeCard?.exampleOrAnalogy && (
                  <div className={`border rounded-2xl p-3 flex items-start space-x-2.5 ${
                    isDarkMode ? 'bg-amber-950/20 border-amber-500/30' : 'bg-amber-50 border-amber-200 shadow-sm'
                  }`}>
                    <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <span className={`text-[11px] font-bold ${isDarkMode ? 'text-amber-300' : 'text-amber-800'}`}>दैनिक जीवन से उदाहरण: </span>
                      <span className={`text-xs ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>{activeCard.exampleOrAnalogy}</span>
                    </div>
                  </div>
                )}

                {/* Exam Tip if available */}
                {activeCard?.examTip && (
                  <div className={`border rounded-2xl p-2.5 flex items-start space-x-2 text-xs ${
                    isDarkMode ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-emerald-50 border-emerald-200 shadow-sm'
                  }`}>
                    <GraduationCap className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <div>
                      <span className={`font-bold ${isDarkMode ? 'text-emerald-300' : 'text-emerald-800'}`}>BSEB परीक्षा टिप: </span>
                      <span className={isDarkMode ? 'text-slate-300' : 'text-slate-700'}>{activeCard.examTip}</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Bottom Card Footer Actions */}
            <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (activeCard) onAskAI(activeCard.term);
                }}
                className="flex items-center space-x-1 text-indigo-300 hover:text-white transition-colors"
                title="AI शिक्षक से इस शब्द को विस्तार से समझें"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[11px]">AI से विस्तार में पूछें</span>
              </button>

              {activeCard && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleMastered(activeCard.id);
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1 rounded-xl font-bold transition-all ${
                    isCurrentMastered
                      ? 'bg-emerald-600 text-white shadow'
                      : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
                  }`}
                >
                  {isCurrentMastered ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                      <span>याद हो गया (Mastered)</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />
                      <span>याद चिह्नित करें</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Drill Controller Toolbar */}
          <div className="flex items-center justify-between gap-2 pt-2">
            <button
              onClick={handlePrev}
              className={`flex items-center space-x-1 px-4 py-2 border rounded-xl text-xs font-bold transition-all active:scale-95 shadow-sm ${
                isDarkMode 
                  ? 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-200' 
                  : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
              }`}
              title="पिछला कार्ड (Previous)"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>पिछला</span>
            </button>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => setIsFlipped(!isFlipped)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-md active:scale-95 flex items-center space-x-1.5"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>{isFlipped ? 'आगे देखें' : 'पलटें (Flip)'}</span>
              </button>

              <button
                onClick={handleShuffle}
                className={`p-2 border rounded-xl text-xs transition-all active:scale-95 ${
                  isDarkMode 
                    ? 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white' 
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-sm'
                }`}
                title="रैंडम क्रम (Shuffle)"
              >
                <Shuffle className="w-4 h-4 text-amber-500" />
              </button>

              <button
                onClick={() => setIsAutoPlaying(!isAutoPlaying)}
                className={`p-2 rounded-xl text-xs transition-all active:scale-95 border ${
                  isAutoPlaying
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                    : isDarkMode 
                      ? 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-sm'
                }`}
                title={isAutoPlaying ? 'स्लाइडशो रोकें' : 'स्वतः स्लाइडशो (Auto-play)'}
              >
                {isAutoPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 text-blue-600" />}
              </button>
            </div>

            <button
              onClick={handleNext}
              className={`flex items-center space-x-1 px-4 py-2 border rounded-xl text-xs font-bold transition-all active:scale-95 shadow-sm ${
                isDarkMode 
                  ? 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-200' 
                  : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
              }`}
              title="अगला कार्ड (Next)"
            >
              <span>अगला</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* Grid / Glossary View of All Filtered Cards */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredCards.map((card) => {
            const isMastered = masteredIds.includes(card.id);
            return (
              <div
                key={card.id}
                className={`p-4 rounded-2xl border transition-all space-y-2.5 ${
                  isMastered
                    ? (isDarkMode ? 'bg-slate-950 border-emerald-500/30' : 'bg-emerald-50/60 border-emerald-300 shadow-sm')
                    : (isDarkMode ? 'bg-slate-900 border-slate-800 hover:border-indigo-500/50' : 'bg-white border-slate-200 shadow-sm hover:border-indigo-400')
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      isDarkMode ? 'text-indigo-400 bg-slate-800' : 'text-indigo-700 bg-indigo-50 border border-indigo-200'
                    }`}>
                      कक्षा {card.classGrade} • {card.category}
                    </span>
                    <h3 className={`text-sm font-black mt-1 ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                      {card.term}
                    </h3>
                    <p className={`text-xs font-medium ${isDarkMode ? 'text-amber-300' : 'text-amber-800 font-bold'}`}>{card.hindiMeaning}</p>
                  </div>

                  <button
                    onClick={() => onToggleMastered(card.id)}
                    className={`p-1.5 rounded-lg text-xs font-bold transition-colors ${
                      isMastered
                        ? (isDarkMode ? 'text-emerald-400 bg-emerald-500/10' : 'text-emerald-700 bg-emerald-100')
                        : (isDarkMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-400 hover:text-slate-900 hover:bg-slate-100')
                    }`}
                    title={isMastered ? 'याद हो गया' : 'याद चिह्नित करें'}
                  >
                    <CheckCircle2 className={`w-5 h-5 ${isMastered ? 'text-emerald-500' : 'text-slate-400'}`} />
                  </button>
                </div>

                <p className={`text-xs leading-relaxed p-2.5 rounded-xl border ${
                  isDarkMode ? 'text-slate-300 bg-slate-950/60 border-slate-800/60' : 'text-slate-700 bg-slate-50 border-slate-200'
                }`}>
                  {card.explanationHindi}
                </p>

                {card.exampleOrAnalogy && (
                  <p className={`text-[11px] italic ${isDarkMode ? 'text-amber-200/90' : 'text-amber-900 font-medium'}`}>
                    💡 {card.exampleOrAnalogy}
                  </p>
                )}

                <div className={`flex items-center justify-between pt-1 border-t text-[11px] ${
                  isDarkMode ? 'border-slate-800' : 'border-slate-200'
                }`}>
                  <button
                    onClick={() => handleSpeakTerm(card.term)}
                    className={`${isDarkMode ? 'text-slate-400 hover:text-white' : 'text-slate-600 hover:text-slate-900'} flex items-center space-x-1`}
                  >
                    <Volume2 className="w-3.5 h-3.5 text-amber-500" />
                    <span>उच्चारण</span>
                  </button>
                  <button
                    onClick={() => onAskAI(card.term)}
                    className="text-blue-400 hover:text-blue-300 flex items-center space-x-1"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>AI से समझें</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
