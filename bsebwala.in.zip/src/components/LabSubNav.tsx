import React from 'react';
import { Code2, Database, Gamepad2, Network } from 'lucide-react';

interface LabSubNavProps {
  currentTab: string;
  onNavigateTab: (tab: string) => void;
}

export const LabSubNav: React.FC<LabSubNavProps> = ({ currentTab, onNavigateTab }) => {
  const labs = [
    { id: 'cpp-lab', label: 'C++ कोडिंग लैब', icon: Code2, desc: 'कंपाइलर व प्रीसेट' },
    { id: 'sql-lab', label: 'SQL डेटाबेस लैब', icon: Database, desc: 'STUDENT डेटाबेस' },
    { id: 'games', label: 'प्रोग्रामिंग खेल (4)', icon: Gamepad2, desc: 'इवेंट गेम्स' },
    { id: 'networking', label: 'नेटवर्किंग आरेख', icon: Network, desc: 'टोपोलॉजी व पैकेट्स' },
  ];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-1.5 shadow-md mb-5 overflow-x-auto no-scrollbar">
      <div className="flex items-center space-x-1.5 min-w-max sm:min-w-0 sm:grid sm:grid-cols-4">
        {labs.map((lab) => {
          const Icon = lab.icon;
          const isActive = currentTab === lab.id;
          return (
            <button
              key={lab.id}
              onClick={() => onNavigateTab(lab.id)}
              className={`flex items-center space-x-2 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <div className="text-left truncate">
                <span className="block">{lab.label}</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
