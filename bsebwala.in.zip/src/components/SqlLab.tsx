import React, { useState, useMemo } from 'react';
import { 
  Database, 
  Play, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle, 
  Table as TableIcon, 
  Sparkles, 
  HelpCircle,
  Clock,
  Layers,
  FileCode
} from 'lucide-react';
import { ClientSqlEngine, bsebSqlExercises, SqlResult } from '../utils/sqlEngine';
import { incrementLabCount } from '../utils/storage';

interface SqlLabProps {
  onAskAIAboutSql: (query: string) => void;
}

export const SqlLab: React.FC<SqlLabProps> = ({ onAskAIAboutSql }) => {
  const engine = useMemo(() => new ClientSqlEngine(), []);
  const [query, setQuery] = useState<string>('SELECT * FROM STUDENT;');
  const [result, setResult] = useState<SqlResult | null>(null);
  const [selectedExerciseId, setSelectedExerciseId] = useState<string>('sql-1');
  const [tableRefreshTrigger, setTableRefreshTrigger] = useState<number>(0);

  // Get current state of tables
  const currentStudentTable = engine.getTableData('STUDENT');
  const tableNames = engine.getTableList();

  const handleExecute = (overrideQuery?: string) => {
    const q = overrideQuery || query;
    const res = engine.execute(q);
    setResult(res);
    setTableRefreshTrigger((prev) => prev + 1);
    incrementLabCount('sql');
  };

  const handleSelectExercise = (id: string) => {
    const ex = bsebSqlExercises.find((e) => e.id === id);
    if (ex) {
      setSelectedExerciseId(id);
      setQuery(ex.query);
      handleExecute(ex.query);
    }
  };

  const handleResetDatabase = () => {
    engine.reset();
    setQuery('SELECT * FROM STUDENT;');
    setResult(null);
    setTableRefreshTrigger((prev) => prev + 1);
  };

  const currentExercise = bsebSqlExercises.find((e) => e.id === selectedExerciseId);

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                इंटरैक्टिव SQL क्वेरी लैब
              </span>
              <span className="text-xs text-slate-400">कक्षा 11 व 12 RDBMS पाठ्यक्रम</span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1">Interactive SQL Database Lab</h1>
            <p className="text-sm text-slate-300 mt-1">
              वास्तविक रिलेशनल डेटाबेस पर SQL क्वेरी लिखें और लाइव परिणाम देखें। गलतियों की व्याख्या सरल हिंदी में प्राप्त करें।
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleResetDatabase}
              className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-2 rounded-xl text-xs font-semibold border border-slate-700 transition-all active:scale-95"
              title="डेटाबेस को मूल 4 छात्रों पर रीसेट करें"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>डेटाबेस रीसेट करें</span>
            </button>
            <button
              onClick={() => onAskAIAboutSql(query)}
              className="flex items-center space-x-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-md shadow-blue-600/30 transition-all active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>AI से क्वेरी समझें</span>
            </button>
          </div>
        </div>

        {/* 12 Practical Exercise Quick Selector */}
        <div className="mt-4 pt-4 border-t border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-slate-400">
              बिहार बोर्ड के 12 महत्वपूर्ण SQL अभ्यास (क्लिक करके तुरंत चलाएँ):
            </label>
            <span className="text-[11px] text-blue-400">DML, DDL & Aggregate Functions</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
            {bsebSqlExercises.map((ex) => (
              <button
                key={ex.id}
                onClick={() => handleSelectExercise(ex.id)}
                className={`p-2 rounded-xl text-left border transition-all text-xs ${
                  selectedExerciseId === ex.id
                    ? 'bg-indigo-600/30 border-indigo-500 text-indigo-300 font-bold'
                    : 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:bg-slate-750 hover:text-white'
                }`}
              >
                <div className="truncate font-semibold">{ex.titleHindi}</div>
                <div className="text-[10px] text-slate-400 truncate mt-0.5">{ex.concept}</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Grid: Query Editor & Live Database Table State */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Query Editor & Results (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Query Editor Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-slate-850 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
                <FileCode className="w-4 h-4 text-indigo-400" />
                <span>SQL Query Editor</span>
              </div>
              <button
                onClick={() => handleExecute()}
                className="bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold px-4 py-1.5 rounded-lg text-xs flex items-center space-x-1.5 shadow-md shadow-indigo-600/30 transition-all"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>क्वेरी चलाएँ (Execute)</span>
              </button>
            </div>

            <div className="p-3 bg-slate-950">
              <textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                rows={4}
                className="w-full bg-transparent text-cyan-300 font-mono text-sm leading-relaxed focus:outline-none resize-none selection:bg-indigo-600"
                placeholder="यहाँ अपनी SQL क्वेरी टाइप करें (उदा: SELECT * FROM STUDENT;)"
                spellCheck={false}
              />
            </div>

            {/* Exercise Hindi Guidance if selected */}
            {currentExercise && (
              <div className="bg-slate-850/80 px-4 py-2.5 border-t border-slate-800 text-xs text-slate-300 flex items-start space-x-2">
                <HelpCircle className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-white">{currentExercise.titleHindi}: </span>
                  <span>{currentExercise.explanationHindi}</span>
                </div>
              </div>
            )}
          </div>

          {/* Query Results Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-slate-850 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
                <TableIcon className="w-4 h-4 text-emerald-400" />
                <span>क्वेरी का परिणाम (Query Output)</span>
              </div>
              {result && (
                <div className="flex items-center space-x-3 text-[11px] text-slate-400 font-mono">
                  <span>{result.rowCount} Rows</span>
                  <span className="flex items-center space-x-1">
                    <Clock className="w-3 h-3 text-slate-500" />
                    <span>{result.executionTimeMs}ms</span>
                  </span>
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-950 min-h-[200px] overflow-x-auto text-xs">
              {result ? (
                <div>
                  {result.success ? (
                    <div>
                      <div className="flex items-center space-x-2 text-emerald-400 font-medium mb-3">
                        <CheckCircle2 className="w-4 h-4 shrink-0" />
                        <span>{result.messageHindi}</span>
                      </div>

                      {result.columns.length > 0 && (
                        <div className="border border-slate-800 rounded-xl overflow-hidden shadow-inner">
                          <table className="w-full text-left font-mono border-collapse">
                            <thead>
                              <tr className="bg-slate-800/80 text-indigo-300 border-b border-slate-700">
                                {result.columns.map((col, idx) => (
                                  <th key={idx} className="p-2.5 font-bold uppercase tracking-wider text-[11px]">
                                    {col}
                                  </th>
                                ))}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800/80">
                              {result.rows.length > 0 ? (
                                result.rows.map((row, rIdx) => (
                                  <tr key={rIdx} className="hover:bg-slate-900/60 transition-colors">
                                    {row.map((val, cIdx) => (
                                      <td key={cIdx} className="p-2.5 text-slate-200">
                                        {val !== null ? String(val) : <span className="text-slate-600 italic">NULL</span>}
                                      </td>
                                    ))}
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan={result.columns.length} className="p-4 text-center text-slate-500 italic">
                                    कोई पंक्ति (Row) मेल नहीं खाई।
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="bg-rose-950/40 border border-rose-800/50 rounded-xl p-4 text-rose-300 space-y-2">
                      <div className="flex items-center space-x-2 font-bold text-rose-400">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{result.messageHindi}</span>
                      </div>
                      <p className="text-xs leading-relaxed text-rose-200 bg-rose-900/30 p-2.5 rounded">
                        👉 {result.errorHindi}
                      </p>
                      <p className="text-[11px] text-rose-400/80">
                        सुझाव: सुनिश्चित करें कि टेबल का नाम (STUDENT) सही है और कॉलम के नाम (Roll_No, Name, Class, Marks) में कोई स्पेलिंग मिस्टेक नहीं है।
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-slate-500 text-center py-12">
                  <Database className="w-8 h-8 mx-auto text-slate-600 mb-2 opacity-50" />
                  <p>क्वेरी लिखकर ऊपर "क्वेरी चलाएँ" पर क्लिक करें या किसी अभ्यास को चुनें।</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Live Table Schema & Current Rows View (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-slate-850 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
                <Layers className="w-4 h-4 text-blue-400" />
                <span>डेटाबेस में लाइव तालिका: STUDENT</span>
              </div>
              <span className="text-[10px] bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full font-bold">
                {currentStudentTable?.rows.length || 0} Records
              </span>
            </div>

            <div className="p-4 space-y-4">
              {/* Table Schema pills */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block mb-1.5 uppercase tracking-wider">
                  संरचना (Schema & Data Types):
                </span>
                <div className="grid grid-cols-2 gap-1.5 text-xs">
                  {currentStudentTable?.schema.map((col, idx) => (
                    <div key={idx} className="bg-slate-950 p-2 rounded-lg border border-slate-800 flex justify-between items-center">
                      <span className="font-mono text-cyan-300 font-semibold">{col.name}</span>
                      <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400">
                        {col.type}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Current rows snapshot */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block mb-1.5 uppercase tracking-wider">
                  वर्तमान डेटा (Current Live Rows):
                </span>
                <div className="border border-slate-800 rounded-xl overflow-x-auto bg-slate-950">
                  <table className="w-full text-left font-mono text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-900 text-slate-400 border-b border-slate-800 text-[11px]">
                        <th className="p-2 font-bold">Roll_No (PK)</th>
                        <th className="p-2 font-bold">Name</th>
                        <th className="p-2 font-bold">Class</th>
                        <th className="p-2 font-bold">Marks</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {currentStudentTable?.rows.map((r, i) => (
                        <tr key={i} className="hover:bg-slate-900/40">
                          <td className="p-2 text-indigo-400 font-bold">{r.Roll_No}</td>
                          <td className="p-2 text-slate-200">{r.Name}</td>
                          <td className="p-2 text-slate-400">{r.Class}</td>
                          <td className="p-2 text-emerald-400 font-bold">{r.Marks}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-indigo-950/30 border border-indigo-900/40 rounded-xl p-3 text-xs text-indigo-200">
                <span className="font-bold text-indigo-300 block mb-1">💡 BSEB परीक्षा टिप:</span>
                SQL में <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-300">WHERE</code> शर्त लगाने के लिए, <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-300">ORDER BY</code> क्रमबद्ध करने के लिए, और <code className="bg-slate-900 px-1 py-0.5 rounded text-cyan-300">GROUP BY</code> समूहों पर aggregate गणना करने के लिए उपयोग किया जाता है।
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
