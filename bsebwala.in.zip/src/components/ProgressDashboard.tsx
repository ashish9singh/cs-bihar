import React from 'react';
import { 
  BarChart3, 
  CheckCircle2, 
  Flame, 
  Award, 
  BookOpen, 
  RotateCcw, 
  AlertCircle, 
  Sparkles,
  ShieldCheck,
  ChevronRight,
  Code2,
  Database
} from 'lucide-react';
import { StudentProgress, Chapter } from '../types';

interface ProgressDashboardProps {
  progress: StudentProgress;
  allChapters: Chapter[];
  onSelectChapter: (id: string) => void;
  onResetProgress: () => void;
}

export const ProgressDashboard: React.FC<ProgressDashboardProps> = ({
  progress,
  allChapters,
  onSelectChapter,
  onResetProgress,
}) => {
  const totalChapters = allChapters.length;
  const completedCount = progress.completedChapterIds.length;
  const completionPercentage = totalChapters > 0 ? Math.round((completedCount / totalChapters) * 100) : 0;

  // Calculate quiz statistics
  const quizEntries = Object.entries(progress.quizScores);
  let totalScore = 0;
  let totalPossible = 0;
  const revisionChapters: { title: string; score: number; total: number; id: string }[] = [];

  quizEntries.forEach(([chId, data]) => {
    totalScore += data.score;
    totalPossible += data.total;
    const pct = data.total > 0 ? (data.score / data.total) * 100 : 0;
    if (pct < 70) {
      const ch = allChapters.find((c) => c.id === chId);
      revisionChapters.push({
        id: chId,
        title: ch ? ch.titleHindi : chId,
        score: data.score,
        total: data.total,
      });
    }
  });

  const averageQuizAccuracy = totalPossible > 0 ? Math.round((totalScore / totalPossible) * 100) : 0;

  // Badges logic
  const badges = [
    {
      id: 'b1',
      title: 'कंप्यूटर सम्राट (First Step)',
      desc: 'कम से कम 1 पाठ सफलतापूर्वक पूर्ण किया',
      unlocked: completedCount >= 1,
      icon: '🏆',
    },
    {
      id: 'b2',
      title: 'C++ शुरुआत (C++ Pioneer)',
      desc: 'C++ लैब में कम से कम 3 बार प्रोग्राम चलाए',
      unlocked: (progress.cppRunCount || 0) >= 3,
      icon: '💻',
    },
    {
      id: 'b3',
      title: 'SQL मास्टर (SQL Master)',
      desc: 'SQL लैब में कम से कम 3 क्वेरी चलाईं',
      unlocked: (progress.sqlRunCount || 0) >= 3,
      icon: '🗄️',
    },
    {
      id: 'b4',
      title: 'नियमित अभ्यासी (Consistent Learner)',
      desc: '3 या अधिक दिनों की अध्ययन निरंतरता',
      unlocked: progress.streakDays >= 3,
      icon: '🔥',
    },
    {
      id: 'b5',
      title: 'बोर्ड परीक्षा टॉपर (Board Ready)',
      desc: 'क्विज में 80% से अधिक औसत अंक',
      unlocked: averageQuizAccuracy >= 80 && quizEntries.length >= 2,
      icon: '🌟',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">
                व्यक्तिगत अध्ययन रिपोर्ट
              </span>
              <span className="text-xs text-slate-400">Bihar Board Student Tracker</span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1">My Learning Progress</h1>
            <p className="text-sm text-slate-300 mt-1">
              पाठ्यक्रम पूर्णता, क्विज प्रदर्शन, अर्जित बैज एवं पुनरावृत्ति (Revision) हेतु कमजोर विषयों का विश्लेषण।
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onResetProgress}
              className="text-xs text-slate-400 hover:text-white px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 flex items-center space-x-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>प्रगति रीसेट करें</span>
            </button>
          </div>
        </div>

        {/* Local Storage Privacy Note */}
        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center space-x-2 text-xs text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            गोपनीयता सूचना: आपकी प्रगति आपके ब्राउज़र (Local Storage) में सुरक्षित रूप से सेव है। कोई भी व्यक्तिगत डेटा सर्वर पर नहीं भेजा जाता।
          </span>
        </div>
      </div>

      {/* Top Key Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Streak */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 shrink-0">
            <Flame className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase">अध्ययन निरंतरता</span>
            <div className="text-xl sm:text-2xl font-black text-white">{progress.streakDays} दिन</div>
            <span className="text-[10px] text-amber-300">दैनिक अध्ययन जारी रखें</span>
          </div>
        </div>

        {/* Completed Chapters */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-500/30 shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase">पूर्ण किए पाठ</span>
            <div className="text-xl sm:text-2xl font-black text-white">
              {completedCount} / {totalChapters}
            </div>
            <span className="text-[10px] text-blue-300">{completionPercentage}% सिलेबस पूरा</span>
          </div>
        </div>

        {/* Quiz Accuracy */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 shrink-0">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase">क्विज औसत सटीकता</span>
            <div className="text-xl sm:text-2xl font-black text-white">{averageQuizAccuracy}%</div>
            <span className="text-[10px] text-emerald-300">{quizEntries.length} टेस्ट पूर्ण</span>
          </div>
        </div>

        {/* Lab Runs */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30 shrink-0">
            <Code2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase">लैब निष्पादन</span>
            <div className="text-xl sm:text-2xl font-black text-white">
              {(progress.cppRunCount || 0) + (progress.sqlRunCount || 0)} बार
            </div>
            <span className="text-[10px] text-indigo-300">C++: {progress.cppRunCount || 0} | SQL: {progress.sqlRunCount || 0}</span>
          </div>
        </div>
      </div>

      {/* Syllabus Progress Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-2">
        <div className="flex justify-between items-center text-xs font-bold">
          <span className="text-white flex items-center space-x-1.5">
            <BookOpen className="w-4 h-4 text-blue-400" />
            <span>कुल पाठ्यक्रम पूर्णता (Overall Syllabus Completion)</span>
          </span>
          <span className="text-blue-400">{completionPercentage}%</span>
        </div>
        <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
          <div
            className="bg-gradient-to-r from-blue-600 to-cyan-400 h-full rounded-full transition-all duration-500"
            style={{ width: `${completionPercentage}%` }}
          />
        </div>
      </div>

      {/* Two Column Grid: Weak Topics & Earned Badges */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Weak Topics Requiring Revision */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-base flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-amber-400" />
              <span>पुनरावृत्ति हेतु विषय (Topics Requiring Revision)</span>
            </h3>
            <span className="text-[11px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
              {revisionChapters.length} विषय
            </span>
          </div>

          {revisionChapters.length > 0 ? (
            <div className="space-y-2.5">
              <p className="text-xs text-slate-400">
                इन अध्यायों के क्विज में आपका प्राप्तांक 70% से कम रहा है। परीक्षा से पूर्व इनका पुनः अभ्यास अवश्य करें:
              </p>
              {revisionChapters.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => onSelectChapter(item.id)}
                  className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between cursor-pointer hover:border-blue-500/60 transition-all"
                >
                  <div>
                    <span className="text-xs font-bold text-slate-200 block">{item.title}</span>
                    <span className="text-[10px] text-rose-400">
                      अंक: {item.score}/{item.total} ({(item.score / item.total * 100).toFixed(0)}%)
                    </span>
                  </div>
                  <button className="text-xs text-blue-400 hover:text-blue-300 flex items-center space-x-1">
                    <span>दोहराएँ</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 text-center text-xs text-slate-400">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-70" />
              <p className="font-bold text-slate-200">बहुत बढ़िया! कोई भी कमजोर विषय नहीं है।</p>
              <p className="text-[11px] text-slate-500 mt-1">
                आपने सभी अध्यायों में 70% से अधिक अंक प्राप्त किए हैं।
              </p>
            </div>
          )}
        </div>

        {/* Right: Badges & Achievements */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-base flex items-center space-x-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span>उपलब्धियाँ एवं बैज (Achievements)</span>
            </h3>
            <span className="text-[11px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
              {badges.filter((b) => b.unlocked).length} / {badges.length} अनलॉक
            </span>
          </div>

          <div className="space-y-2.5">
            {badges.map((b) => (
              <div
                key={b.id}
                className={`p-3 rounded-xl border flex items-center space-x-3 transition-all ${
                  b.unlocked
                    ? 'bg-slate-950 border-amber-500/40 shadow-sm'
                    : 'bg-slate-950/40 border-slate-800/60 opacity-50'
                }`}
              >
                <div className="text-2xl shrink-0">{b.icon}</div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-white">{b.title}</span>
                    {b.unlocked && (
                      <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-bold uppercase">
                        अनलॉक
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">{b.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
