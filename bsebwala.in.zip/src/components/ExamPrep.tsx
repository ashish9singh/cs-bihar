import React, { useState, useEffect } from 'react';
import { 
  Award, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  FileText, 
  Sparkles, 
  HelpCircle, 
  Check, 
  X, 
  RotateCcw,
  BookOpen,
  ChevronDown,
  Layers,
  Info
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { bsebExamPapers } from '../data/examPrepData';
import { BoardExamPaper } from '../types';
import { recordQuizScore } from '../utils/storage';

export const ExamPrep: React.FC = () => {
  const [selectedPaperId, setSelectedPaperId] = useState<string>(bsebExamPapers[0].id);
  const [activeSection, setActiveSection] = useState<'blueprint' | 'objective-omr' | 'subjective-short' | 'subjective-long' | 'topper-tips'>('blueprint');
  
  // OMR Test State
  const [omrAnswers, setOmrAnswers] = useState<Record<string, number>>({});
  const [isTestSubmitted, setIsTestSubmitted] = useState<boolean>(false);
  const [timerSeconds, setTimerSeconds] = useState<number>(15 * 60); // 15 mins for practice
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [revealedAnswers, setRevealedAnswers] = useState<Record<string, boolean>>({});

  const currentPaper = bsebExamPapers.find((p) => p.id === selectedPaperId) || bsebExamPapers[0];

  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning && timerSeconds > 0 && !isTestSubmitted) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev - 1);
      }, 1000);
    } else if (timerSeconds === 0 && !isTestSubmitted) {
      handleSubmitOMR();
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds, isTestSubmitted]);

  const handleSelectPaper = (id: string) => {
    setSelectedPaperId(id);
    setOmrAnswers({});
    setIsTestSubmitted(false);
    setIsTimerRunning(false);
    setTimerSeconds(15 * 60);
    setRevealedAnswers({});
  };

  const handleSelectOMROption = (qId: string, optIdx: number) => {
    if (isTestSubmitted) return;
    if (!isTimerRunning) setIsTimerRunning(true);
    setOmrAnswers((prev) => ({ ...prev, [qId]: optIdx }));
  };

  const handleSubmitOMR = () => {
    setIsTestSubmitted(true);
    setIsTimerRunning(false);

    let correct = 0;
    currentPaper.objectiveQuestions.forEach((q) => {
      if (omrAnswers[q.id] === q.correctIndex) correct++;
    });

    recordQuizScore(currentPaper.id, correct, currentPaper.objectiveQuestions.length);

    if (correct >= Math.ceil(currentPaper.objectiveQuestions.length * 0.7)) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleResetOMR = () => {
    setOmrAnswers({});
    setIsTestSubmitted(false);
    setTimerSeconds(15 * 60);
    setIsTimerRunning(false);
  };

  const toggleRevealAnswer = (key: string) => {
    setRevealedAnswers((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Format timer
  const minutes = Math.floor(timerSeconds / 60);
  const seconds = timerSeconds % 60;
  const timeFormatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const correctCount = currentPaper.objectiveQuestions.filter(
    (q) => omrAnswers[q.id] === q.correctIndex
  ).length;

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                बिहार बोर्ड परीक्षा तैयारी केंद्र
              </span>
              <span className="text-xs text-slate-400">BSEB Class 11 & 12 Computer Science</span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1">Board Examination Hub</h1>
            <p className="text-sm text-slate-300 mt-1">
              आधिकारिक PYQ, मॉडल पेपर्स, OMR शीट सिमुलेटर एवं विषयनिष्ठ प्रश्नों के आदर्श उत्तर।
            </p>
          </div>
        </div>

        {/* Paper Selector Pills */}
        <div className="mt-4 pt-4 border-t border-slate-800">
          <label className="text-xs font-semibold text-slate-400 block mb-2">
            प्रश्न पत्र चुनें (Verified Previous Years & Official Model Sets):
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {bsebExamPapers.map((paper) => (
              <button
                key={paper.id}
                onClick={() => handleSelectPaper(paper.id)}
                className={`p-3 rounded-xl text-left border transition-all text-xs ${
                  selectedPaperId === paper.id
                    ? 'bg-blue-600/30 border-blue-500 text-blue-200 font-bold shadow-md'
                    : 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:bg-slate-750 hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                    paper.type === 'pyq'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : paper.type === 'model_paper'
                      ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}>
                    {paper.type === 'pyq' ? 'सत्यापित पूर्व वर्ष (PYQ)' : paper.type === 'model_paper' ? 'आधिकारिक मॉडल पेपर' : 'AI अभ्यास सेट'}
                  </span>
                  <span className="text-slate-400 font-mono text-[11px]">{paper.session}</span>
                </div>
                <div className="font-bold text-sm text-white line-clamp-1">{paper.title}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  कुल अंक: {paper.totalMarks} (सैद्धांतिक 70 + प्रायोगिक 30)
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Section Navigation */}
        <div className="flex space-x-2 mt-4 pt-4 border-t border-slate-800 overflow-x-auto no-scrollbar">
          {[
            { id: 'blueprint', label: '1. परीक्षा पैटर्न व अंक विभाजन', icon: Layers },
            { id: 'objective-omr', label: '2. खंड-अ: OMR शीट सिमुलेटर (Objective)', icon: Award },
            { id: 'subjective-short', label: '3. खंड-ब: लघु उत्तरीय (2 अंक)', icon: FileText },
            { id: 'subjective-long', label: '4. खंड-स: दीर्घ उत्तरीय (5 अंक)', icon: BookOpen },
            { id: 'topper-tips', label: '5. टॉपर टिप्स (Topper Strategies)', icon: Sparkles },
          ].map((sec) => {
            const Icon = sec.icon;
            const isActive = activeSection === sec.id;
            return (
              <button
                key={sec.id}
                onClick={() => setActiveSection(sec.id as any)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-750 hover:text-white border border-slate-700/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{sec.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* SECTION 1: BLUEPRINT */}
      {activeSection === 'blueprint' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
            <div>
              <h2 className="text-xl font-bold text-white">BSEB Computer Science परीक्षा पैटर्न एवं अंक वितरण</h2>
              <p className="text-xs text-slate-400 mt-1">
                स्रोत: {currentPaper.officialSource || 'बिहार विद्यालय परीक्षा समिति, पटना'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <span className="text-[11px] font-bold text-blue-400 block uppercase">सैद्धांतिक परीक्षा</span>
                <span className="text-2xl font-black text-white mt-1 block">70 अंक</span>
                <span className="text-xs text-slate-400">समय: 3 घंटे 15 मिनट</span>
              </div>
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <span className="text-[11px] font-bold text-emerald-400 block uppercase">प्रायोगिक परीक्षा</span>
                <span className="text-2xl font-black text-white mt-1 block">30 अंक</span>
                <span className="text-xs text-slate-400">विद्यालय स्तर पर प्रैक्टिकल</span>
              </div>
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <span className="text-[11px] font-bold text-amber-400 block uppercase">कुल पूर्णांक</span>
                <span className="text-2xl font-black text-white mt-1 block">100 अंक</span>
                <span className="text-xs text-slate-400">उत्तीर्णांक: 30 अंक</span>
              </div>
            </div>

            {/* Section Breakdown Table */}
            <div className="border border-slate-800 rounded-xl overflow-x-auto bg-slate-950 text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-850 text-slate-300 font-bold border-b border-slate-800">
                  <tr>
                    <th className="p-3">खंड (Section)</th>
                    <th className="p-3">प्रश्नों के प्रकार</th>
                    <th className="p-3">कुल प्रश्न / हल करने हैं</th>
                    <th className="p-3">निर्धारित अंक</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 text-slate-300">
                  <tr>
                    <td className="p-3 font-bold text-blue-400">खंड-अ (Section A)</td>
                    <td className="p-3">वस्तुनिष्ठ प्रश्न (MCQ on OMR)</td>
                    <td className="p-3">70 में से 35 प्रश्न हल करें</td>
                    <td className="p-3 font-bold text-white">35 अंक (50%)</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-bold text-indigo-400">खंड-ब (Section B)</td>
                    <td className="p-3">लघु उत्तरीय प्रश्न (Short Answer)</td>
                    <td className="p-3">20 में से 10 प्रश्न हल करें</td>
                    <td className="p-3 font-bold text-white">20 अंक (2 x 10)</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-bold text-cyan-400">खंड-स (Section C)</td>
                    <td className="p-3">दीर्घ उत्तरीय प्रश्न (Long Answer)</td>
                    <td className="p-3">6 में से 3 प्रश्न हल करें</td>
                    <td className="p-3 font-bold text-white">15 अंक (5 x 3)</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="bg-blue-950/20 border border-blue-900/40 rounded-xl p-4 text-xs text-blue-200 space-y-1">
              <span className="font-bold text-blue-300 block mb-1">🎯 100% अंक प्राप्ति की रणनीति:</span>
              <p>• वस्तुनिष्ठ प्रश्नों में पूरे 35 में से 35 अंक आसानी से प्राप्त किए जा सकते हैं।</p>
              <p>• लघु उत्तरीय में सटीक तकनीकी शब्द (Technical keywords) को अंडरलाइन करें।</p>
              <p>• C++ प्रोग्राम्स लिखते समय इंडेंटेशन (Indentation) और सेमीकोलन का विशेष ध्यान रखें।</p>
            </div>
          </div>

          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <h3 className="font-bold text-white text-base">बोर्ड मूल्यांकन दिशानिर्देश (Marking Scheme)</h3>
            <div className="space-y-2.5 text-xs text-slate-300">
              {currentPaper.markingSchemeTips.map((tip, i) => (
                <div key={i} className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-start space-x-2">
                  <span className="text-amber-400 font-bold shrink-0">👉</span>
                  <span>{tip}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: OMR SIMULATOR */}
      {activeSection === 'objective-omr' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Questions Stream (8 cols) */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-lg font-bold text-white">वस्तुनिष्ठ प्रश्न अभ्यास (OMR Practice)</h2>
                <p className="text-xs text-slate-400">
                  {currentPaper.title} • 1 अंक प्रत्येक प्रश्न
                </p>
              </div>

              {/* Timer Bar */}
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-1.5 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 font-mono text-xs">
                  <Clock className={`w-4 h-4 ${timerSeconds < 180 ? 'text-rose-400 animate-pulse' : 'text-cyan-400'}`} />
                  <span className={timerSeconds < 180 ? 'text-rose-400 font-bold' : 'text-white'}>
                    {timeFormatted}
                  </span>
                </div>
                {isTestSubmitted && (
                  <button
                    onClick={handleResetOMR}
                    className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs flex items-center space-x-1"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>पुनः दें</span>
                  </button>
                )}
              </div>
            </div>

            {/* Questions */}
            <div className="space-y-6">
              {currentPaper.objectiveQuestions.map((q, idx) => {
                const selectedOpt = omrAnswers[q.id];
                return (
                  <div key={q.id} className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs sm:text-sm font-bold text-slate-100 flex items-start space-x-2">
                        <span className="text-blue-400 font-mono shrink-0">Q{idx + 1}.</span>
                        <span>{q.question}</span>
                      </span>
                    </div>

                    {/* Options */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      {q.options.map((opt, oIdx) => {
                        let btnStyle = 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850';

                        if (selectedOpt === oIdx) {
                          btnStyle = 'bg-blue-600/30 border-blue-500 text-blue-200 font-bold';
                        }

                        if (isTestSubmitted) {
                          if (oIdx === q.correctIndex) {
                            btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-300 font-bold';
                          } else if (selectedOpt === oIdx && oIdx !== q.correctIndex) {
                            btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-300 font-bold';
                          }
                        }

                        return (
                          <button
                            key={oIdx}
                            disabled={isTestSubmitted}
                            onClick={() => handleSelectOMROption(q.id, oIdx)}
                            className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all ${btnStyle}`}
                          >
                            <div className="flex items-center space-x-2">
                              <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 text-xs font-bold flex items-center justify-center shrink-0">
                                {String.fromCharCode(65 + oIdx)}
                              </span>
                              <span>{opt}</span>
                            </div>
                            {isTestSubmitted && oIdx === q.correctIndex && (
                              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                            )}
                            {isTestSubmitted && selectedOpt === oIdx && oIdx !== q.correctIndex && (
                              <X className="w-4 h-4 text-rose-400 shrink-0" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {isTestSubmitted && (
                      <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-1">
                        <span className="font-bold text-cyan-300">व्याख्या: </span>
                        <span>{q.explanationHindi}</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* OMR Sheet Replica (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl sticky top-24">
              <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
                <span className="font-bold text-sm text-white flex items-center space-x-1.5">
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>OMR शीट रिस्पॉन्स ग्रिड</span>
                </span>
                <span className="text-[11px] text-slate-400">
                  {Object.keys(omrAnswers).length}/{currentPaper.objectiveQuestions.length} भरे गए
                </span>
              </div>

              {/* OMR bubbles list */}
              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {currentPaper.objectiveQuestions.map((q, idx) => {
                  const filled = omrAnswers[q.id];
                  return (
                    <div key={q.id} className="flex items-center justify-between bg-slate-950 p-2 rounded-xl border border-slate-800/80">
                      <span className="text-xs font-mono text-slate-400 w-6">
                        #{idx + 1}
                      </span>
                      <div className="flex items-center space-x-1.5">
                        {[0, 1, 2, 3].map((bubbleIdx) => {
                          const isBubbleSelected = filled === bubbleIdx;
                          let bubbleClass = 'bg-slate-900 border-slate-700 text-slate-400';
                          if (isBubbleSelected) {
                            bubbleClass = 'bg-blue-600 text-white border-blue-400 font-bold';
                          }
                          if (isTestSubmitted) {
                            if (bubbleIdx === q.correctIndex) {
                              bubbleClass = 'bg-emerald-600 text-white border-emerald-400 font-bold';
                            } else if (isBubbleSelected) {
                              bubbleClass = 'bg-rose-600 text-white border-rose-400 font-bold';
                            }
                          }

                          return (
                            <button
                              key={bubbleIdx}
                              disabled={isTestSubmitted}
                              onClick={() => handleSelectOMROption(q.id, bubbleIdx)}
                              className={`w-6 h-6 rounded-full border text-[10px] flex items-center justify-center transition-all ${bubbleClass}`}
                            >
                              {String.fromCharCode(65 + bubbleIdx)}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* OMR Submit Action */}
              <div className="mt-4 pt-4 border-t border-slate-800">
                {!isTestSubmitted ? (
                  <button
                    onClick={handleSubmitOMR}
                    disabled={Object.keys(omrAnswers).length === 0}
                    className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold py-2.5 rounded-xl text-xs shadow-lg shadow-blue-600/30 transition-all active:scale-95"
                  >
                    OMR शीट जमा करें (Submit OMR)
                  </button>
                ) : (
                  <div className="text-center space-y-2">
                    <div className="text-emerald-400 font-bold text-sm">
                      प्राप्तांक: {correctCount} / {currentPaper.objectiveQuestions.length}
                    </div>
                    <p className="text-xs text-slate-400">
                      प्रतिशत: {((correctCount / currentPaper.objectiveQuestions.length) * 100).toFixed(0)}%
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: SHORT QUESTIONS (2 MARKS) */}
      {activeSection === 'subjective-short' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h2 className="text-lg font-bold text-white">खंड-ब: लघु उत्तरीय प्रश्न (Short Answer - 2 अंक)</h2>
            <p className="text-xs text-slate-400">
              परीक्षा में 20 में से 10 प्रश्नों के उत्तर देने होते हैं। शब्द सीमा: 30-50 शब्द।
            </p>
          </div>

          <div className="space-y-4">
            {currentPaper.shortQuestions.map((sq, idx) => {
              const isRevealed = revealedAnswers[`sq-${idx}`];
              return (
                <div key={idx} className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs sm:text-sm font-bold text-slate-100 flex items-center space-x-2">
                      <span className="text-cyan-400 font-mono">Q{idx + 1}.</span>
                      <span>{sq.question}</span>
                    </span>
                    <span className="text-[10px] font-bold bg-blue-500/20 text-blue-300 px-2.5 py-0.5 rounded-full border border-blue-500/30">
                      [2 अंक]
                    </span>
                  </div>

                  {isRevealed && (
                    <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-2">
                      <span className="font-bold text-emerald-400 block">आदर्श उत्तर (Model Answer):</span>
                      <p className="whitespace-pre-line">{sq.answerHindi}</p>
                    </div>
                  )}

                  <button
                    onClick={() => toggleRevealAnswer(`sq-${idx}`)}
                    className="text-xs text-blue-400 hover:text-blue-300 font-semibold transition-colors flex items-center space-x-1"
                  >
                    <span>{isRevealed ? 'उत्तर छिपाएँ' : 'आदर्श उत्तर देखें 👉'}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 4: LONG QUESTIONS (5 MARKS) */}
      {activeSection === 'subjective-long' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h2 className="text-lg font-bold text-white">खंड-स: दीर्घ उत्तरीय प्रश्न (Long Answer - 5 अंक)</h2>
            <p className="text-xs text-slate-400">
              परीक्षा में 6 में से 3 प्रश्नों के उत्तर देने होते हैं। पूरे 5 अंक प्राप्त करने के लिए कोड व आरेख अनिवार्य है।
            </p>
          </div>

          <div className="space-y-4">
            {currentPaper.longQuestions.map((lq, idx) => {
              const isRevealed = revealedAnswers[`lq-${idx}`];
              return (
                <div key={idx} className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs sm:text-sm font-bold text-slate-100 flex items-center space-x-2">
                      <span className="text-indigo-400 font-mono">Q{idx + 1}.</span>
                      <span>{lq.question}</span>
                    </span>
                    <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                      [5 अंक]
                    </span>
                  </div>

                  {isRevealed && (
                    <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-3">
                      <span className="font-bold text-emerald-400 block">विस्तृत आदर्श उत्तर:</span>
                      <p className="whitespace-pre-line">{lq.answerHindi}</p>

                      {lq.codeSnippet && (
                        <pre className="bg-slate-950 p-3 rounded-lg font-mono text-xs text-cyan-300 overflow-x-auto border border-slate-800">
                          <code>{lq.codeSnippet}</code>
                        </pre>
                      )}
                    </div>
                  )}

                  <button
                    onClick={() => toggleRevealAnswer(`lq-${idx}`)}
                    className="text-xs text-blue-400 hover:text-blue-300 font-semibold transition-colors flex items-center space-x-1"
                  >
                    <span>{isRevealed ? 'उत्तर छिपाएँ' : 'विस्तृत उत्तर व कोड देखें 👉'}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 5: TOPPER TIPS */}
      {activeSection === 'topper-tips' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h2 className="text-lg font-bold text-white flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>बिहार बोर्ड कंप्यूटर साइंस परीक्षा: टॉपर रणनीतियाँ</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm text-slate-300">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <strong className="text-cyan-300 block text-sm">1. वस्तुनिष्ठ प्रश्नों (OMR) में 35/35:</strong>
              <p>• प्रश्न को ध्यान से पढ़ें - कई बार "इनमें से कौन नहीं है?" पूछा जाता है।</p>
              <p>• पहले उन 35 प्रश्नों पर टिक लगा लें जिनके उत्तर पर 100% विश्वास हो।</p>
              <p>• OMR गोले को पूरी तरह गहरा भरें; आधा भरा गोला अमान्य हो सकता है।</p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <strong className="text-emerald-300 block text-sm">2. C++ प्रोग्रामिंग प्रश्नों में 5 अंक:</strong>
              <p>• हेडर फाइलें (`#include {'<iostream>'}`) और `main()` लिखना न भूलें।</p>
              <p>• हर स्टेटमेंट के बाद सेमीकोलन (;) की जाँच करें।</p>
              <p>• कोड के बगल में 2-3 पंक्तियों में कमेंट्स लिख देने से परीक्षक पूरे अंक देते हैं।</p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <strong className="text-amber-300 block text-sm">3. SQL एवं डेटाबेस में पूरे अंक:</strong>
              <p>• SQL कीवर्ड्स (SELECT, FROM, WHERE, ORDER BY) को बड़े अक्षरों (CAPITAL) में लिखें।</p>
              <p>• टेक्स्ट वैल्यूज को सिंगल कोट्स (`'...'`) में और नंबरों को बिना कोट्स के लिखें।</p>
              <p>• अंत में सेमीकोलन अवश्य लगाएं।</p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <strong className="text-blue-300 block text-sm">4. नेटवर्किंग के प्रश्नों में ब्लॉक डायग्राम:</strong>
              <p>• Star, Bus या Ring टोपोलॉजी पूछते ही पेन से स्वच्छ चित्र जरूर बनाएं।</p>
              <p>• LAN, MAN और WAN की सारणी (Table) बनाकर तुलना करें।</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
