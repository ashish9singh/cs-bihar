import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  User, 
  Sparkles, 
  Copy, 
  Check, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  HelpCircle,
  Code,
  Flame,
  ArrowRight
} from 'lucide-react';
import { ClassGrade } from '../types';

interface Message {
  id: string;
  sender: 'user' | 'tutor';
  text: string;
  timestamp: string;
  codeSnippet?: string;
  source?: 'gemini' | 'local' | 'fallback';
}

interface AITutorProps {
  selectedClass: ClassGrade;
  initialQuery?: string;
  onClearInitialQuery?: () => void;
  onNavigateToTab?: (tab: string) => void;
}

export const AITutor: React.FC<AITutorProps> = ({
  selectedClass,
  initialQuery,
  onClearInitialQuery,
  onNavigateToTab,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'tutor',
      text: `नमस्कार विद्यार्थी! 🙏
मैं आपका **BSEBwala.in AI साथी** और कंप्यूटर शिक्षक हूँ। 

आप मुझसे **कक्षा ${selectedClass}** के सिलेबस, C++ प्रोग्रामिंग, SQL डेटाबेस, नेटवर्किंग या कंप्यूटर के किसी भी सवाल को **सरल हिंदी, English या Hinglish** में पूछ सकते हैं।

आइए, समझते हैं! आप आज क्या सीखना चाहते हैं? नीचे दिए गए प्रश्नों में से चुनें या अपना प्रश्न टाइप करें:`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState(initialQuery || '');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickQuestions = [
    'RAM और ROM में क्या अंतर है?',
    'C++ में variable क्या होता है?',
    'for loop को उदाहरण से समझाइए।',
    'do-while और while loop में क्या अंतर है?',
    'SQL में SELECT command कैसे काम करता है?',
    'Primary Key क्या होती है?',
    'LAN और WAN में क्या अंतर है?',
    'इस C++ program में error क्यों आ रहा है?',
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
    if (initialQuery) {
      handleSendMessage(initialQuery);
      if (onClearInitialQuery) onClearInitialQuery();
    }
  }, [initialQuery]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputPrompt).trim();
    if (!text || isLoading) return;

    const userMessage: Message = {
      id: 'msg-' + Date.now(),
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          classGrade: selectedClass,
          conversationHistory: messages.slice(-4).map((m) => ({
            sender: m.sender,
            text: m.text,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error('सर्वर से उत्तर प्राप्त नहीं हो सका');
      }

      const data = await response.json();

      const tutorMessage: Message = {
        id: 'reply-' + Date.now(),
        sender: 'tutor',
        text: data.reply || 'माफ़ कीजिए, उत्तर तैयार नहीं हो सका। कृपया पुनः पूछें।',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        source: data.source,
      };

      setMessages((prev) => [...prev, tutorMessage]);
    } catch (err) {
      const errorMessage: Message = {
        id: 'err-' + Date.now(),
        sender: 'tutor',
        text: `नेटवर्क से संपर्क में बाधा आई है। 
आइए, हम एक सरल बात याद रखें:
- C++ में सिंटैक्स और लॉजिक का ध्यान रखें।
- किसी भी प्रश्न को आप फिर से भेज सकते हैं।`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        source: 'fallback',
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    // Clean markdown before speaking
    const cleanText = text.replace(/[#*`_~]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'hi-IN';
    utterance.rate = 0.95;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleResetChat = () => {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    setIsSpeaking(false);
    setMessages([
      {
        id: 'welcome-reset',
        sender: 'tutor',
        text: `चैट रीसेट कर दी गई है! मैं कक्षा ${selectedClass} के कंप्यूटर साइंस पाठ्यक्रम से संबंधित आपका नया प्रश्न सुनने के लिए तैयार हूँ।`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  // Render markdown helper (bold, code blocks, lists)
  const renderMessageContent = (content: string) => {
    const parts = content.split(/(```[\s\S]*?```)/g);

    return parts.map((part, index) => {
      if (part.startsWith('```') && part.endsWith('```')) {
        const lines = part.slice(3, -3).trim().split('\n');
        const lang = lines[0].match(/^(cpp|sql|html|python|bash|text)/) ? lines[0] : '';
        const code = lang ? lines.slice(1).join('\n') : lines.join('\n');

        return (
          <div key={index} className="my-3 rounded-lg overflow-hidden border border-slate-700 bg-slate-950 font-mono text-xs">
            <div className="bg-slate-800/80 px-3 py-1.5 flex justify-between items-center text-slate-300 text-[11px] border-b border-slate-700">
              <span className="font-semibold uppercase tracking-wider text-blue-400 flex items-center space-x-1">
                <Code className="w-3 h-3" />
                <span>{lang || 'Code'}</span>
              </span>
              <button
                onClick={() => handleCopy(code, `code-${index}`)}
                className="hover:text-white flex items-center space-x-1 text-slate-400 transition-colors"
                title="कोड कॉपी करें"
              >
                {copiedId === `code-${index}` ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedId === `code-${index}` ? 'कॉपी हुआ!' : 'कॉपी करें'}</span>
              </button>
            </div>
            <pre className="p-3 overflow-x-auto text-emerald-300 leading-relaxed whitespace-pre font-mono">
              <code>{code}</code>
            </pre>
          </div>
        );
      }

      // Format bold text and linebreaks
      const formattedLines = part.split('\n').map((line, lIdx) => {
        // Bullet points
        const isBullet = line.trim().startsWith('- ') || line.trim().startsWith('* ');
        const cleanLine = isBullet ? line.trim().substring(2) : line;

        // Process bold (**text**)
        const formattedText = cleanLine.split(/(\*\*.*?\*\*)/g).map((sub, sIdx) => {
          if (sub.startsWith('**') && sub.endsWith('**')) {
            return (
              <strong key={sIdx} className="font-bold text-yellow-300/90">
                {sub.slice(2, -2)}
              </strong>
            );
          }
          if (sub.startsWith('`') && sub.endsWith('`')) {
            return (
              <code key={sIdx} className="bg-slate-800 text-cyan-300 px-1 py-0.5 rounded text-xs font-mono">
                {sub.slice(1, -1)}
              </code>
            );
          }
          return sub;
        });

        if (isBullet) {
          return (
            <li key={lIdx} className="ml-4 list-disc list-outside my-0.5 text-slate-200">
              {formattedText}
            </li>
          );
        }

        return (
          <p key={lIdx} className={line.trim() === '' ? 'h-2' : 'my-1 text-slate-200 leading-relaxed'}>
            {formattedText}
          </p>
        );
      });

      return <div key={index}>{formattedLines}</div>;
    });
  };

  return (
    <div className="flex flex-col h-[calc(100dvh-190px)] sm:h-[calc(100vh-140px)] max-w-5xl mx-auto rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden w-full">
      {/* Tutor Top Header */}
      <div className="bg-slate-850 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <Bot className="w-6 h-6" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900" />
          </div>
          <div>
            <h2 className="font-bold text-slate-100 text-sm sm:text-base flex items-center space-x-2">
              <span>BSEBwala.in AI Tutor</span>
              <span className="text-[11px] bg-blue-500/20 text-blue-400 font-semibold px-2 py-0.5 rounded-full border border-blue-500/30">
                कक्षा {selectedClass}
              </span>
            </h2>
            <p className="text-xs text-slate-400 flex items-center space-x-1">
              <Sparkles className="w-3 h-3 text-amber-400 inline" />
              <span>हिंदी + इंग्लिश द्विभाषी व्याख्या • बिहार बोर्ड पाठ्यक्रम अनुकूल</span>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-1">
          <button
            onClick={handleResetChat}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg text-xs flex items-center space-x-1 transition-colors"
            title="नई बातचीत शुरू करें"
          >
            <RotateCcw className="w-4 h-4" />
            <span className="hidden sm:inline">नई बातचीत</span>
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => {
          const isTutor = message.sender === 'tutor';
          return (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${isTutor ? 'justify-start' : 'justify-end'}`}
            >
              {isTutor && (
                <div className="w-8 h-8 rounded-lg bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400 shrink-0 mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[88%] sm:max-w-[80%] rounded-2xl px-4 py-3 text-sm shadow-md ${
                  isTutor
                    ? 'bg-slate-800/90 text-slate-100 border border-slate-700/60 rounded-tl-sm'
                    : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-tr-sm'
                }`}
              >
                <div className="prose prose-invert max-w-none text-sm">
                  {renderMessageContent(message.text)}
                </div>

                <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center space-x-1">
                    <span>{message.timestamp}</span>
                    {message.source && (
                      <span className="text-[10px] bg-slate-700/60 px-1.5 py-0.2 rounded text-slate-300">
                        {message.source === 'gemini' ? 'Gemini 3.8' : 'Verified BSEB Tutor'}
                      </span>
                    )}
                  </span>

                  {isTutor && (
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleSpeak(message.text)}
                        className="hover:text-blue-300 transition-colors p-1"
                        title={isSpeaking ? 'आवाज़ बंद करें' : 'हिंदी में सुनकर समझें'}
                      >
                        {isSpeaking ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        onClick={() => handleCopy(message.text, message.id)}
                        className="hover:text-blue-300 transition-colors p-1"
                        title="उत्तर कॉपी करें"
                      >
                        {copiedId === message.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {!isTutor && (
                <div className="w-8 h-8 rounded-lg bg-blue-700 flex items-center justify-center text-white shrink-0 mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-start space-x-3 justify-start">
            <div className="w-8 h-8 rounded-lg bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400 shrink-0">
              <Bot className="w-4 h-4 animate-bounce" />
            </div>
            <div className="bg-slate-800 rounded-2xl px-4 py-3 rounded-tl-sm border border-slate-700/60 text-sm text-slate-300 flex items-center space-x-2">
              <div className="flex space-x-1">
                <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping"></span>
                <span className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" style={{ animationDelay: '0.2s' }}></span>
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" style={{ animationDelay: '0.4s' }}></span>
              </div>
              <span className="text-xs text-slate-400">शिक्षक उत्तर और दैनिक जीवन का उदाहरण सोच रहे हैं...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Suggestions Chips */}
      <div className="bg-slate-850 px-4 py-2 border-t border-slate-800/80">
        <div className="flex items-center space-x-2 overflow-x-auto pb-1 no-scrollbar text-xs">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center space-x-1 shrink-0">
            <Flame className="w-3 h-3 text-amber-400" />
            <span>अक्सर पूछे जाने वाले सवाल:</span>
          </span>
          {quickQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(q)}
              className="bg-slate-800 hover:bg-blue-600/30 hover:border-blue-500/40 border border-slate-700 text-slate-300 hover:text-white px-2.5 py-1 rounded-full text-xs whitespace-nowrap transition-all duration-150 active:scale-95"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Input Form Bar */}
      <div className="p-3 bg-slate-900 border-t border-slate-800">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center space-x-2"
        >
          <div className="relative flex-1">
            <input
              type="text"
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder={`कक्षा ${selectedClass} का कोई सवाल पूछें (जैसे: for loop क्या है? या C++ कोड में त्रुटि)...`}
              className="w-full bg-slate-800/90 border border-slate-700 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
              disabled={isLoading}
            />
          </div>
          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="p-3 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:hover:bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-600/30 transition-all active:scale-95 flex items-center justify-center shrink-0"
            title="भेजें"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
        <p className="text-[11px] text-center text-slate-500 mt-2">
          💡 युक्ति: आप C++ कोड पेस्ट करके भी पूछ सकते हैं - "इस कोड में क्या गलती है?"
        </p>
      </div>
    </div>
  );
};
