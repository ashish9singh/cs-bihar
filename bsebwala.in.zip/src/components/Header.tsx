import React, { useState } from 'react';
import { 
  GraduationCap, 
  BookOpen, 
  Bot, 
  Code2, 
  Database, 
  Network, 
  CheckSquare, 
  Award, 
  BarChart3, 
  Sun, 
  Moon, 
  Menu, 
  X,
  Lock,
  Unlock,
  Sparkles,
  Bell,
  ChevronRight,
  Gamepad2,
  Layers,
  Search
} from 'lucide-react';
import { ClassGrade } from '../types';

interface HeaderProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  selectedClass: ClassGrade;
  onSelectClass: (c: ClassGrade) => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  onOpenAdmin: () => void;
  isAdminLoggedIn: boolean;
  completedCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  selectedClass,
  onSelectClass,
  isDarkMode,
  onToggleTheme,
  onOpenAdmin,
  isAdminLoggedIn,
  completedCount,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'डैशबोर्ड', icon: GraduationCap },
    { id: 'modules', label: 'पाठ्यक्रम', icon: BookOpen },
    { id: 'flashcards', label: 'फ्लैशकार्ड्स 🗂️', icon: Layers, highlight: true },
    { id: 'cpp-lab', label: 'C++ लैब', icon: Code2 },
    { id: 'sql-lab', label: 'SQL लैब', icon: Database },
    { id: 'games', label: 'खेल 🎮', icon: Gamepad2 },
    { id: 'exam-prep', label: 'बोर्ड परीक्षा 🎯', icon: Award },
    { id: 'mcq', label: 'MCQ टेस्ट', icon: CheckSquare },
    { id: 'networking', label: 'नेटवर्किंग', icon: Network },
    { id: 'progress', label: 'मेरी प्रगति', icon: BarChart3 },
  ];

  return (
    <header className={`sticky top-0 z-40 backdrop-blur-md border-b transition-colors duration-200 ${
      isDarkMode 
        ? 'bg-slate-900/95 border-slate-800 text-slate-100 shadow-md' 
        : 'bg-white/95 border-slate-200 text-slate-900 shadow-sm'
    }`}>
      {/* BSEBWala Style Live Updates Ticker Banner */}
      <div className={`px-3 py-1.5 text-[11px] sm:text-xs font-medium border-b transition-colors ${
        isDarkMode 
          ? 'bg-gradient-to-r from-blue-950 via-indigo-950 to-slate-900 text-white border-blue-800/40' 
          : 'bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white border-blue-600/40 shadow-inner'
      }`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 overflow-hidden">
          <div className="flex items-center space-x-2 shrink-0">
            <span className="bg-amber-400 text-slate-950 px-2 py-0.5 rounded font-black text-[10px] uppercase tracking-wider flex items-center space-x-1 shadow-sm">
              <Bell className="w-3 h-3 fill-current" />
              <span>LIVE UPDATE</span>
            </span>
          </div>

          <div className="flex-1 overflow-hidden whitespace-nowrap text-white text-[11px] sm:text-xs truncate">
            <span className="text-amber-300 font-bold">📢 BSEB PATNA:</span>{' '}
            <span>कक्षा 9वीं–12वीं कंप्यूटर साइंस संपूर्ण अध्ययन सामग्री • C++ एवं SQL लाइव लैब • 2025-2026 वार्षिक परीक्षा तैयारी</span>
          </div>

          {/* Admin Lock Button in Top Bar */}
          <button 
            onClick={onOpenAdmin}
            className={`shrink-0 flex items-center space-x-1 px-2.5 py-0.5 rounded text-[11px] font-bold border transition-all ${
              isAdminLoggedIn 
                ? 'bg-emerald-500/20 text-emerald-200 border-emerald-400/40' 
                : 'bg-slate-950/40 text-amber-300 border-amber-400/40 hover:bg-slate-950/60'
            }`}
            title="शिक्षक एवं एडमिन पोर्टल"
          >
            {isAdminLoggedIn ? <Unlock className="w-3 h-3 text-emerald-300" /> : <Lock className="w-3 h-3 text-amber-300" />}
            <span>{isAdminLoggedIn ? 'एडमिन सक्रिय' : 'एडमिन लॉगिन 🔒'}</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        <div className="flex items-center justify-between h-14 sm:h-16">
          {/* Brand Logo & Name */}
          <div 
            onClick={() => onSelectTab('home')}
            className="flex items-center space-x-2.5 cursor-pointer group select-none shrink-0"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <Code2 className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-1">
                <span className={`font-black text-lg sm:text-xl tracking-tight flex items-center ${
                  isDarkMode ? 'text-white' : 'text-slate-900'
                }`}>
                  BSEB<span className="text-amber-500">wala</span><span className={`${isDarkMode ? 'text-blue-400' : 'text-blue-600'} font-mono text-base font-bold`}>.in</span>
                </span>
                <span className={`text-[9px] px-1.5 py-0.5 rounded font-extrabold uppercase hidden sm:inline-block ${
                  isDarkMode ? 'bg-blue-600/30 text-blue-300 border border-blue-500/30' : 'bg-blue-50 text-blue-700 border border-blue-200'
                }`}>
                  CS
                </span>
              </div>
              <p className={`text-[10px] hidden xs:block truncate ${isDarkMode ? 'text-slate-400' : 'text-slate-500 font-medium'}`}>
                बिहार बोर्ड Computer Science • Class 9-12
              </p>
            </div>
          </div>

          {/* Class Grade Switcher (Desktop / Tablet) */}
          <div className={`hidden md:flex items-center space-x-1 p-1 rounded-xl border ${
            isDarkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
          }`}>
            <span className={`text-[11px] font-bold px-2 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>कक्षा:</span>
            {(['9', '10', '11', '12'] as ClassGrade[]).map((c) => (
              <button
                key={c}
                onClick={() => onSelectClass(c)}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  selectedClass === c
                    ? 'bg-blue-600 text-white shadow'
                    : isDarkMode 
                      ? 'text-slate-400 hover:text-white hover:bg-slate-800'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white'
                }`}
              >
                कक्षा {c}
              </button>
            ))}
          </div>

          {/* Right Action Buttons */}
          <div className="flex items-center space-x-2">
            {/* Mobile Class Switcher Selector */}
            <div className={`md:hidden flex items-center rounded-lg border px-1.5 py-0.5 ${
              isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-100 border-slate-300'
            }`}>
              <span className={`text-[10px] mr-1 font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>कक्षा:</span>
              <select
                value={selectedClass}
                onChange={(e) => onSelectClass(e.target.value as ClassGrade)}
                className={`bg-transparent text-xs font-bold focus:outline-none ${
                  isDarkMode ? 'text-amber-400' : 'text-blue-700'
                }`}
              >
                <option value="9" className="bg-slate-900 text-white">9</option>
                <option value="10" className="bg-slate-900 text-white">10</option>
                <option value="11" className="bg-slate-900 text-white">11</option>
                <option value="12" className="bg-slate-900 text-white">12</option>
              </select>
            </div>

            {/* AI Tutor Quick Pill */}
            <button
              onClick={() => onSelectTab('ai-tutor')}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:from-blue-500 shadow-sm active:scale-95 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span className="hidden sm:inline">AI शिक्षक</span>
              <span className="sm:hidden">AI</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={onToggleTheme}
              className={`p-2 rounded-xl transition-colors ${
                isDarkMode 
                  ? 'text-slate-300 hover:text-white hover:bg-slate-800' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
              title={isDarkMode ? 'लाइट मोड सक्रिय करें' : 'डार्क मोड सक्रिय करें'}
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-blue-600" />}
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`lg:hidden p-2 rounded-xl transition-colors focus:outline-none ${
                isDarkMode 
                  ? 'text-slate-300 hover:text-white hover:bg-slate-800' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center space-x-1 pb-2 overflow-x-auto no-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-150 ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm'
                    : isDarkMode 
                      ? 'text-slate-300 hover:text-white hover:bg-slate-800'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Mobile Drawer Dropdown */}
      {isMobileMenuOpen && (
        <div className={`lg:hidden border-b px-4 py-3 space-y-3 animate-fadeIn ${
          isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-xl'
        }`}>
          <div className={`grid grid-cols-4 gap-1.5 pb-2 border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
            {(['9', '10', '11', '12'] as ClassGrade[]).map((c) => (
              <button
                key={c}
                onClick={() => {
                  onSelectClass(c);
                }}
                className={`p-2 text-xs font-bold rounded-lg text-center ${
                  selectedClass === c
                    ? 'bg-blue-600 text-white'
                    : isDarkMode
                      ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                कक्षा {c}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectTab(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`flex items-center space-x-2 p-2.5 rounded-xl text-xs font-bold w-full text-left transition-all ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm'
                      : isDarkMode
                        ? 'bg-slate-850 text-slate-200 hover:bg-slate-800'
                        : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className={`pt-2 border-t flex justify-between items-center ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
            <button
              onClick={() => {
                onOpenAdmin();
                setIsMobileMenuOpen(false);
              }}
              className={`text-xs font-bold flex items-center space-x-1.5 py-1 ${
                isDarkMode ? 'text-amber-300' : 'text-blue-700'
              }`}
            >
              <Lock className={`w-3.5 h-3.5 ${isDarkMode ? 'text-amber-400' : 'text-blue-600'}`} />
              <span>शिक्षक एवं एडमिन पोर्टल {isAdminLoggedIn && '(सक्रिय)'}</span>
            </button>
            <span className={`text-[11px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{completedCount} पाठ पूर्ण</span>
          </div>
        </div>
      )}
    </header>
  );
};
