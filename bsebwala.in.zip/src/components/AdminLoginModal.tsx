import React, { useState } from 'react';
import { 
  Lock, 
  KeyRound, 
  ShieldCheck, 
  Eye, 
  EyeOff, 
  AlertCircle, 
  Check, 
  X, 
  UserCheck, 
  ArrowRight
} from 'lucide-react';
import { verifyAdminLogin, updateAdminPassword, setAdminSession } from '../utils/adminAuth';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: () => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [step, setStep] = useState<'login' | 'change-password'>('login');
  
  // Login Form
  const [adminId, setAdminId] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  
  // Password Change Form
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showNewPassword, setShowNewPassword] = useState<boolean>(false);
  
  // Feedback
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');

  if (!isOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!adminId.trim() || !password.trim()) {
      setErrorMsg('कृपया एडमिन ID एवं पासवर्ड दोनों दर्ज करें।');
      return;
    }

    const verification = verifyAdminLogin(adminId, password);

    if (!verification.success) {
      setErrorMsg(verification.errorHindi || 'गलत ID या पासवर्ड। कृपया पुनः प्रयास करें।');
      return;
    }

    if (verification.requiresPasswordChange) {
      // First login! Force password change
      setStep('change-password');
      setErrorMsg('');
      setSuccessMsg('पहला लॉगिन सफल! कृपया आगे बढ़ने के लिए अपना नया सुरक्षित पासवर्ड सेट करें।');
    } else {
      // Regular login with updated password
      setAdminSession(true);
      setSuccessMsg('एडमिन लॉगिन सफल!');
      setTimeout(() => {
        onLoginSuccess();
      }, 500);
    }
  };

  const handlePasswordChangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!newPassword || newPassword.length < 6) {
      setErrorMsg('नया पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।');
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMsg('दोनों पासवर्ड मेल नहीं खाते! कृपया पुनः जाँचें।');
      return;
    }

    const updateRes = updateAdminPassword(newPassword);
    if (!updateRes.success) {
      setErrorMsg(updateRes.errorHindi || 'पासवर्ड अपडेट करने में त्रुटि।');
      return;
    }

    setSuccessMsg('नया पासवर्ड सफलतापूर्वक सेट हो गया! एडमिन पैनल खोला जा रहा है...');
    setTimeout(() => {
      onLoginSuccess();
    }, 1000);
  };

  const handleClose = () => {
    setErrorMsg('');
    setSuccessMsg('');
    setStep('login');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-md w-full shadow-2xl overflow-hidden text-slate-100">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 px-6 py-5 flex items-center justify-between text-white border-b border-blue-600/30">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur border border-white/20 flex items-center justify-center">
              <Lock className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-base leading-tight">
                {step === 'login' ? 'शिक्षक / एडमिन सुरक्षित लॉगिन' : 'पहला लॉगिन: नया पासवर्ड सेट करें'}
              </h3>
              <p className="text-xs text-blue-100 mt-0.5">
                {step === 'login' ? 'Admin Access Protected' : 'Mandatory First-Time Password Setup'}
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4">
          {/* Notifications */}
          {errorMsg && (
            <div className="bg-rose-950/50 border border-rose-800/80 rounded-xl p-3 text-xs text-rose-300 flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="bg-emerald-950/50 border border-emerald-800/80 rounded-xl p-3 text-xs text-emerald-300 flex items-start space-x-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* STEP 1: LOGIN FORM */}
          {step === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs sm:text-sm">
              <div className="space-y-1.5">
                <label className="font-bold text-slate-300 flex items-center space-x-1.5">
                  <UserCheck className="w-4 h-4 text-blue-400" />
                  <span>एडमिन आईडी (Admin ID):</span>
                </label>
                <input
                  type="text"
                  value={adminId}
                  onChange={(e) => setAdminId(e.target.value)}
                  placeholder="अपना एडमिन ID दर्ज करें..."
                  required
                  autoFocus
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-mono text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-300 flex items-center space-x-1.5">
                  <KeyRound className="w-4 h-4 text-blue-400" />
                  <span>पासवर्ड (Password):</span>
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="पासवर्ड दर्ज करें..."
                    required
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 pr-10 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 font-mono text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-bold py-3 rounded-xl shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center space-x-2 text-sm mt-3"
              >
                <span>लॉगिन करें (Secure Login)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* STEP 2: MANDATORY FIRST-LOGIN PASSWORD CHANGE */}
          {step === 'change-password' && (
            <form onSubmit={handlePasswordChangeSubmit} className="space-y-4 text-xs sm:text-sm">
              <div className="bg-amber-950/30 border border-amber-900/50 rounded-xl p-3 text-xs text-amber-300">
                <span className="font-bold block mb-1">🔐 सुरक्षा निर्देश:</span>
                कृपया अपना नया गोपनीय पासवर्ड सेट करें। भविष्य में इसी पासवर्ड से एडमिन पोर्टल में लॉगिन किया जा सकेगा।
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-300">नया पासवर्ड (New Password - न्यूनतम 6 अक्षर):</label>
                <div className="relative">
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="कम से कम 6 अक्षरों का नया पासवर्ड..."
                    required
                    autoFocus
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 pr-10 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-300">नया पासवर्ड दोबारा दर्ज करें (Confirm Password):</label>
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="वही पासवर्ड दोबारा लिखें..."
                  required
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono text-sm"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold py-3 rounded-xl shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center space-x-2 text-sm mt-2"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>नया पासवर्ड सहेजें और पोर्टल खोलें</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
