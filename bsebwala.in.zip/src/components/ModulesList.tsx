import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  Search, 
  CheckCircle, 
  Clock, 
  ArrowRight, 
  Sparkles, 
  Check,
  ChevronDown,
  ChevronUp,
  Award,
  Layers,
  Cpu,
  Database,
  Code2,
  Terminal,
  ShieldCheck,
  Globe,
  Binary,
  HardDrive,
  FileCode2,
  Box,
  Network,
  Edit3,
  Trash2,
  ToggleRight
} from 'lucide-react';
import { Chapter, ClassGrade, SyllabusUnit } from '../types';
import { syllabusUnits } from '../data/unitsData';

interface ModulesListProps {
  chapters: Chapter[];
  selectedClass: ClassGrade;
  onSelectClass: (c: ClassGrade) => void;
  onSelectChapter: (id: string) => void;
  completedChapterIds: string[];
  isAdmin?: boolean;
  onEditChapter?: (ch: Chapter) => void;
  onDeleteChapter?: (id: string) => void;
}

// Icon mapper for units
const getUnitIcon = (iconName?: string) => {
  switch (iconName) {
    case 'Cpu': return Cpu;
    case 'Code': return Code2;
    case 'Terminal': return Terminal;
    case 'Database': return Database;
    case 'Network': return Network;
    case 'Layers': return Layers;
    case 'ShieldCheck': return ShieldCheck;
    case 'Globe': return Globe;
    case 'Binary': return Binary;
    case 'HardDrive': return HardDrive;
    case 'FileCode2': return FileCode2;
    case 'Box': return Box;
    case 'ToggleRight': return ToggleRight;
    default: return BookOpen;
  }
};

export const ModulesList: React.FC<ModulesListProps> = ({
  chapters,
  selectedClass,
  onSelectClass,
  onSelectChapter,
  completedChapterIds,
  isAdmin = false,
  onEditChapter,
  onDeleteChapter,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedUnitId, setSelectedUnitId] = useState<string>('all');
  const [collapsedUnits, setCollapsedUnits] = useState<Record<string, boolean>>({});
  const [filterStatus, setFilterStatus] = useState<'all' | 'completed' | 'pending'>('all');

  // Filter units for the selected class
  const classUnits = useMemo(() => {
    return syllabusUnits.filter((u) => u.classGrade === selectedClass);
  }, [selectedClass]);

  // Reset selected unit if class changes and unit doesn't belong to new class
  React.useEffect(() => {
    if (selectedUnitId !== 'all') {
      const exists = classUnits.some((u) => u.id === selectedUnitId);
      if (!exists) {
        setSelectedUnitId('all');
      }
    }
  }, [selectedClass, classUnits, selectedUnitId]);

  // Toggle unit collapse
  const toggleUnitCollapse = (unitId: string) => {
    setCollapsedUnits((prev) => ({
      ...prev,
      [unitId]: !prev[unitId],
    }));
  };

  // Group and filter chapters
  const filteredUnitsWithChapters = useMemo(() => {
    return classUnits
      .filter((unit) => selectedUnitId === 'all' || unit.id === selectedUnitId)
      .map((unit) => {
        const unitChapters = chapters.filter((c) => {
          if (c.classGrade !== selectedClass) return false;
          // Match by explicit unitId or fallback to unitNumber / moduleTitle
          const matchUnit = 
            c.unitId === unit.id ||
            c.unitNumber === unit.unitNumber ||
            c.moduleTitle.toLowerCase().includes(unit.unitCode.toLowerCase()) ||
            c.moduleTitle.toLowerCase().includes(unit.title.toLowerCase());
          
          if (!matchUnit) return false;

          // Search query filter
          if (searchQuery.trim()) {
            const q = searchQuery.toLowerCase();
            const inTitle = c.title.toLowerCase().includes(q);
            const inHindi = c.titleHindi.toLowerCase().includes(q);
            const inIntro = c.introHindi.toLowerCase().includes(q);
            const inTerms = c.technicalTerms?.some((t) => 
              t.term.toLowerCase().includes(q) || t.hindiMeaning.toLowerCase().includes(q)
            );
            if (!inTitle && !inHindi && !inIntro && !inTerms) return false;
          }

          // Completion status filter
          const isDone = completedChapterIds.includes(c.id);
          if (filterStatus === 'completed' && !isDone) return false;
          if (filterStatus === 'pending' && isDone) return false;

          return true;
        });

        return {
          unit,
          chapters: unitChapters,
        };
      })
      .filter((group) => {
        // If there's an active search or status filter, show only units with matching chapters
        if (searchQuery.trim() || filterStatus !== 'all') {
          return group.chapters.length > 0;
        }
        return true;
      });
  }, [classUnits, chapters, selectedClass, selectedUnitId, searchQuery, filterStatus, completedChapterIds]);

  // Total progress for current class
  const classChapters = chapters.filter((c) => c.classGrade === selectedClass);
  const completedInClass = classChapters.filter((c) => completedChapterIds.includes(c.id)).length;
  const progressPercent = classChapters.length > 0 ? Math.round((completedInClass / classChapters.length) * 100) : 0;

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-16">
      {/* 1. Header Banner & BSEB Blueprint Overview */}
      <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 border border-blue-500/30 rounded-3xl p-5 sm:p-7 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-amber-400 text-slate-950 text-[11px] font-black uppercase px-2.5 py-0.5 rounded-full tracking-wider shadow-sm">
                BSEB OFFICIAL CURRICULUM
              </span>
              <span className="bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[11px] font-bold px-2.5 py-0.5 rounded-full">
                कक्षा {selectedClass} • यूनिट-वार पाठ्यक्रम नोट्स
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              अध्याय-वार यूनिट्स (Chapter-wise Units)
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
              बिहार विद्यालय परीक्षा समिति (BSEB) द्वारा निर्धारित आधिकारिक पाठ्यक्रम के अनुसार संपूर्ण यूनिट्स एवं अध्याय। प्रत्येक पाठ में 14-बिंदु सरल व्याख्या, दैनिक जीवन के उदाहरण, C++/SQL प्रायोगिक कोड एवं परीक्षा प्रश्न।
            </p>

            {/* Official Marks / Blueprint Pill */}
            <div className="pt-2 flex flex-wrap items-center gap-2 text-xs">
              {(selectedClass === '11' || selectedClass === '12') ? (
                <div className="bg-slate-950/80 border border-slate-700/80 px-3 py-1.5 rounded-xl text-slate-300 flex items-center space-x-2">
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>
                    <strong>थ्योरी परीक्षा:</strong> 70 अंक | <strong>प्रैक्टिकल/लैब:</strong> 30 अंक | <strong>कुल:</strong> 100 अंक
                  </span>
                </div>
              ) : (
                <div className="bg-slate-950/80 border border-slate-700/80 px-3 py-1.5 rounded-xl text-slate-300 flex items-center space-x-2">
                  <Award className="w-4 h-4 text-emerald-400" />
                  <span>
                    <strong>NEP 2020 अधिगम विभाजन:</strong> 40% सिद्धांत | 40% व्यावहारिक/लैब | 20% प्रोजेक्ट कार्य
                  </span>
                </div>
              )}

              <div className="bg-slate-950/80 border border-slate-700/80 px-3 py-1.5 rounded-xl text-slate-300 flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>
                  <strong>प्रगति:</strong> {completedInClass}/{classChapters.length} अध्याय पूर्ण ({progressPercent}%)
                </span>
              </div>
            </div>
          </div>

          {/* Class Switcher for fast hopping */}
          <div className="bg-slate-950 p-1.5 rounded-2xl border border-slate-800 flex flex-row md:flex-col gap-1 shrink-0">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 py-0.5 hidden md:block">
              कक्षा चुनें:
            </span>
            <div className="flex md:flex-col gap-1 w-full">
              {(['9', '10', '11', '12'] as ClassGrade[]).map((c) => (
                <button
                  key={c}
                  onClick={() => onSelectClass(c)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center justify-between ${
                    selectedClass === c
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <span>कक्षा {c}</span>
                  {selectedClass === c && <span className="w-1.5 h-1.5 rounded-full bg-white ml-2 hidden md:inline-block" />}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 2. Interactive Unit Bar for Selected Class */}
        <div className="mt-6 pt-5 border-t border-slate-800/80">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
              <Layers className="w-3.5 h-3.5 text-blue-400" />
              <span>कक्षा {selectedClass} की आधिकारिक यूनिट्स (Units Filter):</span>
            </span>
            <span className="text-[11px] text-slate-400 hidden sm:inline">
              कुल {classUnits.length} यूनिट्स
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <button
              onClick={() => setSelectedUnitId('all')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all ${
                selectedUnitId === 'all'
                  ? 'bg-amber-400 text-slate-950 shadow-md font-black'
                  : 'bg-slate-950/80 border border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              सभी यूनिट्स ({classChapters.length} अध्याय)
            </button>

            {classUnits.map((u) => {
              const isSelected = selectedUnitId === u.id;
              return (
                <button
                  key={u.id}
                  onClick={() => setSelectedUnitId(u.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center space-x-1.5 ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                      : 'bg-slate-950/80 border border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <span>{u.unitCode}: {u.titleHindi.split(' ')[0]}</span>
                  {u.marks ? (
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-extrabold ${
                      isSelected ? 'bg-white/20 text-white' : 'bg-blue-500/20 text-blue-300'
                    }`}>
                      {u.marks}M
                    </span>
                  ) : null}
                </button>
              );
            })}
          </div>
        </div>

        {/* 3. Search and Status Filters */}
        <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="यूनिट या अध्याय खोजें (उदा: C++, SQL, IPOS, Boolean, Stack)..."
              className="w-full bg-slate-950/90 border border-slate-700/80 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950/90 border border-slate-700/80 p-1 rounded-xl shrink-0">
            {[
              { id: 'all', label: 'सभी' },
              { id: 'pending', label: 'अपूर्ण' },
              { id: 'completed', label: 'पूर्ण ✓' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilterStatus(f.id as any)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  filterStatus === f.id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 4. Units & Chapter-wise Content Sections */}
      {filteredUnitsWithChapters.length === 0 ? (
        <div className="text-center py-16 bg-slate-900 border border-slate-800 rounded-3xl p-8">
          <Search className="w-12 h-12 text-slate-500 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white">कोई अध्याय नहीं मिला</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            कृपया अपने खोज शब्द बदलें या "सभी यूनिट्स" पर क्लिक करें।
          </p>
          <button
            onClick={() => { setSearchQuery(''); setSelectedUnitId('all'); setFilterStatus('all'); }}
            className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl"
          >
            फ़िल्टर रीसेट करें
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredUnitsWithChapters.map(({ unit, chapters: uChapters }) => {
            const UnitIcon = getUnitIcon(unit.iconName);
            const isCollapsed = Boolean(collapsedUnits[unit.id]);
            const unitDoneCount = uChapters.filter((c) => completedChapterIds.includes(c.id)).length;
            const unitProgressPct = uChapters.length > 0 ? Math.round((unitDoneCount / uChapters.length) * 100) : 0;

            return (
              <div 
                key={unit.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl transition-all hover:border-slate-700"
              >
                {/* Unit Header Container */}
                <div 
                  onClick={() => toggleUnitCollapse(unit.id)}
                  className="p-5 sm:p-6 bg-slate-850/80 border-b border-slate-800/80 cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4 select-none hover:bg-slate-800/60 transition-colors"
                >
                  <div className="flex items-start space-x-3.5">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 shrink-0 mt-0.5">
                      <UnitIcon className="w-5 h-5 sm:w-6 sm:h-6" />
                    </div>

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                          {unit.unitCode} • कक्षा {unit.classGrade}
                        </span>

                        {unit.marks ? (
                          <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 shadow-sm">
                            {unit.marks} अंक (BSEB Theory)
                          </span>
                        ) : null}

                        <span className="text-[11px] text-slate-400">
                          {uChapters.length} अध्याय
                        </span>
                      </div>

                      <h2 className="text-base sm:text-xl font-black text-white tracking-tight flex items-center gap-2">
                        <span>{unit.titleHindi}</span>
                      </h2>
                      <p className="text-xs text-slate-400 font-mono">
                        {unit.title}
                      </p>
                      <p className="text-xs text-slate-300 leading-relaxed pt-1 line-clamp-2 md:line-clamp-none">
                        {unit.descriptionHindi}
                      </p>
                    </div>
                  </div>

                  {/* Right side stats and toggle button */}
                  <div className="flex items-center justify-between md:justify-end gap-3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-800">
                    <div className="text-right">
                      <div className="flex items-center space-x-2">
                        <div className="w-24 sm:w-32 bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                          <div 
                            className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                            style={{ width: `${unitProgressPct}%` }}
                          />
                        </div>
                        <span className="text-xs font-bold text-slate-300 min-w-8">
                          {unitProgressPct}%
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400">
                        {unitDoneCount}/{uChapters.length} पूर्ण
                      </span>
                    </div>

                    <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400">
                      {isCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                    </div>
                  </div>
                </div>

                {/* Chapter Cards Grid inside Unit */}
                {!isCollapsed && (
                  <div className="p-4 sm:p-6 bg-slate-900/90">
                    {uChapters.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-400 bg-slate-950/60 rounded-2xl border border-dashed border-slate-800">
                        इस यूनिट में चयनित फ़िल्टर के अनुसार कोई अध्याय उपलब्ध नहीं है।
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {uChapters.map((chapter) => {
                          const isDone = completedChapterIds.includes(chapter.id);
                          return (
                            <div
                              key={chapter.id}
                              onClick={() => onSelectChapter(chapter.id)}
                              className="group bg-slate-950/70 border border-slate-800/80 hover:border-blue-500/60 p-4 sm:p-5 rounded-2xl cursor-pointer transition-all hover:bg-slate-850/80 flex flex-col justify-between shadow-lg"
                            >
                              <div className="space-y-2.5">
                                <div className="flex items-center justify-between gap-2">
                                  <div className="flex items-center space-x-1.5">
                                    <span className="text-[10px] font-black text-amber-400 bg-amber-400/10 border border-amber-400/20 px-2 py-0.5 rounded">
                                      अध्याय {chapter.chapterNumber || '1.1'}
                                    </span>
                                    {chapter.practicalDemo && (
                                      <span className="text-[9px] font-bold text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded uppercase">
                                        {chapter.practicalDemo.language} कोड
                                      </span>
                                    )}
                                  </div>

                                  <div className="flex items-center space-x-1 shrink-0">
                                    {isDone ? (
                                      <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold flex items-center space-x-1">
                                        <CheckCircle className="w-3 h-3" />
                                        <span>पूर्ण</span>
                                      </span>
                                    ) : (
                                      <span className="text-[10px] text-slate-400 flex items-center space-x-1">
                                        <Clock className="w-3 h-3" />
                                        <span>~{chapter.estimatedMins}m</span>
                                      </span>
                                    )}
                                  </div>
                                </div>

                                <div>
                                  <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-blue-300 transition-colors leading-snug">
                                    {chapter.titleHindi}
                                  </h3>
                                  <p className="text-[11px] text-slate-400 font-mono mt-0.5 line-clamp-1">
                                    {chapter.title}
                                  </p>
                                </div>

                                <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                                  {chapter.introHindi}
                                </p>

                                {/* Objectives preview */}
                                {chapter.learningObjectives && chapter.learningObjectives.length > 0 && (
                                  <div className="pt-1 text-[11px] text-slate-400 space-y-0.5">
                                    <div className="flex items-center space-x-1 text-slate-300 font-semibold">
                                      <Sparkles className="w-3 h-3 text-amber-400 inline" />
                                      <span>मुख्य अधिगम बिंदु:</span>
                                    </div>
                                    <p className="truncate text-slate-400">
                                      • {chapter.learningObjectives[0]}
                                    </p>
                                  </div>
                                )}
                              </div>

                              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-bold text-blue-400 group-hover:text-blue-300">
                                <span className="flex items-center space-x-1">
                                  <span>पाठ खोलें (14-Point Guide)</span>
                                </span>

                                <div className="flex items-center space-x-2">
                                  {isAdmin && (
                                    <div className="flex items-center space-x-1" onClick={(e) => e.stopPropagation()}>
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          onEditChapter && onEditChapter(chapter);
                                        }}
                                        className="p-1 px-2 rounded-lg bg-amber-500/20 hover:bg-amber-400 text-amber-300 hover:text-slate-950 border border-amber-500/30 text-[10px] font-bold flex items-center space-x-1 transition-all"
                                        title="अध्याय संपादित करें"
                                      >
                                        <Edit3 className="w-3 h-3" />
                                        <span>संपादित करें</span>
                                      </button>
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          if (confirm(`क्या आप सचमुच अध्याय "${chapter.titleHindi}" को हटाना चाहते हैं?`)) {
                                            onDeleteChapter && onDeleteChapter(chapter.id);
                                          }
                                        }}
                                        className="p-1 px-2 rounded-lg bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 text-[10px] font-bold flex items-center space-x-1 transition-all"
                                        title="अध्याय हटाएं"
                                      >
                                        <Trash2 className="w-3 h-3" />
                                        <span>हटाएं</span>
                                      </button>
                                    </div>
                                  )}
                                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
