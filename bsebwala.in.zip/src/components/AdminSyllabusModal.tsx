import React, { useState, useMemo, useEffect } from 'react';
import { 
  X, 
  PlusCircle, 
  Calendar, 
  Download, 
  RotateCcw, 
  Save, 
  Check, 
  AlertCircle,
  LogOut,
  KeyRound,
  ShieldCheck,
  BookOpen,
  Layers,
  Code2,
  Award,
  HelpCircle,
  Sparkles,
  Plus,
  Trash2,
  ListChecks,
  FileText,
  Terminal,
  Info,
  ChevronRight,
  Eye,
  RefreshCw,
  Search,
  Edit3,
  Undo2
} from 'lucide-react';
import { Chapter, ClassGrade, TechnicalTerm, MCQQuestion, ShortQuestion } from '../types';
import { syllabusUnits } from '../data/unitsData';
import { updateAdminPassword } from '../utils/adminAuth';

interface AdminSyllabusModalProps {
  isOpen: boolean;
  onClose: () => void;
  chapters: Chapter[];
  onAddNewChapter: (newChapter: Chapter) => void;
  onUpdateChapter: (updatedChapter: Chapter) => void;
  onDeleteChapter: (chapterId: string) => void;
  chapterToEdit?: Chapter | null;
  onClearEditingChapter?: () => void;
  currentSession: string;
  onUpdateSession: (newSession: string) => void;
  onResetSyllabusToDefault: () => void;
  onLogout: () => void;
}

export const AdminSyllabusModal: React.FC<AdminSyllabusModalProps> = ({
  isOpen,
  onClose,
  chapters,
  onAddNewChapter,
  onUpdateChapter,
  onDeleteChapter,
  chapterToEdit,
  onClearEditingChapter,
  currentSession,
  onUpdateSession,
  onResetSyllabusToDefault,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<'add-chapter' | 'manage-chapters' | 'session' | 'password' | 'backup'>('add-chapter');
  const [formSection, setFormSection] = useState<'basic' | 'notes' | 'practical' | 'questions'>('basic');
  const [sessionInput, setSessionInput] = useState<string>(currentSession);
  
  // Editing Chapter State
  const [editingChapterId, setEditingChapterId] = useState<string | null>(null);

  // Chapter Search in Manage Tab
  const [manageClassFilter, setManageClassFilter] = useState<ClassGrade>('11');
  const [manageSearch, setManageSearch] = useState<string>('');
  const [previewChapter, setPreviewChapter] = useState<Chapter | null>(null);

  // Extended Chapter Form state
  const [classGrade, setClassGrade] = useState<ClassGrade>('11');
  const [selectedUnitId, setSelectedUnitId] = useState<string>('');
  const [chapterNumber, setChapterNumber] = useState<string>('3.3');
  const [titleHindi, setTitleHindi] = useState<string>('');
  const [title, setTitle] = useState<string>('');
  const [estimatedMins, setEstimatedMins] = useState<number>(30);
  const [isOfficial, setIsOfficial] = useState<boolean>(true);
  
  // Learning Objectives
  const [objectives, setObjectives] = useState<string[]>([
    'विषय की आधारभूत समझ और मुख्य संकल्पना',
    'दैनिक जीवन और प्रायोगिक अनुप्रयोग',
    'BSEB परीक्षा की दृष्टि से महत्वपूर्ण बिंदु'
  ]);
  const [newObjInput, setNewObjInput] = useState<string>('');

  // Content & Notes
  const [introHindi, setIntroHindi] = useState<string>('');
  const [explanationHindi, setExplanationHindi] = useState<string>('');
  
  // Technical Terms
  const [techTerms, setTechTerms] = useState<TechnicalTerm[]>([
    { term: '', hindiMeaning: '', explanation: '' }
  ]);

  // Real life analogy
  const [analogyTitle, setAnalogyTitle] = useState<string>('दैनिक जीवन से उदाहरण');
  const [analogyScenario, setAnalogyScenario] = useState<string>('दैनिक जीवन की परिस्थिति...');
  const [analogyText, setAnalogyText] = useState<string>('कंप्यूटर सिद्धांत से तुलना...');
  const [analogyTakeaway, setAnalogyTakeaway] = useState<string>('मुख्य सीख...');

  // Practical Demo
  const [hasPracticalDemo, setHasPracticalDemo] = useState<boolean>(true);
  const [demoLang, setDemoLang] = useState<'cpp' | 'sql' | 'html' | 'pseudo'>('cpp');
  const [demoTitle, setDemoTitle] = useState<string>('प्रायोगिक कोड उदाहरण');
  const [demoCode, setDemoCode] = useState<string>('#include <iostream.h>\nint main() {\n    cout << "नमस्ते बिहार!";\n    return 0;\n}');
  const [demoExplanation, setDemoExplanation] = useState<string>('इस कोड में मुख्य निर्देशों की व्याख्या...');
  const [practicalExercise, setPracticalExercise] = useState<string>('कंप्यूटर लैब में इस कोड को चलाकर आउटपुट देखें।');

  // Key revision points
  const [keyPoints, setKeyPoints] = useState<string[]>([
    'परीक्षा के लिए परिभाषा और सिंटैक्स याद रखें।',
    'त्रुटियों से बचने के लिए नियमों का ध्यान रखें।'
  ]);

  // Questions
  const [mcqQuestion, setMcqQuestion] = useState<string>('');
  const [mcqOptions, setMcqOptions] = useState<string[]>(['विकल्प A', 'विकल्प B', 'विकल्प C', 'विकल्प D']);
  const [mcqCorrectIndex, setMcqCorrectIndex] = useState<number>(0);
  const [mcqExplanation, setMcqExplanation] = useState<string>('');

  const [shortQues, setShortQues] = useState<string>('');
  const [shortAns, setShortAns] = useState<string>('');

  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);
  const [formError, setFormError] = useState<string>('');
  const [actionNotice, setActionNotice] = useState<string>('');

  // Change Password State
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [pwdMsg, setPwdMsg] = useState<{ text: string; isError: boolean } | null>(null);

  // Available units for currently selected classGrade in form
  const availableUnits = useMemo(() => {
    return syllabusUnits.filter((u) => u.classGrade === classGrade);
  }, [classGrade]);

  // Manage Chapters filtered list
  const managedChapters = useMemo(() => {
    return chapters.filter((c) => {
      const matchClass = c.classGrade === manageClassFilter;
      if (!matchClass) return false;
      if (manageSearch.trim()) {
        const q = manageSearch.toLowerCase();
        return (
          c.titleHindi.toLowerCase().includes(q) ||
          c.title.toLowerCase().includes(q) ||
          c.chapterNumber?.toLowerCase().includes(q) ||
          c.moduleTitle.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [chapters, manageClassFilter, manageSearch]);

  // Load a chapter into the editor
  const loadChapterForEditing = (ch: Chapter) => {
    setEditingChapterId(ch.id);
    setClassGrade(ch.classGrade);
    setSelectedUnitId(ch.unitId || '');
    setChapterNumber(ch.chapterNumber || '');
    setTitleHindi(ch.titleHindi);
    setTitle(ch.title);
    setEstimatedMins(ch.estimatedMins || 25);
    setIsOfficial(ch.isOfficialSyllabus);
    setObjectives(ch.learningObjectives?.length ? [...ch.learningObjectives] : ['मुख्य बिंदु']);
    setIntroHindi(ch.introHindi);
    setExplanationHindi(ch.explanationHindi);
    
    if (ch.technicalTerms?.length) {
      setTechTerms([...ch.technicalTerms]);
    } else {
      setTechTerms([{ term: '', hindiMeaning: '', explanation: '' }]);
    }

    if (ch.realLifeExample) {
      setAnalogyTitle(ch.realLifeExample.title || 'दैनिक जीवन से उदाहरण');
      setAnalogyScenario(ch.realLifeExample.scenario || '');
      setAnalogyText(ch.realLifeExample.analogy || '');
      setAnalogyTakeaway(ch.realLifeExample.takeaway || '');
    }

    if (ch.practicalDemo) {
      setHasPracticalDemo(true);
      setDemoLang(ch.practicalDemo.language);
      setDemoTitle(ch.practicalDemo.title);
      setDemoCode(ch.practicalDemo.code);
      setDemoExplanation(ch.practicalDemo.explanation);
    } else {
      setHasPracticalDemo(false);
    }

    setPracticalExercise(ch.practicalExercise || 'कंप्यूटर लैब में संबंधित कोड का अभ्यास करें।');
    setKeyPoints(ch.importantPoints?.length ? [...ch.importantPoints] : ['परीक्षा के लिए महत्वपूर्ण नियम']);

    if (ch.mcqs?.length) {
      setMcqQuestion(ch.mcqs[0].question);
      setMcqOptions([...ch.mcqs[0].options]);
      setMcqCorrectIndex(ch.mcqs[0].correctIndex);
      setMcqExplanation(ch.mcqs[0].explanationHindi);
    } else {
      setMcqQuestion('');
      setMcqOptions(['विकल्प A', 'विकल्प B', 'विकल्प C', 'विकल्प D']);
      setMcqCorrectIndex(0);
      setMcqExplanation('');
    }

    if (ch.shortQuestions?.length) {
      setShortQues(ch.shortQuestions[0].question);
      setShortAns(ch.shortQuestions[0].answerHindi);
    } else {
      setShortQues('');
      setShortAns('');
    }

    setActiveTab('add-chapter');
    setFormSection('basic');
    setFormError('');
    setActionNotice(`अध्याय "${ch.titleHindi}" संपादन के लिए लोड किया गया।`);
    setTimeout(() => setActionNotice(''), 4000);
  };

  // Reset form to blank / new chapter mode
  const handleCancelEditing = () => {
    setEditingChapterId(null);
    if (onClearEditingChapter) onClearEditingChapter();
    setTitle('');
    setTitleHindi('');
    setIntroHindi('');
    setExplanationHindi('');
    setChapterNumber('1.1');
    setMcqQuestion('');
    setShortQues('');
    setShortAns('');
    setFormError('');
  };

  // Effect if an external chapterToEdit is passed
  useEffect(() => {
    if (chapterToEdit) {
      loadChapterForEditing(chapterToEdit);
    }
  }, [chapterToEdit]);

  // Set default unit when class changes and not editing
  useEffect(() => {
    if (availableUnits.length > 0) {
      const currentExists = availableUnits.some((u) => u.id === selectedUnitId);
      if (!currentExists) {
        setSelectedUnitId(availableUnits[0].id);
      }
    }
  }, [classGrade, availableUnits, selectedUnitId]);

  // Selected unit details
  const currentUnit = availableUnits.find((u) => u.id === selectedUnitId) || availableUnits[0];

  // Helper to load sample data for quick authoring
  const handleLoadSampleTemplate = () => {
    if (classGrade === '11') {
      setTitleHindi('C++ में फंक्शन ओवरलोडिंग एवं रिकर्शन (Function Overloading)');
      setTitle('Function Overloading and Recursion in C++');
      setChapterNumber('3.4');
      setEstimatedMins(35);
      setIntroHindi('नमस्कार विद्यार्थियों! जब एक ही नाम के कई फंक्शन अलग-अलग पैरामीटर के साथ बनाए जाते हैं, तो इसे फंक्शन ओवरलोडिंग कहते हैं। आइए, इसे सरल उदाहरण से समझते हैं।');
      setExplanationHindi(`### 1. Function Overloading क्या है?
C++ में एक ही नाम के दो या अधिक फ़ंक्शंस बनाना जिनकी रिटर्न टाइप या पैरामीटर्स (Arguments) की संख्या/प्रकार भिन्न हो।
- यह **Polymorphism (बहुरूपता)** का संकलन-समय (Compile-time) उदाहरण है।

### 2. Recursion (पुनरावृत्ति):
जब कोई फंक्शन अपने आप को ही बार-बार कॉल करता है जब तक कि बेस कंडीशन पूरी न हो जाए (उदा. फैक्टोरियल n!)।`);
      setTechTerms([
        { term: 'Function Overloading', hindiMeaning: 'फंक्शन अतिभारण', explanation: 'समान नाम लेकिन भिन्न तर्कों वाले फंक्शन।' },
        { term: 'Base Case', hindiMeaning: 'आधार शर्त', explanation: 'रिकर्सिव फंक्शन को अनंत लूप से रोकने वाली अंतिम शर्त।' }
      ]);
      setAnalogyTitle('दैनिक जीवन से उदाहरण: एक ही व्यक्ति के कई रूप');
      setAnalogyScenario('जैसे एक शिक्षक:');
      setAnalogyText('कक्षा में वे शिक्षक हैं, घर पर पिता हैं, और बैंक में ग्राहक हैं। व्यक्ति का नाम एक ही है, पर काम संदर्भ के अनुसार बदल जाता है। यही फंक्शन ओवरलोडिंग है!');
      setAnalogyTakeaway('कंप्यूटर पास किए गए तर्कों के प्रकार से सही फंक्शन चुन लेता है।');
      setDemoLang('cpp');
      setDemoTitle('फंक्शन ओवरलोडिंग का C++ कोड');
      setDemoCode(`#include <iostream.h>
void print(int i) { cout << "पूर्णांक: " << i << endl; }
void print(double f) { cout << "दशमलव: " << f << endl; }

int main() {
    print(10);
    print(3.14);
    return 0;
}`);
      setDemoExplanation('कंप्यूटर 10 देखकर int वाले print() को और 3.14 देखकर double वाले print() को स्वतः कॉल करता है।');
      setPracticalExercise('दो पूर्णांकों और दो दशमलव संख्याओं का योग निकालने के लिए overloaded add() फंक्शन लिखें।');
      setMcqQuestion('फंक्शन ओवरलोडिंग किसका उदाहरण है?');
      setMcqOptions(['Compile-time Polymorphism', 'Run-time Polymorphism', 'Multiple Inheritance', 'Data Hiding']);
      setMcqCorrectIndex(0);
      setMcqExplanation('फंक्शन ओवरलोडिंग कंपाइल समय पर ही तय हो जाती है, अतः यह Compile-time Polymorphism है।');
      setShortQues('फंक्शन ओवरलोडिंग के दो मुख्य नियम लिखिए।');
      setShortAns('1. फंक्शन का नाम एक समान होना चाहिए। 2. उनके पैरामीटर्स की संख्या या डेटा प्रकार में अंतर होना अनिवार्य है। केवल रिटर्न टाइप अलग होने से ओवरलोडिंग नहीं होती।');
    } else {
      setTitleHindi(`${classGrade}वीं कक्षा का विशेष पूरक अध्याय`);
      setTitle(`Special Topic for Class ${classGrade}`);
      setChapterNumber('1.4');
      setIntroHindi('यह अध्याय बिहार बोर्ड के छात्रों के लिए विशेष व्यावहारिक मार्गदर्शन और परीक्षा तैयारी प्रदान करता है।');
      setExplanationHindi('### मुख्य विषय व्याख्या\nयहाँ विस्तृत तकनीकी व्याख्या, सूत्र और सिंटैक्स का विवरण दर्ज किया जा सकता है।');
      setMcqQuestion('इस विषय का मुख्य उद्देश्य क्या है?');
      setMcqOptions(['ज्ञान संवर्धन', 'परीक्षा सफलता', 'प्रायोगिक अभ्यास', 'उपरोक्त सभी']);
      setMcqCorrectIndex(3);
      setMcqExplanation('यह अध्याय समग्र समझ और परीक्षा दोनों के लिए उपयोगी है।');
      setShortQues('इस अध्याय की मुख्य परिभाषा संक्षेप में लिखिए।');
      setShortAns('यह अध्याय छात्रों को व्यावहारिक कौशल और कंप्यूटर विज्ञान के गहन सिद्धांतों से अवगत कराता है।');
    }
  };

  // Save / Update Chapter handler
  const handleSaveOrUpdateChapter = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!titleHindi.trim()) {
      setFormError('कृपया अध्याय का हिंदी नाम दर्ज करें।');
      setFormSection('basic');
      return;
    }
    if (!title.trim()) {
      setFormError('कृपया Chapter Title (English) दर्ज करें।');
      setFormSection('basic');
      return;
    }
    if (!introHindi.trim()) {
      setFormError('कृपया अध्याय का सरल हिंदी परिचय दर्ज करें।');
      setFormSection('notes');
      return;
    }

    const filteredTerms = techTerms.filter((t) => t.term.trim() && t.hindiMeaning.trim());
    const finalTerms: TechnicalTerm[] = filteredTerms.length > 0 ? filteredTerms : [
      { term: title, hindiMeaning: titleHindi, explanation: introHindi.slice(0, 100) }
    ];

    const finalMCQs: MCQQuestion[] = mcqQuestion.trim() ? [
      {
        id: `mcq-${editingChapterId || Date.now()}-1`,
        question: mcqQuestion,
        options: mcqOptions,
        correctIndex: mcqCorrectIndex,
        explanationHindi: mcqExplanation || 'यह सही उत्तर है।',
        isPYQ: false,
      }
    ] : [
      {
        id: `mcq-${editingChapterId || Date.now()}-1`,
        question: `${titleHindi} के संदर्भ में कौन सा कथन सत्य है?`,
        options: ['यह एक महत्वपूर्ण कंप्यूटर सिद्धांत है', 'यह केवल गेमिंग के लिए है', 'यह अप्रचलित हो चुका है', 'उपरोक्त में से कोई नहीं'],
        correctIndex: 0,
        explanationHindi: 'यह एक मान्य और उपयोगी कंप्यूटर साइंस सिद्धांत है।',
      }
    ];

    const finalShortQuestions: ShortQuestion[] = shortQues.trim() ? [
      {
        question: shortQues,
        marks: 2,
        answerHindi: shortAns || introHindi,
      }
    ] : [
      {
        question: `${titleHindi} की परिभाषा लिखिए।`,
        marks: 2,
        answerHindi: introHindi,
      }
    ];

    const targetUnit = currentUnit || { id: `c${classGrade}-u1`, unitNumber: 1, unitCode: 'UNIT-1', title: 'Fundamentals' };

    const chapterPayload: Chapter = {
      id: editingChapterId || `custom-${classGrade}-${Date.now()}`,
      classGrade,
      unitId: targetUnit.id,
      unitNumber: targetUnit.unitNumber,
      chapterNumber: chapterNumber.trim() || '1.1',
      moduleTitle: `${targetUnit.unitCode}: ${targetUnit.title}`,
      title: title.trim(),
      titleHindi: titleHindi.trim(),
      isOfficialSyllabus: isOfficial,
      estimatedMins: Number(estimatedMins) || 25,
      learningObjectives: objectives.filter((o) => o.trim().length > 0),
      introHindi: introHindi.trim(),
      explanationHindi: explanationHindi.trim() || introHindi.trim(),
      technicalTerms: finalTerms,
      realLifeExample: {
        title: analogyTitle.trim() || 'दैनिक जीवन से उदाहरण',
        scenario: analogyScenario.trim() || 'वास्तविक जीवन की परिस्थिति',
        analogy: analogyText.trim() || 'सरल तुलनात्मक व्याख्या',
        takeaway: analogyTakeaway.trim() || 'महत्वपूर्ण समझ',
      },
      practicalDemo: hasPracticalDemo ? {
        title: demoTitle.trim() || 'प्रायोगिक कोड',
        language: demoLang,
        code: demoCode.trim(),
        explanation: demoExplanation.trim() || 'कोड की व्याख्या',
      } : undefined,
      importantPoints: keyPoints.filter((p) => p.trim().length > 0),
      faqs: [{ question: `${titleHindi} क्या है?`, answer: introHindi }],
      mcqs: finalMCQs,
      shortQuestions: finalShortQuestions,
      practicalExercise: practicalExercise.trim() || 'कंप्यूटर लैब में संबंधित कोड का अभ्यास करें।',
    };

    if (editingChapterId) {
      onUpdateChapter(chapterPayload);
      setActionNotice(`अध्याय "${titleHindi}" सफलतापूर्वक अपडेट हो गया!`);
    } else {
      onAddNewChapter(chapterPayload);
      setActionNotice(`नया अध्याय "${titleHindi}" सफलतापूर्वक जोड़ा गया!`);
    }

    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      handleCancelEditing();
      setActiveTab('manage-chapters');
    }, 1200);
  };

  // Delete Chapter handler
  const handleDeleteChapter = (ch: Chapter) => {
    const isConfirmed = window.confirm(`चेतावनी: क्या आप अध्याय "${ch.titleHindi}" (${ch.chapterNumber || ''}) को पाठ्यक्रम से हटाना चाहते हैं?`);
    if (isConfirmed) {
      onDeleteChapter(ch.id);
      if (editingChapterId === ch.id) {
        handleCancelEditing();
      }
      setActionNotice(`अध्याय "${ch.titleHindi}" हटा दिया गया।`);
      setTimeout(() => setActionNotice(''), 3000);
    }
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(chapters, null, 2));
    const dlAnchor = document.createElement('a');
    dlAnchor.setAttribute('href', dataStr);
    dlAnchor.setAttribute('download', `bseb_cs_syllabus_${currentSession}.json`);
    dlAnchor.click();
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPwdMsg(null);

    if (newPassword.length < 6) {
      setPwdMsg({ text: 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।', isError: true });
      return;
    }

    if (newPassword !== confirmPassword) {
      setPwdMsg({ text: 'दोनों पासवर्ड मेल नहीं खाते!', isError: true });
      return;
    }

    const res = updateAdminPassword(newPassword);
    if (!res.success) {
      setPwdMsg({ text: res.errorHindi || 'त्रुटि हुई।', isError: true });
    } else {
      setPwdMsg({ text: 'पासवर्ड सफलतापूर्वक बदल गया! अगली बार इसी नए पासवर्ड से लॉगिन करें।', isError: false });
      setNewPassword('');
      setConfirmPassword('');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/90 rounded-3xl max-w-4xl w-full max-h-[94vh] flex flex-col shadow-2xl overflow-hidden text-slate-100">
        
        {/* Modal Header */}
        <div className="px-5 sm:px-6 py-4 bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 border-b border-blue-600/30 flex items-center justify-between text-white shrink-0">
          <div className="space-y-0.5">
            <div className="flex items-center space-x-2">
              <h2 className="text-base sm:text-lg font-black flex items-center space-x-2">
                <ShieldCheck className="w-5 h-5 text-amber-300" />
                <span>शिक्षक एवं पाठ्यक्रम एडमिन पोर्टल</span>
              </h2>
              <span className="text-[10px] bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full font-black uppercase">
                Admin: Ashish9Singh
              </span>
            </div>
            <p className="text-xs text-blue-100 hidden sm:block">
              अध्याय जोड़ें, नोट्स संपादित करें (Edit) या किसी भी अध्याय को हटाएं (Remove)
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={onLogout}
              className="bg-rose-600/90 hover:bg-rose-600 text-white px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-colors shadow-sm"
              title="एडमिन लॉगआउट करें"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">लॉगआउट</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-200 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action Notice Toast */}
        {actionNotice && (
          <div className="bg-blue-600/20 border-b border-blue-500/30 px-6 py-2 text-xs text-blue-300 font-bold flex items-center space-x-2">
            <Info className="w-4 h-4 text-blue-400 shrink-0" />
            <span>{actionNotice}</span>
          </div>
        )}

        {/* Modal Top Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-850 px-4 sm:px-6 pt-2 space-x-2 sm:space-x-4 text-xs font-bold overflow-x-auto no-scrollbar shrink-0">
          <button
            onClick={() => setActiveTab('add-chapter')}
            className={`pb-2.5 border-b-2 whitespace-nowrap transition-all flex items-center space-x-1.5 ${
              activeTab === 'add-chapter'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {editingChapterId ? (
              <>
                <Edit3 className="w-4 h-4 text-amber-400" />
                <span>अध्याय संपादित करें (Editing Mode)</span>
              </>
            ) : (
              <>
                <PlusCircle className="w-4 h-4 text-amber-400" />
                <span>नया अध्याय जोड़ें (Add Chapter)</span>
              </>
            )}
          </button>

          <button
            onClick={() => setActiveTab('manage-chapters')}
            className={`pb-2.5 border-b-2 whitespace-nowrap transition-all flex items-center space-x-1.5 ${
              activeTab === 'manage-chapters'
                ? 'border-blue-400 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>अध्याय सूची एवं संपादन ({chapters.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('session')}
            className={`pb-2.5 border-b-2 whitespace-nowrap transition-all flex items-center space-x-1.5 ${
              activeTab === 'session'
                ? 'border-blue-400 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>सत्र ({currentSession})</span>
          </button>

          <button
            onClick={() => setActiveTab('password')}
            className={`pb-2.5 border-b-2 whitespace-nowrap transition-all flex items-center space-x-1.5 ${
              activeTab === 'password'
                ? 'border-blue-400 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>पासवर्ड बदलें</span>
          </button>

          <button
            onClick={() => setActiveTab('backup')}
            className={`pb-2.5 border-b-2 whitespace-nowrap transition-all flex items-center space-x-1.5 ${
              activeTab === 'backup'
                ? 'border-blue-400 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>बैकअप & रीसेट</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4 text-xs">
          
          {/* =========================================================================
              TAB 1: ADD OR EDIT CHAPTER FORM
             ========================================================================= */}
          {activeTab === 'add-chapter' && (
            <form onSubmit={handleSaveOrUpdateChapter} className="space-y-5">
              
              {/* If in edit mode, show prominent banner */}
              {editingChapterId ? (
                <div className="bg-amber-950/40 border border-amber-500/40 rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center space-x-2.5">
                    <Edit3 className="w-4 h-4 text-amber-400 shrink-0" />
                    <div>
                      <span className="font-extrabold text-amber-300 block text-xs">
                        संपादित किया जा रहा है: {titleHindi || 'अध्याय'} ({chapterNumber})
                      </span>
                      <span className="text-[11px] text-slate-400">
                        आप नोट्स, व्याख्या, शीर्षक, उदाहरण, कोड एवं परीक्षा प्रश्नों को बदल सकते हैं।
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleCancelEditing}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-xl font-bold flex items-center space-x-1.5 shrink-0"
                  >
                    <Undo2 className="w-3.5 h-3.5" />
                    <span>संपादन रद्द करें (नया पाठ जोड़ें)</span>
                  </button>
                </div>
              ) : (
                /* Quick Presets / Template Bar for Add Mode */
                <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center space-x-2">
                    <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                    <span className="text-slate-300 text-xs">
                      त्वरित सहायता: आप सीधे विवरण लिख सकते हैं या 1-क्लिक में मानक BSEB प्रारूप लोड कर सकते हैं।
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleLoadSampleTemplate}
                    className="bg-blue-600/30 hover:bg-blue-600 border border-blue-500/40 text-blue-200 hover:text-white px-3 py-1.5 rounded-xl font-bold transition-all flex items-center space-x-1.5 shrink-0"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-blue-300" />
                    <span>नमूना टेम्पलेट भरें (Auto-Fill)</span>
                  </button>
                </div>
              )}

              {/* Form Navigation Sub-tabs */}
              <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-2xl border border-slate-800 overflow-x-auto no-scrollbar">
                {[
                  { id: 'basic', label: '1. बुनियादी विवरण व यूनिट', icon: Layers },
                  { id: 'notes', label: '2. विस्तृत व्याख्या व शब्दावली', icon: FileText },
                  { id: 'practical', label: '3. दैनिक जीवन व कोड लैब', icon: Terminal },
                  { id: 'questions', label: '4. वस्तुनिष्ठ व परीक्षा प्रश्न', icon: Award },
                ].map((s) => {
                  const Icon = s.icon;
                  const isActive = formSection === s.id;
                  return (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setFormSection(s.id as any)}
                      className={`px-3 py-2 rounded-xl font-bold flex items-center space-x-1.5 whitespace-nowrap transition-all ${
                        isActive
                          ? 'bg-blue-600 text-white shadow-md'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{s.label}</span>
                    </button>
                  );
                })}
              </div>

              {formError && (
                <div className="bg-rose-950/50 border border-rose-800 rounded-xl p-3 text-rose-300 flex items-start space-x-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}

              {/* SECTION 1: BASIC DETAILS & UNIT */}
              {formSection === 'basic' && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {/* Class */}
                    <div>
                      <label className="font-bold text-slate-300 block mb-1">कक्षा (Class Grade):</label>
                      <select
                        value={classGrade}
                        onChange={(e) => setClassGrade(e.target.value as ClassGrade)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-blue-500"
                      >
                        <option value="9">कक्षा 9 (Class 9)</option>
                        <option value="10">कक्षा 10 (Class 10)</option>
                        <option value="11">कक्षा 11 (Class 11)</option>
                        <option value="12">कक्षा 12 (Class 12)</option>
                      </select>
                    </div>

                    {/* Target Syllabus Unit */}
                    <div className="sm:col-span-2">
                      <label className="font-bold text-slate-300 block mb-1">
                        पाठ्यक्रम यूनिट चुनें (Official Syllabus Unit):
                      </label>
                      <select
                        value={selectedUnitId}
                        onChange={(e) => setSelectedUnitId(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-blue-500"
                      >
                        {availableUnits.map((u) => (
                          <option key={u.id} value={u.id}>
                            {u.unitCode}: {u.titleHindi} {u.marks ? `(${u.marks} अंक)` : ''}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {/* Chapter Code */}
                    <div>
                      <label className="font-bold text-slate-300 block mb-1">अध्याय क्रमांक (Chapter Code):</label>
                      <input
                        type="text"
                        value={chapterNumber}
                        onChange={(e) => setChapterNumber(e.target.value)}
                        placeholder="उदा: 1.3 या 3.4"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    {/* Estimated Study Time */}
                    <div>
                      <label className="font-bold text-slate-300 block mb-1">अध्ययन समय (Estimated Mins):</label>
                      <input
                        type="number"
                        value={estimatedMins}
                        onChange={(e) => setEstimatedMins(Number(e.target.value))}
                        min={10}
                        max={120}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    {/* Official Syllabus Checkbox */}
                    <div className="flex items-center space-x-2 pt-6">
                      <input
                        type="checkbox"
                        id="official-check"
                        checked={isOfficial}
                        onChange={(e) => setIsOfficial(e.target.checked)}
                        className="rounded text-blue-600 focus:ring-0 w-4 h-4"
                      />
                      <label htmlFor="official-check" className="text-slate-300 font-semibold cursor-pointer">
                        आधिकारिक बोर्ड पाठ्यक्रम
                      </label>
                    </div>
                  </div>

                  {/* Hindi & English Titles */}
                  <div>
                    <label className="font-bold text-slate-300 block mb-1">
                      अध्याय का शीर्षक हिंदी में (Hindi Title): *
                    </label>
                    <input
                      type="text"
                      value={titleHindi}
                      onChange={(e) => setTitleHindi(e.target.value)}
                      placeholder="उदा: C++ में फंक्शन ओवरलोडिंग एवं रिकर्शन"
                      required
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-300 block mb-1">
                      Chapter Title in English: *
                    </label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="e.g. Function Overloading and Recursion in C++"
                      required
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white text-sm font-mono focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  {/* Dynamic Learning Objectives */}
                  <div className="space-y-2 pt-2">
                    <label className="font-bold text-slate-300 flex items-center justify-between">
                      <span className="flex items-center space-x-1.5">
                        <ListChecks className="w-4 h-4 text-blue-400" />
                        <span>मुख्य अधिगम बिंदु (Learning Objectives):</span>
                      </span>
                      <span className="text-[11px] text-slate-400">कुल {objectives.length} बिंदु</span>
                    </label>

                    <div className="space-y-2">
                      {objectives.map((obj, idx) => (
                        <div key={idx} className="flex items-center space-x-2">
                          <span className="text-slate-500 font-bold w-5">{idx + 1}.</span>
                          <input
                            type="text"
                            value={obj}
                            onChange={(e) => {
                              const updated = [...objectives];
                              updated[idx] = e.target.value;
                              setObjectives(updated);
                            }}
                            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-white focus:outline-none focus:border-blue-500"
                          />
                          <button
                            type="button"
                            onClick={() => setObjectives(objectives.filter((_, i) => i !== idx))}
                            className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800"
                            title="हटाएं"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center space-x-2 pt-1">
                      <input
                        type="text"
                        value={newObjInput}
                        onChange={(e) => setNewObjInput(e.target.value)}
                        placeholder="नया अधिगम बिंदु जोड़ें..."
                        className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-white text-xs focus:outline-none focus:border-blue-500"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (newObjInput.trim()) {
                            setObjectives([...objectives, newObjInput.trim()]);
                            setNewObjInput('');
                          }
                        }}
                        className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-xl font-bold flex items-center space-x-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>जोड़ें</span>
                      </button>
                    </div>
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={() => setFormSection('notes')}
                      className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded-xl flex items-center space-x-1.5"
                    >
                      <span>अगला: विस्तृत नोट्स भरें</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* SECTION 2: DETAILED NOTES & TECHNICAL TERMS */}
              {formSection === 'notes' && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <label className="font-bold text-slate-300 block mb-1">
                      सरल हिंदी परिचय (Bilingual Intro): *
                    </label>
                    <textarea
                      value={introHindi}
                      onChange={(e) => setIntroHindi(e.target.value)}
                      rows={3}
                      placeholder="विद्यार्थियों के लिए 2-3 पंक्तियों में सरल और आदरसूचक भाषा में परिचय..."
                      required
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-blue-500 leading-relaxed"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-slate-300 block mb-1">
                      विस्तृत व्याख्या एवं 14-बिंदु नोट्स (Detailed Notes - Markdown supported):
                    </label>
                    <textarea
                      value={explanationHindi}
                      onChange={(e) => setExplanationHindi(e.target.value)}
                      rows={8}
                      placeholder="### 1. मुख्य सिद्धांत\nविस्तृत व्याख्या, बिंदुवार नोट्स, तालिकायें, सिंटैक्स..."
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-mono focus:outline-none focus:border-blue-500 leading-relaxed"
                    />
                  </div>

                  {/* Technical Terms List */}
                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-slate-300 flex items-center space-x-1.5">
                        <BookOpen className="w-4 h-4 text-blue-400" />
                        <span>तकनीकी शब्दावली (Technical Terms):</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setTechTerms([...techTerms, { term: '', hindiMeaning: '', explanation: '' }])}
                        className="text-[11px] text-blue-400 hover:underline flex items-center space-x-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>+ नया शब्द जोड़ें</span>
                      </button>
                    </div>

                    <div className="space-y-2">
                      {techTerms.map((term, idx) => (
                        <div key={idx} className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-2">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <input
                              type="text"
                              value={term.term}
                              onChange={(e) => {
                                const updated = [...techTerms];
                                updated[idx].term = e.target.value;
                                setTechTerms(updated);
                              }}
                              placeholder="Technical Term (उदा: Polymorphism)"
                              className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                            />
                            <div className="flex items-center space-x-2">
                              <input
                                type="text"
                                value={term.hindiMeaning}
                                onChange={(e) => {
                                  const updated = [...techTerms];
                                  updated[idx].hindiMeaning = e.target.value;
                                  setTechTerms(updated);
                                }}
                                placeholder="हिंदी अर्थ (उदा: बहुरूपता)"
                                className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
                              />
                              <button
                                type="button"
                                onClick={() => setTechTerms(techTerms.filter((_, i) => i !== idx))}
                                className="p-1.5 text-slate-500 hover:text-rose-400"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                          <input
                            type="text"
                            value={term.explanation}
                            onChange={(e) => {
                              const updated = [...techTerms];
                              updated[idx].explanation = e.target.value;
                              setTechTerms(updated);
                            }}
                            placeholder="सरल 1-पंक्ति व्याख्या..."
                            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white text-[11px]"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setFormSection('basic')}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2 rounded-xl"
                    >
                      ← पिछला
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormSection('practical')}
                      className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded-xl flex items-center space-x-1.5"
                    >
                      <span>अगला: उदाहरण व कोड लैब</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* SECTION 3: REAL-LIFE ANALOGY & CODE LAB */}
              {formSection === 'practical' && (
                <div className="space-y-4 animate-fadeIn">
                  {/* Real Life Analogy Box */}
                  <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3">
                    <label className="font-bold text-amber-300 flex items-center space-x-1.5">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>दैनिक जीवन का उदाहरण (Familiar Indian / Bihar Analogy):</span>
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <span className="text-[10px] text-slate-400 block mb-0.5">उदाहरण का शीर्षक:</span>
                        <input
                          type="text"
                          value={analogyTitle}
                          onChange={(e) => setAnalogyTitle(e.target.value)}
                          placeholder="उदा: डाकघर का लेटर बॉक्स या शादी की प्लेट्स"
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block mb-0.5">परिस्थिति (Scenario):</span>
                        <input
                          type="text"
                          value={analogyScenario}
                          onChange={(e) => setAnalogyScenario(e.target.value)}
                          placeholder="उदा: जब आप डाकघर में पत्र पोस्ट करते हैं..."
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">तुलनात्मक समझ (Analogy):</span>
                      <textarea
                        value={analogyText}
                        onChange={(e) => setAnalogyText(e.target.value)}
                        rows={2}
                        placeholder="दैनिक जीवन की क्रिया को कंप्यूटर सिद्धांत से जोड़कर समझाएं..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white"
                      />
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">मुख्य सीख (Key Takeaway):</span>
                      <input
                        type="text"
                        value={analogyTakeaway}
                        onChange={(e) => setAnalogyTakeaway(e.target.value)}
                        placeholder="उदा: इंडेक्स के माध्यम से डेटा तक तुरंत पहुंचा जा सकता है।"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
                      />
                    </div>
                  </div>

                  {/* Practical Demo & Simulator Code */}
                  <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-emerald-300 flex items-center space-x-1.5">
                        <Terminal className="w-4 h-4 text-emerald-400" />
                        <span>लाइव प्रायोगिक कोड (Practical Code Demo):</span>
                      </label>
                      <div className="flex items-center space-x-2">
                        <span className="text-[11px] text-slate-400">प्रोग्रामिंग भाषा:</span>
                        <select
                          value={demoLang}
                          onChange={(e) => setDemoLang(e.target.value as any)}
                          className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono text-xs"
                        >
                          <option value="cpp">C++ Language</option>
                          <option value="sql">SQL Query</option>
                          <option value="html">HTML Web</option>
                          <option value="pseudo">Pseudocode</option>
                        </select>
                      </div>
                    </div>

                    <input
                      type="text"
                      value={demoTitle}
                      onChange={(e) => setDemoTitle(e.target.value)}
                      placeholder="प्रायोगिक कोड का शीर्षक"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
                    />

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">कोड स्निपेट:</span>
                      <textarea
                        value={demoCode}
                        onChange={(e) => setDemoCode(e.target.value)}
                        rows={5}
                        placeholder="// यहाँ C++, SQL या HTML कोड दर्ज करें..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-emerald-300 font-mono text-xs focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">कोड की संक्षिप्त व्याख्या:</span>
                      <input
                        type="text"
                        value={demoExplanation}
                        onChange={(e) => setDemoExplanation(e.target.value)}
                        placeholder="यह कोड स्क्रीन पर परिणाम प्रदर्शित करता है..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
                      />
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">विद्यार्थियों हेतु लैब अभ्यास (Practical Exercise):</span>
                      <input
                        type="text"
                        value={practicalExercise}
                        onChange={(e) => setPracticalExercise(e.target.value)}
                        placeholder="छात्रों के लिए कंप्यूटर लैब कार्य निर्देश..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
                      />
                    </div>
                  </div>

                  <div className="pt-2 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setFormSection('notes')}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2 rounded-xl"
                    >
                      ← पिछला
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormSection('questions')}
                      className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded-xl flex items-center space-x-1.5"
                    >
                      <span>अगला: परीक्षा प्रश्न व MCQs</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* SECTION 4: EXAM QUESTIONS & MCQS */}
              {formSection === 'questions' && (
                <div className="space-y-4 animate-fadeIn">
                  {/* Practice MCQ */}
                  <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3">
                    <label className="font-bold text-amber-300 flex items-center space-x-1.5">
                      <Award className="w-4 h-4 text-amber-400" />
                      <span>वस्तुनिष्ठ प्रश्न (BSEB Model MCQ):</span>
                    </label>

                    <input
                      type="text"
                      value={mcqQuestion}
                      onChange={(e) => setMcqQuestion(e.target.value)}
                      placeholder="वस्तुनिष्ठ प्रश्न (उदा: C++ में लूप कितने प्रकार के होते हैं?)"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white"
                    />

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {mcqOptions.map((opt, oIdx) => (
                        <div key={oIdx} className="flex items-center space-x-2 bg-slate-900 p-2 rounded-lg border border-slate-800">
                          <input
                            type="radio"
                            name="correct-option"
                            checked={mcqCorrectIndex === oIdx}
                            onChange={() => setMcqCorrectIndex(oIdx)}
                            className="text-amber-400 focus:ring-0"
                          />
                          <input
                            type="text"
                            value={opt}
                            onChange={(e) => {
                              const updated = [...mcqOptions];
                              updated[oIdx] = e.target.value;
                              setMcqOptions(updated);
                            }}
                            className="flex-1 bg-transparent border-none text-white focus:outline-none text-xs"
                          />
                        </div>
                      ))}
                    </div>

                    <input
                      type="text"
                      value={mcqExplanation}
                      onChange={(e) => setMcqExplanation(e.target.value)}
                      placeholder="सही उत्तर का स्पष्टीकरण (Explanation in Hindi)..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white text-[11px]"
                    />
                  </div>

                  {/* Short Exam Question */}
                  <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-2">
                    <label className="font-bold text-blue-300 flex items-center space-x-1.5">
                      <HelpCircle className="w-4 h-4 text-blue-400" />
                      <span>लघु उत्तरीय प्रश्न (2 अंक):</span>
                    </label>

                    <input
                      type="text"
                      value={shortQues}
                      onChange={(e) => setShortQues(e.target.value)}
                      placeholder="प्रश्न (उदा: C++ में कॉल बाई वैल्यू और कॉल बाई रेफरेंस में अंतर स्पष्ट करें।)"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
                    />

                    <textarea
                      value={shortAns}
                      onChange={(e) => setShortAns(e.target.value)}
                      rows={2}
                      placeholder="आदर्श उत्तर (Model Answer in Hindi)..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-white leading-relaxed"
                    />
                  </div>

                  {/* Final Submit Bar */}
                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => setFormSection('practical')}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2.5 rounded-xl"
                    >
                      ← पिछला
                    </button>

                    <div className="flex items-center space-x-3">
                      {savedSuccess && (
                        <span className="text-emerald-400 font-bold flex items-center space-x-1 animate-pulse">
                          <Check className="w-4 h-4" />
                          <span>{editingChapterId ? 'अध्याय अपडेट हो गया!' : 'अध्याय सहेजा गया!'}</span>
                        </span>
                      )}

                      <button
                        type="submit"
                        className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold px-6 py-2.5 rounded-xl shadow-lg shadow-emerald-600/30 transition-all flex items-center space-x-2 text-sm"
                      >
                        <Save className="w-4 h-4" />
                        <span>{editingChapterId ? 'परिवर्तन सहेजें (Update Chapter)' : 'अध्याय सुरक्षित करें (Save Chapter)'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </form>
          )}

          {/* =========================================================================
              TAB 2: MANAGE, EDIT & DELETE LOADED CHAPTERS
             ========================================================================= */}
          {activeTab === 'manage-chapters' && (
            <div className="space-y-4">
              {/* Header and Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <span className="text-slate-400 font-bold px-2 text-[11px]">कक्षा:</span>
                  {(['9', '10', '11', '12'] as ClassGrade[]).map((c) => (
                    <button
                      key={c}
                      onClick={() => setManageClassFilter(c)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                        manageClassFilter === c
                          ? 'bg-blue-600 text-white'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      कक्षा {c}
                    </button>
                  ))}
                </div>

                <div className="relative flex-1 max-w-xs">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={manageSearch}
                    onChange={(e) => setManageSearch(e.target.value)}
                    placeholder="अध्याय खोजें..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Chapters List Table */}
              <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden">
                <div className="p-3 bg-slate-900 border-b border-slate-800 flex justify-between items-center text-slate-400 font-bold text-[11px]">
                  <span>कक्षा {manageClassFilter} के अध्याय ({managedChapters.length})</span>
                  <span>कार्रवाई (Edit / Delete)</span>
                </div>

                <div className="divide-y divide-slate-850 max-h-[50vh] overflow-y-auto">
                  {managedChapters.length === 0 ? (
                    <div className="p-8 text-center text-slate-500">कोई अध्याय नहीं मिला।</div>
                  ) : (
                    managedChapters.map((ch) => (
                      <div
                        key={ch.id}
                        className="p-3.5 hover:bg-slate-900/60 transition-colors flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0 flex-1 space-y-0.5">
                          <div className="flex items-center space-x-2">
                            <span className="text-[10px] font-black bg-amber-400/20 text-amber-300 border border-amber-400/30 px-1.5 py-0.2 rounded font-mono">
                              अध्याय {ch.chapterNumber || '1.1'}
                            </span>
                            <span className="text-[10px] text-blue-400 font-semibold truncate">
                              {ch.moduleTitle}
                            </span>
                            {ch.isOfficialSyllabus ? (
                              <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1.5 rounded font-bold">
                                आधिकारिक
                              </span>
                            ) : (
                              <span className="text-[9px] bg-purple-500/20 text-purple-300 px-1.5 rounded font-bold">
                                कस्टम
                              </span>
                            )}
                          </div>
                          <h4 className="text-xs font-bold text-white truncate">{ch.titleHindi}</h4>
                          <p className="text-[11px] text-slate-400 font-mono truncate">{ch.title}</p>
                        </div>

                        {/* Action buttons: View, Edit, Remove */}
                        <div className="flex items-center space-x-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => setPreviewChapter(previewChapter?.id === ch.id ? null : ch)}
                            className="bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white px-2.5 py-1.5 rounded-lg text-[11px] font-bold flex items-center space-x-1"
                            title="विवरण देखें"
                          >
                            <Eye className="w-3.5 h-3.5 text-blue-400" />
                            <span className="hidden sm:inline">{previewChapter?.id === ch.id ? 'बंद' : 'विवरण'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => loadChapterForEditing(ch)}
                            className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 px-2.5 py-1.5 rounded-lg text-[11px] font-bold flex items-center space-x-1 transition-all"
                            title="अध्याय संपादित करें"
                          >
                            <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                            <span>संपादित करें (Edit)</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteChapter(ch)}
                            className="bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 px-2.5 py-1.5 rounded-lg text-[11px] font-bold flex items-center space-x-1 transition-all"
                            title="अध्याय हटाएं"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">हटाएं</span>
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Chapter Details Preview Modal/Card if selected */}
              {previewChapter && (
                <div className="bg-slate-950 p-4 rounded-2xl border border-blue-500/40 space-y-2.5 animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-bold text-amber-400">
                        अध्याय {previewChapter.chapterNumber}: {previewChapter.titleHindi}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">({previewChapter.title})</span>
                    </div>
                    <button
                      onClick={() => setPreviewChapter(null)}
                      className="text-slate-400 hover:text-white text-xs font-bold"
                    >
                      ✕
                    </button>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{previewChapter.introHindi}</p>
                  
                  {previewChapter.technicalTerms && previewChapter.technicalTerms.length > 0 && (
                    <div className="pt-1">
                      <span className="text-[11px] font-bold text-blue-400 block mb-1">तकनीकी शब्दावली:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {previewChapter.technicalTerms.map((t, i) => (
                          <span key={i} className="text-[10px] bg-slate-800 text-slate-200 px-2 py-0.5 rounded font-mono">
                            {t.term} ({t.hindiMeaning})
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {previewChapter.practicalDemo && (
                    <div className="pt-1">
                      <span className="text-[11px] font-bold text-emerald-400 block mb-0.5">प्रायोगिक कोड:</span>
                      <pre className="p-2.5 bg-slate-900 rounded-xl text-emerald-300 font-mono text-[11px] overflow-x-auto max-h-32">
                        {previewChapter.practicalDemo.code}
                      </pre>
                    </div>
                  )}

                  <div className="pt-2 flex justify-end space-x-2">
                    <button
                      type="button"
                      onClick={() => loadChapterForEditing(previewChapter)}
                      className="bg-amber-500/20 text-amber-300 border border-amber-500/40 px-3 py-1 rounded-xl text-xs font-bold flex items-center space-x-1"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>यह अध्याय संपादित करें</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteChapter(previewChapter)}
                      className="bg-rose-500/20 text-rose-300 border border-rose-500/40 px-3 py-1 rounded-xl text-xs font-bold flex items-center space-x-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>यह अध्याय हटाएं</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* =========================================================================
              TAB 3: SESSION SETTINGS
             ========================================================================= */}
          {activeTab === 'session' && (
            <div className="space-y-4 max-w-md">
              <div className="space-y-1">
                <label className="font-bold text-slate-200 block">सक्रिय शैक्षणिक सत्र (Academic Session):</label>
                <input
                  type="text"
                  value={sessionInput}
                  onChange={(e) => setSessionInput(e.target.value)}
                  placeholder="उदा: 2026-2027"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-white font-mono"
                />
              </div>

              <button
                type="button"
                onClick={() => {
                  if (sessionInput.trim()) {
                    onUpdateSession(sessionInput.trim());
                    alert('सत्र सफलतापूर्वक अपडेट किया गया!');
                  }
                }}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded-xl flex items-center space-x-1.5"
              >
                <Check className="w-4 h-4" />
                <span>सत्र सहेजें</span>
              </button>
            </div>
          )}

          {/* =========================================================================
              TAB 4: PASSWORD CHANGE
             ========================================================================= */}
          {activeTab === 'password' && (
            <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
              {pwdMsg && (
                <div className={`p-3 rounded-xl border text-xs flex items-center space-x-2 ${
                  pwdMsg.isError ? 'bg-rose-950/50 border-rose-800 text-rose-300' : 'bg-emerald-950/50 border-emerald-800 text-emerald-300'
                }`}>
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{pwdMsg.text}</span>
                </div>
              )}

              <div className="space-y-1">
                <label className="font-bold text-slate-200 block">नया पासवर्ड (New Password):</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="कम से कम 6 अक्षर..."
                  required
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-white font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-200 block">नया पासवर्ड दोबारा लिखें (Confirm):</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="वही पासवर्ड दोबारा लिखें..."
                  required
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-white font-mono"
                />
              </div>

              <button
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2.5 rounded-xl shadow-lg shadow-emerald-600/30 flex items-center space-x-1.5"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>पासवर्ड अपडेट करें</span>
              </button>
            </form>
          )}

          {/* =========================================================================
              TAB 5: BACKUP & FACTORY RESET
             ========================================================================= */}
          {activeTab === 'backup' && (
            <div className="space-y-6">
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-white text-sm">पाठ्यक्रम डेटा बैकअप (JSON Export)</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    वर्तमान सभी {chapters.length} अध्यायों की प्रतिलिपि JSON फाइल में डाउनलोड करें।
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleExportJSON}
                  className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded-xl flex items-center space-x-1.5"
                >
                  <Download className="w-4 h-4" />
                  <span>डाउनलोड करें</span>
                </button>
              </div>

              <div className="bg-rose-950/20 p-4 rounded-2xl border border-rose-900/40 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-rose-300 text-sm">डिफ़ॉल्ट पाठ्यक्रम पर रीसेट करें</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    सभी कस्टम बदलाव हटाकर आधिकारिक मूल पाठ्यक्रम पुनः स्थापित करें।
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('क्या आप सचमुच पाठ्यक्रम को मूल आधिकारिक अवस्था में रीसेट करना चाहते हैं?')) {
                      onResetSyllabusToDefault();
                      alert('पाठ्यक्रम मूल स्थिति में रीसेट हो गया!');
                    }
                  }}
                  className="bg-rose-700 hover:bg-rose-600 text-white font-bold px-4 py-2 rounded-xl flex items-center space-x-1.5"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>रीसेट करें</span>
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
