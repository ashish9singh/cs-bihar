import React, { useState, useEffect } from 'react';
import { 
  Gamepad2, 
  RotateCcw, 
  Trophy, 
  Sparkles, 
  Code2, 
  HelpCircle, 
  Check, 
  X, 
  ChevronRight,
  Brain,
  Hash,
  Type
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const CSGames: React.FC = () => {
  const [activeGame, setActiveGame] = useState<'tictactoe' | 'memory' | 'hangman' | 'cowsnbulls'>('tictactoe');

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-16">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                BSEB Class 11 Event Programming
              </span>
              <span className="text-xs text-slate-400">आधिकारिक पाठ्यक्रम निर्धारित 4 खेल</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">CS Educational Games Hub</h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              खेल-खेल में सीखिए 2D Arrays, स्ट्रिंग मैनिपुलेशन और C++ इवेंट प्रोग्रामिंग लॉजिक!
            </p>
          </div>
        </div>

        {/* Game Switcher Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3 mt-5 pt-4 border-t border-slate-800">
          {[
            { id: 'tictactoe', label: '1. Cross \'N Knots', sub: '2D Array Tic-Tac-Toe', icon: Hash },
            { id: 'memory', label: '2. Memory Game', sub: '2D Array Pairs', icon: Brain },
            { id: 'hangman', label: '3. Hollywood / Hangman', sub: 'String Functions', icon: Type },
            { id: 'cowsnbulls', label: '4. Cows \'N Bulls', sub: 'Number Deduction', icon: Trophy },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeGame === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveGame(tab.id as any)}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white border-blue-500 shadow-md shadow-blue-600/30 font-bold'
                    : 'bg-slate-850 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <Icon className="w-4 h-4" />
                  <span className="text-xs sm:text-sm font-bold truncate">{tab.label}</span>
                </div>
                <span className="text-[10px] text-slate-300/80 block mt-1 truncate">{tab.sub}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* GAME 1: CROSS 'N KNOTS (TIC-TAC-TOE) */}
      {activeGame === 'tictactoe' && <TicTacToeGame />}

      {/* GAME 2: MEMORY GAME (2D ARRAY) */}
      {activeGame === 'memory' && <MemoryPairsGame />}

      {/* GAME 3: HOLLYWOOD / HANGMAN */}
      {activeGame === 'hangman' && <HangmanGame />}

      {/* GAME 4: COWS 'N BULLS */}
      {activeGame === 'cowsnbulls' && <CowsAndBullsGame />}
    </div>
  );
};

// ==========================================
// 1. TIC TAC TOE (Cross 'N Knots)
// ==========================================
function TicTacToeGame() {
  const [board, setBoard] = useState<string[]>(Array(9).fill(''));
  const [isXNext, setIsXNext] = useState<boolean>(true);
  const [vsAi, setVsAi] = useState<boolean>(true);

  const calculateWinner = (squares: string[]) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // Cols
      [0, 4, 8], [2, 4, 6],             // Diagonals
    ];
    for (const [a, b, c] of lines) {
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    return squares.every(Boolean) ? 'Tie' : null;
  };

  const winner = calculateWinner(board);

  useEffect(() => {
    if (winner && winner !== 'Tie') {
      confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
    }
  }, [winner]);

  // AI Move
  useEffect(() => {
    if (vsAi && !isXNext && !winner) {
      const emptyIndices = board.map((val, idx) => (val === '' ? idx : null)).filter((val) => val !== null) as number[];
      if (emptyIndices.length > 0) {
        const timer = setTimeout(() => {
          const randomIndex = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
          const newBoard = [...board];
          newBoard[randomIndex] = 'O';
          setBoard(newBoard);
          setIsXNext(true);
        }, 300);
        return () => clearTimeout(timer);
      }
    }
  }, [isXNext, vsAi, winner, board]);

  const handleClick = (idx: number) => {
    if (board[idx] || winner || (vsAi && !isXNext)) return;
    const newBoard = [...board];
    newBoard[idx] = isXNext ? 'X' : 'O';
    setBoard(newBoard);
    setIsXNext(!isXNext);
  };

  const handleReset = () => {
    setBoard(Array(9).fill(''));
    setIsXNext(true);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Game Board */}
      <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold text-slate-300">मोड:</span>
            <button
              onClick={() => { setVsAi(true); handleReset(); }}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                vsAi ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              vs कंप्यूटर AI
            </button>
            <button
              onClick={() => { setVsAi(false); handleReset(); }}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                !vsAi ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              2-Player
            </button>
          </div>

          <button
            onClick={handleReset}
            className="flex items-center space-x-1 text-xs text-slate-400 hover:text-white bg-slate-800 px-3 py-1.5 rounded-lg"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>रीसेट</span>
          </button>
        </div>

        {/* Status */}
        <div className="text-center py-2">
          {winner ? (
            <div className="text-sm sm:text-base font-extrabold text-amber-400">
              {winner === 'Tie' ? '🤝 खेल बराबरी (Draw) पर समाप्त हुआ!' : `🎉 विजेता: खिलाड़ी '${winner}' की जीत हुई!`}
            </div>
          ) : (
            <div className="text-xs sm:text-sm font-semibold text-slate-300">
              वर्तमान चाल: <strong className="text-cyan-400 font-mono text-base">{isXNext ? 'X' : 'O'}</strong> {vsAi && !isXNext && '(कंप्यूटर सोच रहा है...)'}
            </div>
          )}
        </div>

        {/* 3x3 Grid */}
        <div className="max-w-xs mx-auto grid grid-cols-3 gap-3 p-4 bg-slate-950 rounded-2xl border border-slate-800">
          {board.map((val, idx) => (
            <button
              key={idx}
              onClick={() => handleClick(idx)}
              className={`h-20 sm:h-24 rounded-xl text-3xl sm:text-4xl font-black font-mono flex items-center justify-center transition-all ${
                val === 'X'
                  ? 'text-cyan-400 bg-cyan-950/30 border border-cyan-800/60'
                  : val === 'O'
                  ? 'text-amber-400 bg-amber-950/30 border border-amber-800/60'
                  : 'bg-slate-900 border border-slate-800 hover:bg-slate-850 hover:border-slate-700'
              }`}
            >
              {val}
            </button>
          ))}
        </div>
      </div>

      {/* C++ Code Connection (Syllabus Concept) */}
      <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
        <h3 className="font-bold text-white text-sm flex items-center space-x-2">
          <Code2 className="w-4 h-4 text-emerald-400" />
          <span>C++ 2D Array लॉजिक (Class 11 Event Programming)</span>
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          यह खेल C++ में 2D Array <code className="bg-slate-800 text-cyan-300 px-1 py-0.5 rounded font-mono">char board[3][3]</code> के अनुप्रयोग को प्रदर्शित करता है:
        </p>

        <pre className="bg-slate-950 p-3 rounded-xl font-mono text-[11px] text-emerald-300 border border-slate-800 overflow-x-auto leading-relaxed">
{`char board[3][3] = {
  {'${board[0] || ' '}', '${board[1] || ' '}', '${board[2] || ' '}'},
  {'${board[3] || ' '}', '${board[4] || ' '}', '${board[5] || ' '}'},
  {'${board[6] || ' '}', '${board[7] || ' '}', '${board[8] || ' '}'}
};

// जीत की जाँच (Check Rows & Cols)
for(int i = 0; i < 3; i++) {
  if(board[i][0] == board[i][1] && 
     board[i][1] == board[i][2] && 
     board[i][0] != ' ')
     return true; // पंक्ति में जीत
}`}
        </pre>

        <div className="bg-blue-950/20 p-2.5 rounded-xl border border-blue-900/30 text-[11px] text-blue-200">
          💡 <strong>परीक्षा ज्ञान:</strong> 2D Array में अवयवों को <code className="text-cyan-300">board[row][col]</code> द्वारा एक्सेस किया जाता है।
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 2. MEMORY PAIRS GAME (2D Array)
// ==========================================
function MemoryPairsGame() {
  const cardsIcons = ['10', '10', '25', '25', '42', '42', '64', '64', '80', '80', '99', '99', '128', '128', '256', '256'];
  
  const [cards, setCards] = useState<string[]>(() => [...cardsIcons].sort(() => Math.random() - 0.5));
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState<number>(0);

  const handleCardClick = (index: number) => {
    if (flipped.length === 2 || flipped.includes(index) || matched.includes(index)) return;

    const newFlipped = [...flipped, index];
    setFlipped(newFlipped);

    if (newFlipped.length === 2) {
      setMoves((m) => m + 1);
      const [first, second] = newFlipped;
      if (cards[first] === cards[second]) {
        setMatched((prev) => {
          const next = [...prev, first, second];
          if (next.length === cards.length) {
            confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
          }
          return next;
        });
        setFlipped([]);
      } else {
        setTimeout(() => setFlipped([]), 800);
      }
    }
  };

  const handleReset = () => {
    setCards([...cardsIcons].sort(() => Math.random() - 0.5));
    setFlipped([]);
    setMatched([]);
    setMoves(0);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 text-xs font-bold text-slate-300">
            <span>चालें (Moves): <strong className="text-white">{moves}</strong></span>
            <span>जोड़े मिले: <strong className="text-emerald-400">{matched.length / 2} / 8</strong></span>
          </div>
          <button
            onClick={handleReset}
            className="flex items-center space-x-1 text-xs text-slate-400 hover:text-white bg-slate-800 px-3 py-1.5 rounded-lg"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>नया खेल</span>
          </button>
        </div>

        {matched.length === cards.length && (
          <div className="text-center py-2 text-sm font-extrabold text-emerald-400 bg-emerald-950/40 p-3 rounded-2xl border border-emerald-800">
            🎉 बधाई! आपने केवल {moves} चालों में सभी 2D Array जोड़े खोज निकाले!
          </div>
        )}

        {/* 4x4 Grid (16 Cards) */}
        <div className="grid grid-cols-4 gap-2.5 max-w-sm mx-auto p-3 bg-slate-950 rounded-2xl border border-slate-800">
          {cards.map((val, idx) => {
            const isRevealed = flipped.includes(idx) || matched.includes(idx);
            return (
              <button
                key={idx}
                onClick={() => handleCardClick(idx)}
                className={`h-16 sm:h-20 rounded-xl font-mono font-bold text-base sm:text-lg flex items-center justify-center transition-all ${
                  isRevealed
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-850 border border-slate-700/80 text-transparent hover:border-blue-500/60'
                }`}
              >
                {isRevealed ? val : '?'}
              </button>
            );
          })}
        </div>
      </div>

      <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
        <h3 className="font-bold text-white text-sm flex items-center space-x-2">
          <Brain className="w-4 h-4 text-cyan-400" />
          <span>मेमोरी गेम C++ संकल्पना (2D Array Grid)</span>
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          बिहार बोर्ड कक्षा 11 के इवेंट प्रोग्रामिंग पाठ्यक्रम के अनुसार, यह खेल 4x4 के 2-डायमेंशनल एरे में यादृच्छिक संख्याओं के जोड़ों को खोजने के सिद्धांत पर आधारित है।
        </p>

        <pre className="bg-slate-950 p-3 rounded-xl font-mono text-[11px] text-cyan-300 border border-slate-800 overflow-x-auto leading-relaxed">
{`int memoryGrid[4][4];
bool revealed[4][4] = {false};

// यादृच्छिक संख्या जोड़े भरना
void initializeGrid() {
  // 8 जोड़ों को रैंडम बॉक्स में सहेजना
  randomize();
}`}
        </pre>
      </div>
    </div>
  );
}

// ==========================================
// 3. HOLLYWOOD / HANGMAN (String Game)
// ==========================================
function HangmanGame() {
  const words = [
    { word: 'COMPILER', hint: 'सोर्स कोड को मशीन कोड में बदलने वाला' },
    { word: 'POINTER', hint: 'मेमोरी पता (Address) सहेजने वाला चर' },
    { word: 'DATABASE', hint: 'आपस में जुड़े डेटा का सुव्यवस्थित संग्रह' },
    { word: 'ROUTER', hint: 'नेटवर्क में डेटा पैकेट को रास्ता दिखाने वाला' },
    { word: 'VARIABLE', hint: 'मेमोरी में मान सहेजने वाला डिब्बा' },
    { word: 'KEYBOARD', hint: 'सबसे आम इनपुट डिवाइस' },
  ];

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [guessedLetters, setGuessedLetters] = useState<string[]>([]);
  const [lives, setLives] = useState<number>(6);

  const currentItem = words[currentIndex];
  const word = currentItem.word;

  const isWon = word.split('').every((letter) => guessedLetters.includes(letter));
  const isLost = lives <= 0;

  useEffect(() => {
    if (isWon) {
      confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
    }
  }, [isWon]);

  const handleGuess = (letter: string) => {
    if (guessedLetters.includes(letter) || isWon || isLost) return;
    setGuessedLetters((prev) => [...prev, letter]);
    if (!word.includes(letter)) {
      setLives((l) => l - 1);
    }
  };

  const handleNextWord = () => {
    setCurrentIndex((prev) => (prev + 1) % words.length);
    setGuessedLetters([]);
    setLives(6);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="text-xs text-slate-300">
            बचे हुए जीवन: <strong className={lives <= 2 ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>{lives} / 6</strong>
          </div>
          <button
            onClick={handleNextWord}
            className="flex items-center space-x-1 text-xs text-blue-400 hover:text-white bg-slate-800 px-3 py-1.5 rounded-lg"
          >
            <span>अगला शब्द</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Word Display */}
        <div className="text-center py-6 bg-slate-950 rounded-2xl border border-slate-800">
          <div className="text-xs text-slate-400 mb-2">💡 संकेत: {currentItem.hint}</div>
          <div className="flex justify-center space-x-2 text-2xl sm:text-3xl font-black font-mono tracking-widest text-white">
            {word.split('').map((letter, idx) => (
              <span key={idx} className="border-b-4 border-blue-500 pb-1 px-1">
                {guessedLetters.includes(letter) || isLost ? letter : '_'}
              </span>
            ))}
          </div>

          {isWon && <div className="mt-4 text-emerald-400 font-bold text-sm">🎉 शाबाश! आपने सही शब्द बूझ लिया!</div>}
          {isLost && <div className="mt-4 text-rose-400 font-bold text-sm">खेल समाप्त! सही शब्द था: {word}</div>}
        </div>

        {/* Alphabet Keyboard */}
        <div className="grid grid-cols-7 sm:grid-cols-9 gap-1.5 pt-2">
          {'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((ch) => {
            const isUsed = guessedLetters.includes(ch);
            return (
              <button
                key={ch}
                disabled={isUsed || isWon || isLost}
                onClick={() => handleGuess(ch)}
                className={`h-9 rounded-lg font-mono font-bold text-xs transition-all ${
                  isUsed
                    ? 'bg-slate-950 text-slate-600 border border-slate-900'
                    : 'bg-slate-800 hover:bg-blue-600 text-white border border-slate-700'
                }`}
              >
                {ch}
              </button>
            );
          })}
        </div>
      </div>

      <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
        <h3 className="font-bold text-white text-sm flex items-center space-x-2">
          <Type className="w-4 h-4 text-amber-400" />
          <span>C++ स्ट्रिंग फ़ंक्शंस (Hollywood / Hangman)</span>
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          यह खेल C++ में स्ट्रिंग्स और अक्षरों की जाँच (<code className="text-cyan-300">string.h</code> और <code className="text-cyan-300">ctype.h</code>) के उपयोग का व्यावहारिक उदाहरण है।
        </p>

        <pre className="bg-slate-950 p-3 rounded-xl font-mono text-[11px] text-amber-300 border border-slate-800 overflow-x-auto leading-relaxed">
{`char secret[] = "${word}";
char guess = 'E';

// अक्षर की खोज
bool found = false;
for(int i = 0; i < strlen(secret); i++) {
  if(toupper(guess) == secret[i]) {
    found = true;
  }
}`}
        </pre>
      </div>
    </div>
  );
}

// ==========================================
// 4. COWS 'N BULLS (Number Deduction)
// ==========================================
function CowsAndBullsGame() {
  const [secret, setSecret] = useState<string>('4821');
  const [guessInput, setGuessInput] = useState<string>('');
  const [history, setHistory] = useState<{ guess: string; bulls: number; cows: number }[]>([]);
  const [isWon, setIsWon] = useState<boolean>(false);

  const generateSecret = () => {
    const digits = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];
    digits.sort(() => Math.random() - 0.5);
    const code = digits.slice(0, 4).join('');
    setSecret(code);
    setHistory([]);
    setIsWon(false);
    setGuessInput('');
  };

  const handleGuessSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (guessInput.length !== 4 || isWon) return;

    let bulls = 0;
    let cows = 0;

    for (let i = 0; i < 4; i++) {
      if (guessInput[i] === secret[i]) {
        bulls++;
      } else if (secret.includes(guessInput[i])) {
        cows++;
      }
    }

    setHistory((prev) => [{ guess: guessInput, bulls, cows }, ...prev]);
    setGuessInput('');

    if (bulls === 4) {
      setIsWon(true);
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <p className="text-xs text-slate-300">
            4 अलग-अलग अंकों वाली गुप्त संख्या खोजें (उदा: 4281):
          </p>
          <button
            onClick={generateSecret}
            className="flex items-center space-x-1 text-xs text-slate-400 hover:text-white bg-slate-800 px-3 py-1.5 rounded-lg"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>नई संख्या</span>
          </button>
        </div>

        <form onSubmit={handleGuessSubmit} className="flex space-x-2">
          <input
            type="text"
            maxLength={4}
            value={guessInput}
            onChange={(e) => setGuessInput(e.target.value.replace(/[^0-9]/g, ''))}
            placeholder="4 अंकों का अनुमान..."
            disabled={isWon}
            className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 font-mono text-base text-white focus:outline-none focus:border-blue-500"
          />
          <button
            type="submit"
            disabled={guessInput.length !== 4 || isWon}
            className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold px-5 py-2.5 rounded-xl text-xs"
          >
            जाँचें
          </button>
        </form>

        {isWon && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-800 text-emerald-300 rounded-2xl text-xs font-bold text-center">
            🎉 अद्भुत! आपने गुप्त संख्या {secret} को सफलतापूर्वक खोज लिया!
          </div>
        )}

        {/* Guess History */}
        <div className="bg-slate-950 rounded-2xl border border-slate-800 p-3 max-h-56 overflow-y-auto space-y-1.5 text-xs font-mono">
          <div className="grid grid-cols-3 font-bold text-slate-400 pb-1 border-b border-slate-800 text-[11px]">
            <span>अनुमान (Guess)</span>
            <span>Bulls (सटीक स्थान)</span>
            <span>Cows (गलत स्थान)</span>
          </div>
          {history.map((h, idx) => (
            <div key={idx} className="grid grid-cols-3 text-slate-200 py-1">
              <span className="text-cyan-400 font-bold">{h.guess}</span>
              <span className="text-emerald-400 font-bold">{h.bulls} 🎯</span>
              <span className="text-amber-400">{h.cows} 🐮</span>
            </div>
          ))}
          {history.length === 0 && (
            <p className="text-slate-500 text-center py-4 text-xs font-sans">
              पहला अनुमान लगाकर खेल शुरू करें।
            </p>
          )}
        </div>
      </div>

      <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
        <h3 className="font-bold text-white text-sm flex items-center space-x-2">
          <Trophy className="w-4 h-4 text-emerald-400" />
          <span>Cows 'N Bulls C++ लॉजिक</span>
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          - <strong>Bull:</strong> सही अंक और सही स्थिति।<br />
          - <strong>Cow:</strong> अंक सही है पर स्थिति गलत है।
        </p>

        <pre className="bg-slate-950 p-3 rounded-xl font-mono text-[11px] text-emerald-300 border border-slate-800 overflow-x-auto leading-relaxed">
{`int bulls = 0, cows = 0;
for(int i = 0; i < 4; i++) {
  if(guess[i] == secret[i])
     bulls++;
  else if(contains(secret, guess[i]))
     cows++;
}`}
        </pre>
      </div>
    </div>
  );
}
