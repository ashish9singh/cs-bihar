import React, { useState } from 'react';
import { 
  Network, 
  Send, 
  Wifi, 
  Server, 
  Laptop, 
  Smartphone, 
  Radio, 
  Layers, 
  CheckCircle, 
  HelpCircle,
  Activity,
  Globe,
  ShieldCheck,
  Cpu
} from 'lucide-react';

export const NetworkingLab: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'topologies' | 'scales' | 'packet-sim' | 'osi-model'>('topologies');
  const [selectedTopology, setSelectedTopology] = useState<'star' | 'bus' | 'ring'>('star');
  const [packetStatus, setPacketStatus] = useState<'idle' | 'encapsulating' | 'in-transit' | 'server-processing' | 'delivered'>('idle');
  const [packetMessage, setPacketMessage] = useState<string>('BSEB Result Request: Roll 1042');
  const [activeNode, setActiveNode] = useState<number | null>(null);

  // Packet simulator animation trigger
  const handleSendPacket = () => {
    if (packetStatus !== 'idle') return;

    setPacketStatus('encapsulating');
    setTimeout(() => {
      setPacketStatus('in-transit');
      setTimeout(() => {
        setPacketStatus('server-processing');
        setTimeout(() => {
          setPacketStatus('delivered');
          setTimeout(() => {
            setPacketStatus('idle');
          }, 3500);
        }, 1200);
      }, 1400);
    }, 1000);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                चित्रात्मक व इंटरैक्टिव नेटवर्किंग
              </span>
              <span className="text-xs text-slate-400">कक्षा 11 व 12 नेटवर्किंग मॉड्यूल</span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1">Computer Networking Visualizer</h1>
            <p className="text-sm text-slate-300 mt-1">
              टोपोलॉजी, LAN/MAN/WAN, क्लाइंट-सर्वर और पैकेट संचरण को सजीव चित्रों और एनिमेशन द्वारा समझें।
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex space-x-2 mt-4 pt-4 border-t border-slate-800 overflow-x-auto no-scrollbar">
          {[
            { id: 'topologies', label: '1. नेटवर्क टोपोलॉजी (Star, Bus, Ring)', icon: Network },
            { id: 'scales', label: '2. नेटवर्क के प्रकार (LAN, MAN, WAN)', icon: Globe },
            { id: 'packet-sim', label: '3. डेटा पैकेट सिमुलेटर (Packet Flow)', icon: Activity },
            { id: 'osi-model', label: '4. OSI और TCP/IP मॉडल', icon: Layers },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-750 hover:text-white border border-slate-700/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: TOPOLOGIES */}
      {activeTab === 'topologies' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-lg text-white">सजीव टोपोलॉजी डायग्राम (Topology Visualizer)</h2>
              <div className="flex space-x-1 bg-slate-800 p-1 rounded-lg text-xs">
                {(['star', 'bus', 'ring'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setSelectedTopology(t)}
                    className={`px-3 py-1 rounded font-bold capitalize transition-all ${
                      selectedTopology === t
                        ? 'bg-blue-600 text-white shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {t === 'star' ? 'Star टोपोलॉजी' : t === 'bus' ? 'Bus टोपोलॉजी' : 'Ring टोपोलॉजी'}
                  </button>
                ))}
              </div>
            </div>

            {/* Visual Canvas Area */}
            <div className="bg-slate-950 rounded-xl p-8 min-h-[380px] flex items-center justify-center border border-slate-800 relative overflow-hidden">
              {/* STAR TOPOLOGY DIAGRAM */}
              {selectedTopology === 'star' && (
                <div className="relative w-full max-w-md h-72 flex items-center justify-center">
                  {/* Central Hub/Switch */}
                  <div className="z-20 w-24 h-24 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 border-2 border-cyan-400 flex flex-col items-center justify-center shadow-lg shadow-blue-500/40 animate-pulse">
                    <Cpu className="w-7 h-7 text-white" />
                    <span className="text-[11px] font-black text-white mt-1">HUB / SWITCH</span>
                    <span className="text-[9px] text-cyan-200">केंद्रीय उपकरण</span>
                  </div>

                  {/* Connected Nodes */}
                  {[
                    { label: 'PC 1 (Patna)', pos: '-top-4 left-4' },
                    { label: 'PC 2 (Gaya)', pos: '-top-4 right-4' },
                    { label: 'PC 3 (Muzaffarpur)', pos: '-bottom-4 left-4' },
                    { label: 'PC 4 (Bhagalpur)', pos: '-bottom-4 right-4' },
                  ].map((node, idx) => (
                    <div
                      key={idx}
                      onClick={() => setActiveNode(idx)}
                      className={`absolute ${node.pos} z-20 cursor-pointer transition-transform hover:scale-110`}
                    >
                      <div className="w-16 h-16 rounded-xl bg-slate-800 border-2 border-blue-500/60 flex flex-col items-center justify-center p-1 text-center shadow-md">
                        <Laptop className="w-5 h-5 text-cyan-400" />
                        <span className="text-[9px] font-bold text-slate-200 mt-1 leading-tight">{node.label}</span>
                      </div>
                    </div>
                  ))}

                  {/* Connecting visual lines */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none stroke-blue-500/60 stroke-2 stroke-dashed">
                    <line x1="20%" y1="15%" x2="50%" y2="50%" />
                    <line x1="80%" y1="15%" x2="50%" y2="50%" />
                    <line x1="20%" y1="85%" x2="50%" y2="50%" />
                    <line x1="80%" y1="85%" x2="50%" y2="50%" />
                  </svg>
                </div>
              )}

              {/* BUS TOPOLOGY DIAGRAM */}
              {selectedTopology === 'bus' && (
                <div className="relative w-full max-w-lg py-12 flex flex-col items-center">
                  <div className="text-xs font-mono text-cyan-400 mb-2">
                    मुख्य बैकबोन केबल (Backbone Cable with Terminators)
                  </div>

                  {/* Main Bus Trunk Cable */}
                  <div className="w-full h-3 bg-gradient-to-r from-amber-600 via-cyan-500 to-amber-600 rounded relative shadow-lg shadow-cyan-500/20">
                    <span className="absolute -left-6 -top-2 bg-rose-600 text-white text-[9px] px-1 py-0.5 rounded font-mono">
                      Terminator
                    </span>
                    <span className="absolute -right-6 -top-2 bg-rose-600 text-white text-[9px] px-1 py-0.5 rounded font-mono">
                      Terminator
                    </span>
                  </div>

                  {/* T-Connectors and PCs */}
                  <div className="w-full grid grid-cols-4 gap-4 mt-6">
                    {[1, 2, 3, 4].map((id) => (
                      <div key={id} className="flex flex-col items-center">
                        <div className="w-0.5 h-6 bg-cyan-400/80 stroke-dashed"></div>
                        <div className="w-16 h-16 rounded-xl bg-slate-800 border-2 border-slate-700 flex flex-col items-center justify-center p-1 shadow">
                          <Laptop className="w-5 h-5 text-amber-400" />
                          <span className="text-[10px] font-bold text-slate-300 mt-1">Node {id}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* RING TOPOLOGY DIAGRAM */}
              {selectedTopology === 'ring' && (
                <div className="relative w-64 h-64 flex items-center justify-center">
                  {/* Outer Ring Circle */}
                  <div className="absolute inset-0 rounded-full border-4 border-dashed border-cyan-500/50 animate-spin" style={{ animationDuration: '24s' }} />

                  {/* 4 Ring Nodes */}
                  {[
                    { label: 'नोड A', pos: 'top-0 left-1/2 -translate-x-1/2' },
                    { label: 'नोड B', pos: 'right-0 top-1/2 -translate-y-1/2' },
                    { label: 'नोड C', pos: 'bottom-0 left-1/2 -translate-x-1/2' },
                    { label: 'नोड D', pos: 'left-0 top-1/2 -translate-y-1/2' },
                  ].map((node, i) => (
                    <div key={i} className={`absolute ${node.pos} z-10`}>
                      <div className="w-14 h-14 rounded-full bg-slate-800 border-2 border-emerald-400 flex flex-col items-center justify-center shadow-lg">
                        <Laptop className="w-4 h-4 text-emerald-400" />
                        <span className="text-[9px] font-bold text-white">{node.label}</span>
                      </div>
                    </div>
                  ))}

                  <div className="text-center p-2 z-10 bg-slate-900/90 rounded-xl border border-slate-700">
                    <span className="text-[10px] font-bold text-cyan-300 block">Token Ring</span>
                    <span className="text-[9px] text-slate-400">टोकन केवल एक दिशा में घूमता है</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Explanation Column */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
              <h3 className="font-bold text-white text-base flex items-center space-x-2">
                <Network className="w-4 h-4 text-cyan-400" />
                <span>
                  {selectedTopology === 'star' ? 'Star टोपोलॉजी (सबसे लोकप्रिय)' : selectedTopology === 'bus' ? 'Bus टोपोलॉजी' : 'Ring टोपोलॉजी'}
                </span>
              </h3>

              <div className="mt-3 space-y-3 text-xs text-slate-300 leading-relaxed">
                {selectedTopology === 'star' && (
                  <>
                    <p>
                      **कार्यप्रणाली:** सभी कंप्यूटर एक केंद्रीय उपकरण (**Hub या Switch**) से अलग-अलग केबल द्वारा जुड़े होते हैं।
                    </p>
                    <div className="bg-emerald-950/30 p-2.5 rounded-lg border border-emerald-900/40 text-emerald-300">
                      <strong>✅ सबसे बड़ा लाभ:</strong> यदि किसी एक कंप्यूटर या उसकी केबल में खराबी आए, तो पूरा नेटवर्क बंद नहीं होता।
                    </div>
                    <div className="bg-rose-950/30 p-2.5 rounded-lg border border-rose-900/40 text-rose-300">
                      <strong>❌ हानि:</strong> यदि बीच का Hub/Switch ही खराब हो जाए, तो पूरा नेटवर्क ठप हो जाता है।
                    </div>
                  </>
                )}

                {selectedTopology === 'bus' && (
                  <>
                    <p>
                      **कार्यप्रणाली:** सभी कंप्यूटर एक ही मुख्य तार (Backbone Cable) से जुड़े होते हैं। दोनों सिरों पर टर्मिनेटर लगे होते हैं।
                    </p>
                    <div className="bg-emerald-950/30 p-2.5 rounded-lg border border-emerald-900/40 text-emerald-300">
                      <strong>✅ लाभ:</strong> कम केबल लगती है और सेटअप बहुत सस्ता होता है।
                    </div>
                    <div className="bg-rose-950/30 p-2.5 rounded-lg border border-rose-900/40 text-rose-300">
                      <strong>❌ हानि:</strong> यदि मुख्य बैकबोन केबल बीच से कट जाए, तो पूरा नेटवर्क तुरंत बंद हो जाता है।
                    </div>
                  </>
                )}

                {selectedTopology === 'ring' && (
                  <>
                    <p>
                      **कार्यप्रणाली:** प्रत्येक कंप्यूटर अपने आस-पास के दो कंप्यूटरों से जुड़कर एक बंद घेरा बनाता है। डेटा एक ही दिशा में बहता है।
                    </p>
                    <div className="bg-emerald-950/30 p-2.5 rounded-lg border border-emerald-900/40 text-emerald-300">
                      <strong>✅ लाभ:</strong> डेटा टकराव (Collision) नहीं होता क्योंकि डेटा भेजने के लिए टोकन की आवश्यकता होती है।
                    </div>
                    <div className="bg-rose-950/30 p-2.5 rounded-lg border border-rose-900/40 text-rose-300">
                      <strong>❌ हानि:</strong> यदि एक भी नोड खराब हुआ, तो टोकन पास नहीं होगा और पूरा रिंग रुक जाएगा।
                    </div>
                  </>
                )}

                <div className="pt-2 border-t border-slate-800 text-[11px] text-cyan-300">
                  🎯 <strong>BSEB बोर्ड प्रश्न:</strong> "Star और Bus टोपोलॉजी में अंतर स्पष्ट कीजिए" (2 या 5 अंक में पूछा जाता है)।
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SCALES (LAN, MAN, WAN) */}
      {activeTab === 'scales' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* LAN */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center mb-3 border border-blue-500/30">
                <Laptop className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded">
                सीमित क्षेत्र
              </span>
              <h3 className="text-xl font-black text-white mt-2">LAN (Local Area Network)</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                यह एक छोटे और सीमित क्षेत्र (जैसे एक कमरा, स्कूल की कंप्यूटर लैब या एक कार्यालय भवन) में फैला नेटवर्क होता है।
              </p>

              <div className="mt-4 space-y-2 text-xs">
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-400">दायरा (Range):</strong> 1 किलोमीटर के अंदर
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-400">गति (Speed):</strong> 100 Mbps से 1 Gbps (अत्यंत तेज)
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-400">बिहार संदर्भ उदाहरण:</strong> पटना के किसी हाई स्कूल की कंप्यूटर लैब के आपस में जुड़े 20 कंप्यूटर और 1 प्रिंटर।
                </div>
              </div>
            </div>
          </div>

          {/* MAN */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center mb-3 border border-indigo-500/30">
                <Radio className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded">
                नगर क्षेत्र
              </span>
              <h3 className="text-xl font-black text-white mt-2">MAN (Metropolitan Area Network)</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                यह पूरे शहर या बड़े महानगर में कई LAN नेटवर्क्स को आपस में जोड़ने वाला नेटवर्क है।
              </p>

              <div className="mt-4 space-y-2 text-xs">
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-400">दायरा (Range):</strong> 5 से 50 किलोमीटर (पूरा शहर)
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-400">गति (Speed):</strong> मध्यम से उच्च (ऑप्टिकल फाइबर आधारित)
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-400">बिहार संदर्भ उदाहरण:</strong> पटना नगर निगम का सर्विलांस कैमरा नेटवर्क या शहर भर का केबल टीवी नेटवर्क।
                </div>
              </div>
            </div>
          </div>

          {/* WAN */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center mb-3 border border-cyan-500/30">
                <Globe className="w-6 h-6" />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded">
                विश्वव्यापी क्षेत्र
              </span>
              <h3 className="text-xl font-black text-white mt-2">WAN (Wide Area Network)</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                यह संपूर्ण देश, महाद्वीप या पूरी पृथ्वी पर फैले लाखों कंप्यूटरों को जोड़ने वाला सबसे विशाल नेटवर्क है।
              </p>

              <div className="mt-4 space-y-2 text-xs">
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-400">दायरा (Range):</strong> असीमित (वैश्विक / Global)
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-400">माध्यम:</strong> उपग्रह (Satellite), समुद्र के नीचे बिछी केबल्स
                </div>
                <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                  <strong className="text-slate-400">सर्वोत्तम उदाहरण:</strong> **इंटरनेट (Internet)** और भारतीय रेलवे आरक्षण प्रणाली (IRCTC)।
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: PACKET TRANSMISSION SIMULATOR */}
      {activeTab === 'packet-sim' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="max-w-2xl">
            <h2 className="text-xl font-bold text-white">इंटरैक्टिव डेटा पैकेट सिमुलेटर (Packet Flow Animation)</h2>
            <p className="text-xs text-slate-300 mt-1">
              जब आप अपने मोबाइल से बिहार बोर्ड रिजल्ट देखते हैं, तो आपका संदेश इंटरनेट पर छोटे-छोटे पैकेट्स में कैसे यात्रा करता है, यहाँ लाइव देखें!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <input
              type="text"
              value={packetMessage}
              onChange={(e) => setPacketMessage(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-blue-500"
              placeholder="क्लाइंट संदेश..."
            />
            <button
              onClick={handleSendPacket}
              disabled={packetStatus !== 'idle'}
              className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 text-white font-bold px-6 py-2.5 rounded-xl text-xs flex items-center justify-center space-x-2 shadow-lg shadow-cyan-500/20 active:scale-95 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>पैकेट भेजें (Send Packet)</span>
            </button>
          </div>

          {/* Visual Simulation Stage */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 sm:p-8 relative overflow-hidden">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 items-center text-center">
              {/* Node 1: Student Phone (Client) */}
              <div className="flex flex-col items-center">
                <div className={`w-20 h-20 rounded-2xl flex flex-col items-center justify-center p-2 border-2 transition-all ${
                  packetStatus === 'encapsulating' ? 'border-amber-400 bg-amber-950/40 scale-105 shadow-lg shadow-amber-500/30' : 'border-slate-700 bg-slate-850'
                }`}>
                  <Smartphone className="w-8 h-8 text-cyan-400" />
                  <span className="text-[10px] font-bold text-white mt-1">छात्र मोबाइल</span>
                </div>
                <span className="text-[11px] text-slate-400 font-mono mt-2">IP: 192.168.1.15</span>
              </div>

              {/* Node 2: Local Router (Gateway) */}
              <div className="flex flex-col items-center">
                <div className={`w-20 h-20 rounded-2xl flex flex-col items-center justify-center p-2 border-2 transition-all ${
                  packetStatus === 'in-transit' ? 'border-blue-400 bg-blue-950/40 scale-105 animate-pulse' : 'border-slate-700 bg-slate-850'
                }`}>
                  <Wifi className="w-8 h-8 text-blue-400" />
                  <span className="text-[10px] font-bold text-white mt-1">राउटर (Patna)</span>
                </div>
                <span className="text-[11px] text-slate-400 font-mono mt-2">IP: 103.24.12.1</span>
              </div>

              {/* Node 3: Internet WAN Backbone */}
              <div className="flex flex-col items-center">
                <div className={`w-20 h-20 rounded-2xl flex flex-col items-center justify-center p-2 border-2 transition-all ${
                  packetStatus === 'in-transit' ? 'border-indigo-400 bg-indigo-950/40 animate-pulse' : 'border-slate-700 bg-slate-850'
                }`}>
                  <Globe className="w-8 h-8 text-indigo-400" />
                  <span className="text-[10px] font-bold text-white mt-1">WAN Cloud</span>
                </div>
                <span className="text-[11px] text-slate-400 font-mono mt-2">TCP/IP Protocol</span>
              </div>

              {/* Node 4: BSEB Server (Destination) */}
              <div className="flex flex-col items-center">
                <div className={`w-20 h-20 rounded-2xl flex flex-col items-center justify-center p-2 border-2 transition-all ${
                  packetStatus === 'server-processing' || packetStatus === 'delivered'
                    ? 'border-emerald-400 bg-emerald-950/40 scale-105 shadow-lg shadow-emerald-500/30'
                    : 'border-slate-700 bg-slate-850'
                }`}>
                  <Server className="w-8 h-8 text-emerald-400" />
                  <span className="text-[10px] font-bold text-white mt-1">BSEB सर्वर</span>
                </div>
                <span className="text-[11px] text-slate-400 font-mono mt-2">IP: 164.100.80.20</span>
              </div>
            </div>

            {/* Status Message Banner */}
            <div className="mt-8 pt-4 border-t border-slate-800 text-center">
              {packetStatus === 'idle' && (
                <p className="text-xs text-slate-400">सिमुलेशन शुरू करने के लिए ऊपर "पैकेट भेजें" दबाएँ।</p>
              )}
              {packetStatus === 'encapsulating' && (
                <p className="text-xs text-amber-400 font-bold animate-pulse">
                  चरण 1: संदेश को TCP/IP हेडर और IP Address के साथ पैकेट में बाँधा जा रहा है (Encapsulation)...
                </p>
              )}
              {packetStatus === 'in-transit' && (
                <p className="text-xs text-cyan-400 font-bold animate-pulse">
                  चरण 2: पैकेट तारों और राउटर्स के माध्यम से पटना से सर्वर की ओर गतिमान है (Routing)...
                </p>
              )}
              {packetStatus === 'server-processing' && (
                <p className="text-xs text-indigo-400 font-bold animate-pulse">
                  चरण 3: BSEB सर्वर ने पैकेट खोला और डेटाबेस में रोल नंबर खोज रहा है...
                </p>
              )}
              {packetStatus === 'delivered' && (
                <div className="inline-flex items-center space-x-2 text-xs text-emerald-400 font-bold bg-emerald-950/40 px-4 py-2 rounded-xl border border-emerald-800">
                  <CheckCircle className="w-4 h-4" />
                  <span>सफलतापूर्वक प्राप्त! HTTP 200 OK: छात्र का रिजल्ट स्क्रीन पर भेजा गया।</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: OSI MODEL VS TCP/IP */}
      {activeTab === 'osi-model' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* OSI 7 Layers */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h3 className="font-bold text-white text-base mb-1">OSI Reference Model (7 लेयर्स)</h3>
            <p className="text-xs text-slate-400 mb-4">
              इंटरनेशनल ऑर्गनाइजेशन फॉर स्टैंडर्डाइजेशन (ISO) द्वारा निर्मित सैद्धांतिक मॉडल:
            </p>

            <div className="space-y-2">
              {[
                { num: 7, name: 'Application Layer', hindi: 'उपयोगकर्ता इंटरफ़ेस (HTTP, FTP, SMTP)' },
                { num: 6, name: 'Presentation Layer', hindi: 'डेटा रूपांतरण और एन्क्रिप्शन (SSL/TLS)' },
                { num: 5, name: 'Session Layer', hindi: 'सत्र (Session) की शुरुआत और समाप्ति' },
                { num: 4, name: 'Transport Layer', hindi: 'एंड-टू-एंड संचार और त्रुटि जाँच (TCP, UDP)' },
                { num: 3, name: 'Network Layer', hindi: 'राउटिंग और आईपी पता (IP Address, Router)' },
                { num: 2, name: 'Data Link Layer', hindi: 'फ्रेम्स और फिजिकल पता (MAC Address, Switch)' },
                { num: 1, name: 'Physical Layer', hindi: 'भौतिक तार, रेडियो तरंगें और बिट्स (0 और 1)' },
              ].map((layer) => (
                <div key={layer.num} className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <span className="w-6 h-6 rounded-lg bg-blue-600/30 text-blue-400 border border-blue-500/40 text-xs font-bold flex items-center justify-center">
                      L{layer.num}
                    </span>
                    <span className="text-xs font-bold text-slate-200">{layer.name}</span>
                  </div>
                  <span className="text-[11px] text-slate-400">{layer.hindi}</span>
                </div>
              ))}
            </div>
          </div>

          {/* TCP/IP 4 Layers */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
            <div>
              <h3 className="font-bold text-white text-base mb-1">TCP/IP Model (4 व्यावहारिक लेयर्स)</h3>
              <p className="text-xs text-slate-400 mb-4">
                इंटरनेट का वास्तविक कार्यकारी आर्किटेक्चर:
              </p>

              <div className="space-y-3">
                {[
                  { name: 'Application Layer', covers: 'OSI की L7, L6, L5 को मिलाकर', proto: 'HTTP, HTTPS, DNS, FTP' },
                  { name: 'Transport Layer', covers: 'सटीक वही जो OSI की L4 है', proto: 'TCP (विश्वसनीय) और UDP (तीव्र)' },
                  { name: 'Internet Layer', covers: 'OSI की Network Layer (L3)', proto: 'IP (IPv4, IPv6), ICMP' },
                  { name: 'Network Access Layer', covers: 'OSI की Data Link (L2) और Physical (L1)', proto: 'Ethernet, Wi-Fi, MAC' },
                ].map((tcp, i) => (
                  <div key={i} className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-cyan-300">{tcp.name}</span>
                      <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                        {tcp.proto}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">{tcp.covers}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 bg-blue-950/20 p-3 rounded-xl border border-blue-900/30 text-xs text-blue-200">
              💡 <strong>याद रखने की युक्ति (Trick):</strong> "All People Seem To Need Data Processing" (Application, Presentation, Session, Transport, Network, Data Link, Physical).
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
