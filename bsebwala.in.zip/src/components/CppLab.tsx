import React, { useState } from 'react';
import { 
  Play, 
  RotateCcw, 
  HelpCircle, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Terminal, 
  BookOpen, 
  Copy, 
  Check,
  ChevronDown,
  Info
} from 'lucide-react';
import { cppProgramPresets } from '../data/cppPrograms';
import { validateAndRunCpp, CppRunResult } from '../utils/cppRunner';
import { incrementLabCount } from '../utils/storage';

interface CppLabProps {
  onAskAIAboutCode: (code: string, title: string) => void;
}

export const CppLab: React.FC<CppLabProps> = ({ onAskAIAboutCode }) => {
  const [selectedPresetId, setSelectedPresetId] = useState<string>('prog-1');
  const [code, setCode] = useState<string>(cppProgramPresets[0].code);
  const [customInput, setCustomInput] = useState<string>(cppProgramPresets[0].defaultInput || '');
  const [runResult, setRunResult] = useState<CppRunResult | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [showExplanation, setShowExplanation] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  const currentPreset = cppProgramPresets.find((p) => p.id === selectedPresetId) || cppProgramPresets[0];

  const handleSelectPreset = (id: string) => {
    const preset = cppProgramPresets.find((p) => p.id === id);
    if (preset) {
      setSelectedPresetId(id);
      setCode(preset.code);
      setCustomInput(preset.defaultInput || '');
      setRunResult(null);
    }
  };

  const handleRunCode = () => {
    setIsRunning(true);
    setTimeout(() => {
      const result = validateAndRunCpp(code, customInput);
      setRunResult(result);
      setIsRunning(false);
      incrementLabCount('cpp');
    }, 250);
  };

  const handleResetToDefault = () => {
    setCode(currentPreset.code);
    setCustomInput(currentPreset.defaultInput || '');
    setRunResult(null);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Line numbering
  const lineCount = code.split('\n').length;
  const lineNumbers = Array.from({ length: Math.max(lineCount, 15) }, (_, i) => i + 1);

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Title & Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">
                इंटरैक्टिव प्रोग्रामिंग लैब
              </span>
              <span className="text-xs text-slate-400">कक्षा 11 व 12 C++ पाठ्यक्रम</span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1">C++ Programming Virtual Lab</h1>
            <p className="text-sm text-slate-300 mt-1">
              लिखिए, संपादित कीजिए और चलाकर देखिए C++ कोड! हर पंक्ति का अर्थ सरल हिंदी में समझें।
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => onAskAIAboutCode(code, currentPreset.title)}
              className="flex items-center space-x-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-md shadow-indigo-600/30 transition-all active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>AI शिक्षक से इस कोड को समझें</span>
            </button>
          </div>
        </div>

        {/* Program Preset Selector Buttons */}
        <div className="mt-4 pt-4 border-t border-slate-800">
          <label className="text-xs font-semibold text-slate-400 block mb-2">
            बिहार बोर्ड के 10 मानक अभ्यास प्रोग्राम्स चुनें:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
            {cppProgramPresets.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handleSelectPreset(preset.id)}
                className={`text-left px-3 py-2 rounded-xl text-xs font-medium border transition-all ${
                  selectedPresetId === preset.id
                    ? 'bg-blue-600/30 border-blue-500 text-blue-300 font-bold shadow-sm'
                    : 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:bg-slate-750 hover:text-white'
                }`}
              >
                <div className="truncate">{preset.titleHindi}</div>
                <div className="text-[10px] text-slate-400 truncate mt-0.5">{preset.category}</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Editor & Execution Output Split View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Code Editor (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden flex flex-col">
          {/* Editor Header Bar */}
          <div className="bg-slate-850 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-rose-500/80"></span>
              <span className="w-3 h-3 rounded-full bg-amber-500/80"></span>
              <span className="w-3 h-3 rounded-full bg-emerald-500/80"></span>
              <span className="text-xs font-mono font-bold text-slate-300 ml-2">main.cpp</span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopyCode}
                className="text-slate-400 hover:text-white p-1 text-xs flex items-center space-x-1"
                title="कोड कॉपी करें"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">{copied ? 'कॉपी हुआ' : 'कॉपी'}</span>
              </button>
              <button
                onClick={handleResetToDefault}
                className="text-slate-400 hover:text-white p-1 text-xs flex items-center space-x-1"
                title="मूल कोड पर रीसेट करें"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">रीसेट</span>
              </button>
              <button
                onClick={handleRunCode}
                disabled={isRunning}
                className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold px-3 py-1.5 rounded-lg text-xs flex items-center space-x-1.5 shadow-md shadow-emerald-600/30 transition-all"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isRunning ? 'चल रहा है...' : 'कोड चलाएँ (Run)'}</span>
              </button>
            </div>
          </div>

          {/* Code Text Area with Line Numbers */}
          <div className="flex flex-1 min-h-[360px] bg-slate-950 font-mono text-xs sm:text-sm">
            {/* Line numbers column */}
            <div className="w-10 bg-slate-900/70 border-r border-slate-800 py-3 select-none text-slate-500 text-right pr-2 font-mono text-xs">
              {lineNumbers.slice(0, lineCount).map((n) => (
                <div key={n} className="leading-6">
                  {n}
                </div>
              ))}
            </div>

            {/* Editable code text */}
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="flex-1 bg-transparent text-emerald-300 p-3 leading-6 focus:outline-none resize-none font-mono selection:bg-blue-600 selection:text-white"
              spellCheck={false}
              autoCapitalize="off"
              autoComplete="off"
            />
          </div>

          {/* User Input Drawer (cin) */}
          <div className="bg-slate-900 border-t border-slate-800 p-3">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1">
                <span>इनपुट डेटा (cin Input Stream):</span>
                <span className="text-[10px] text-slate-500">(संख्याएँ स्पेस देकर लिखें)</span>
              </label>
              {currentPreset.defaultInput && (
                <button
                  onClick={() => setCustomInput(currentPreset.defaultInput || '')}
                  className="text-[11px] text-blue-400 hover:underline"
                >
                  डिफ़ॉल्ट मान भरें ({currentPreset.defaultInput})
                </button>
              )}
            </div>
            <input
              type="text"
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              placeholder="उदाहरण: 15 25"
              className="w-full bg-slate-950 border border-slate-700/80 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Right: Output Console & Diagnostics (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Terminal Console */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden flex flex-col">
            <div className="bg-slate-850 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
                <Terminal className="w-4 h-4 text-cyan-400" />
                <span>टर्मिनल आउटपुट (Terminal Console)</span>
              </div>
              {runResult && (
                <span className="text-[11px] text-slate-400 font-mono">
                  {runResult.executionTimeMs}ms • Code 0
                </span>
              )}
            </div>

            <div className="p-4 bg-slate-950 min-h-[220px] font-mono text-xs leading-relaxed overflow-x-auto text-slate-100">
              {runResult ? (
                <div>
                  {runResult.errorsHindi.length > 0 ? (
                    <div className="text-rose-400 space-y-2">
                      <div className="font-bold flex items-center space-x-1">
                        <AlertTriangle className="w-4 h-4 shrink-0" />
                        <span>कंपाइलेशन त्रुटि (Syntax Errors Found):</span>
                      </div>
                      {runResult.errorsHindi.map((err, i) => (
                        <p key={i} className="pl-5 bg-rose-950/40 p-2 rounded border border-rose-800/40 text-rose-300">
                          {err}
                        </p>
                      ))}
                    </div>
                  ) : (
                    <div>
                      <div className="text-emerald-400 font-semibold mb-2 flex items-center space-x-1.5">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>सफलतापूर्वक निष्पादित (Execution Successful):</span>
                      </div>
                      <pre className="whitespace-pre-wrap text-slate-200 bg-slate-900/60 p-3 rounded-lg border border-slate-800">
                        {runResult.output}
                      </pre>
                    </div>
                  )}

                  {runResult.warningsHindi.length > 0 && (
                    <div className="mt-3 pt-2 border-t border-slate-800 text-amber-300 text-[11px]">
                      <span className="font-bold">सावधानी / Warning:</span>
                      {runResult.warningsHindi.map((w, idx) => (
                        <p key={idx} className="mt-0.5">• {w}</p>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-slate-500 py-10 text-center">
                  <Play className="w-8 h-8 mx-auto text-slate-600 mb-2 opacity-50" />
                  <p>कोड का परिणाम देखने के लिए ऊपर हरे "कोड चलाएँ (Run)" बटन पर क्लिक करें।</p>
                  <p className="text-[11px] mt-1 text-slate-600">
                    अपेक्षित परिणाम (Sample Output):
                  </p>
                  <pre className="mt-2 text-[11px] text-slate-400 text-left bg-slate-900/50 p-2 rounded max-h-24 overflow-y-auto">
                    {currentPreset.expectedOutput}
                  </pre>
                </div>
              )}
            </div>

            <div className="bg-slate-900 px-4 py-2 text-[11px] text-slate-400 border-t border-slate-800 flex items-center space-x-1.5">
              <Info className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span>सत्यापित C++ सिमुलेशन वातावरण • इनपुट-आउटपुट स्ट्रीम समर्थित</span>
            </div>
          </div>

          {/* Line-by-Line Hindi Explanation Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
            <button
              onClick={() => setShowExplanation(!showExplanation)}
              className="w-full flex items-center justify-between text-left font-bold text-sm text-slate-100 hover:text-blue-400 transition-colors"
            >
              <span className="flex items-center space-x-2">
                <BookOpen className="w-4 h-4 text-blue-400" />
                <span>इस प्रोग्राम की लाइन-बाय-लाइन व्याख्या (Hindi)</span>
              </span>
              <ChevronDown className={`w-4 h-4 transition-transform ${showExplanation ? 'rotate-180' : ''}`} />
            </button>

            {showExplanation && (
              <div className="mt-3 pt-3 border-t border-slate-800 space-y-2.5 max-h-72 overflow-y-auto pr-1">
                <p className="text-xs text-slate-300 leading-relaxed bg-blue-950/30 p-2.5 rounded-lg border border-blue-900/40">
                  {currentPreset.descriptionHindi}
                </p>

                {currentPreset.lineByLine.map((item, idx) => (
                  <div key={idx} className="bg-slate-950/80 p-2 rounded-lg border border-slate-800 text-xs">
                    <code className="text-cyan-300 font-mono block font-semibold">{item.line}</code>
                    <p className="text-slate-300 mt-1 pl-1 text-[11px] leading-relaxed">
                      👉 {item.hindi}
                    </p>
                  </div>
                ))}

                {currentPreset.commonMistakes.length > 0 && (
                  <div className="mt-3 pt-2 border-t border-slate-800">
                    <span className="text-[11px] font-bold text-amber-400 block mb-1">
                      ⚠️ छात्र यहाँ गलतियाँ करते हैं:
                    </span>
                    {currentPreset.commonMistakes.map((m, idx) => (
                      <div key={idx} className="text-[11px] text-slate-300 mb-1">
                        <span className="text-rose-400">गलती: </span>{m.mistake}
                        <br />
                        <span className="text-emerald-400">सुझाव: </span>{m.solution}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
