import React, { useState } from 'react';
import { 
  CheckSquare, 
  Clock, 
  Check, 
  X, 
  RotateCcw, 
  Award, 
  Bookmark, 
  HelpCircle,
  Filter,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Chapter, MCQQuestion, ClassGrade } from '../types';
import { recordQuizScore, toggleBookmarkQuestion } from '../utils/storage';

interface MCQPracticeProps {
  chapters: Chapter[];
  selectedClass: ClassGrade;
  bookmarkedQuestionIds: string[];
  onToggleBookmark: (qId: string) => void;
}

export const MCQPractice: React.FC<MCQPracticeProps> = ({
  chapters,
  selectedClass,
  bookmarkedQuestionIds,
  onToggleBookmark,
}) => {
  const [filterClass, setFilterClass] = useState<ClassGrade>(selectedClass);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [isTestMode, setIsTestMode] = useState<boolean>(false);

  // Collect all MCQs matching class
  const classChapters = chapters.filter((c) => c.classGrade === filterClass);
  const allQuestions: { chapterTitle: string; mcq: MCQQuestion }[] = [];
  classChapters.forEach((ch) => {
    ch.mcqs.forEach((m) => {
      allQuestions.push({ chapterTitle: ch.titleHindi, mcq: m });
    });
  });

  const handleSelect = (qId: string, optIdx: number) => {
    if (isSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [qId]: optIdx }));
  };

  const handleSubmit = () => {
    setIsSubmitted(true);
    let correct = 0;
    allQuestions.forEach(({ mcq }) => {
      if (selectedAnswers[mcq.id] === mcq.correctIndex) correct++;
    });

    recordQuizScore(`mcq-room-c${filterClass}`, correct, allQuestions.length);

    if (correct >= Math.ceil(allQuestions.length * 0.7)) {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    }
  };

  const handleReset = () => {
    setSelectedAnswers({});
    setIsSubmitted(false);
  };

  const correctTotal = allQuestions.filter(
    ({ mcq }) => selectedAnswers[mcq.id] === mcq.correctIndex
  ).length;

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">
                वस्तुनिष्ठ प्रश्न अभ्यास कक्ष
              </span>
              <span className="text-xs text-slate-400">कक्षा 9वीं – 12वीं BSEB OMR पैटर्न</span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1">MCQ Practice & Speed Test</h1>
            <p className="text-sm text-slate-300 mt-1">
              अध्याय-वार एवं संपूर्ण कक्षा के वस्तुनिष्ठ प्रश्नों का गहन अभ्यास।
            </p>
          </div>

          <div className="flex items-center space-x-2">
            {/* Filter by class */}
            <div className="flex items-center space-x-1 bg-slate-850 p-1 rounded-xl border border-slate-700">
              <span className="text-xs font-semibold px-2 text-slate-400">कक्षा:</span>
              {(['9', '10', '11', '12'] as ClassGrade[]).map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    setFilterClass(c);
                    handleReset();
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                    filterClass === c
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Score and Reset row */}
        {isSubmitted && (
          <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between">
            <span className="text-sm font-bold text-emerald-400 flex items-center space-x-2">
              <Award className="w-5 h-5" />
              <span>
                परिणाम: {correctTotal} / {allQuestions.length} सही (
                {allQuestions.length > 0 ? ((correctTotal / allQuestions.length) * 100).toFixed(0) : 0}%)
              </span>
            </span>
            <button
              onClick={handleReset}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center space-x-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>पुनः अभ्यास करें</span>
            </button>
          </div>
        )}
      </div>

      {/* Questions Stream */}
      <div className="space-y-4">
        {allQuestions.map(({ chapterTitle, mcq }, qIdx) => {
          const selectedOpt = selectedAnswers[mcq.id];
          const isAnswered = selectedOpt !== undefined;
          const isBookmarked = bookmarkedQuestionIds.includes(mcq.id);

          return (
            <div key={mcq.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider block mb-1">
                    {chapterTitle} {mcq.bsebYear && `• ${mcq.bsebYear}`}
                  </span>
                  <span className="text-xs sm:text-sm font-bold text-slate-100 flex items-start space-x-2">
                    <span className="text-blue-400 font-mono shrink-0">#{qIdx + 1}.</span>
                    <span>{mcq.question}</span>
                  </span>
                </div>

                <button
                  onClick={() => onToggleBookmark(mcq.id)}
                  className={`p-1.5 rounded-lg border transition-colors ${
                    isBookmarked
                      ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                      : 'text-slate-400 hover:text-white border-slate-800 hover:bg-slate-800'
                  }`}
                  title={isBookmarked ? 'बुकमार्क हटाया' : 'रिवीजन के लिए बुकमार्क करें'}
                >
                  <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {mcq.options.map((opt, oIdx) => {
                  let btnStyle = 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-850';

                  if (selectedOpt === oIdx) {
                    btnStyle = 'bg-blue-600/30 border-blue-500 text-blue-200 font-bold';
                  }

                  if (isSubmitted) {
                    if (oIdx === mcq.correctIndex) {
                      btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-300 font-bold';
                    } else if (selectedOpt === oIdx && oIdx !== mcq.correctIndex) {
                      btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-300 font-bold';
                    }
                  }

                  return (
                    <button
                      key={oIdx}
                      disabled={isSubmitted}
                      onClick={() => handleSelect(mcq.id, oIdx)}
                      className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all ${btnStyle}`}
                    >
                      <div className="flex items-center space-x-2">
                        <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-400 text-xs font-bold flex items-center justify-center shrink-0">
                          {String.fromCharCode(65 + oIdx)}
                        </span>
                        <span>{opt}</span>
                      </div>
                      {isSubmitted && oIdx === mcq.correctIndex && (
                        <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                      )}
                      {isSubmitted && selectedOpt === oIdx && oIdx !== mcq.correctIndex && (
                        <X className="w-4 h-4 text-rose-400 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Explanation after submission */}
              {isSubmitted && (
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-1">
                  <span className="font-bold text-cyan-300">व्याख्या: </span>
                  <span>{mcq.explanationHindi}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {!isSubmitted && (
        <div className="flex justify-end pt-4">
          <button
            onClick={handleSubmit}
            disabled={Object.keys(selectedAnswers).length === 0}
            className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold px-8 py-3 rounded-xl text-sm shadow-lg shadow-blue-600/30 transition-all active:scale-95"
          >
            सभी उत्तर जमा करें (Submit All Answers)
          </button>
        </div>
      )}
    </div>
  );
};
