import React from 'react';
import { 
  GraduationCap, 
  BookOpen, 
  Bot, 
  Code2, 
  Database, 
  Network, 
  CheckSquare, 
  Award, 
  BarChart3, 
  Sparkles, 
  Flame, 
  ArrowRight, 
  Laptop, 
  CheckCircle,
  FileText,
  Clock,
  Layers,
  Zap,
  HelpCircle,
  Gamepad2
} from 'lucide-react';
import { ClassGrade, Chapter, StudentProgress } from '../types';

interface HomeDashboardProps {
  selectedClass: ClassGrade;
  onSelectClass: (c: ClassGrade) => void;
  onNavigateTab: (tab: string) => void;
  onSelectChapter: (chId: string) => void;
  progress: StudentProgress;
  chapters: Chapter[];
  onAskAIQuery: (q: string) => void;
  isDarkMode?: boolean;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  selectedClass,
  onSelectClass,
  onNavigateTab,
  onSelectChapter,
  progress,
  chapters,
  onAskAIQuery,
  isDarkMode = true,
}) => {
  const currentClassChapters = chapters.filter((c) => c.classGrade === selectedClass);
  const completedInCurrentClass = currentClassChapters.filter((c) =>
    progress.completedChapterIds.includes(c.id)
  ).length;

  const quickServices = [
    { id: 'modules', label: 'पाठ्यक्रम नोट्स', desc: '14-बिंदु सरल व्याख्या', icon: BookOpen, color: 'text-blue-400 bg-blue-500/10 border-blue-500/30' },
    { id: 'flashcards', label: 'फ्लैशकार्ड्स 🗂️', desc: 'शब्दावली क्विक रिवीजन', icon: Layers, color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30', badge: 'नया' },
    { id: 'cpp-lab', label: 'C++ कोडिंग लैब', desc: 'लाइव कम्पाइलर सिमुलेटर', icon: Code2, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' },
    { id: 'sql-lab', label: 'SQL डेटाबेस लैब', desc: 'क्वेरी रनर व टेबल्स', icon: Database, color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30' },
    { id: 'games', label: 'प्रोग्रामिंग खेल (4)', desc: 'इवेंट प्रोग्रामिंग गेम्स', icon: Gamepad2, color: 'text-purple-400 bg-purple-500/10 border-purple-500/30' },
    { id: 'mcq', label: 'OMR स्पीड टेस्ट', desc: 'BSEB PYQ वस्तुनिष्ठ', icon: CheckSquare, color: 'text-pink-400 bg-pink-500/10 border-pink-500/30' },
    { id: 'exam-prep', label: 'बोर्ड मॉडल पेपर', desc: '70 अंक थ्योरी गाइड', icon: Award, color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' },
    { id: 'networking', label: 'नेटवर्किंग आरेख', desc: 'टोपोलॉजी व पैकेट एनिमेशन', icon: Network, color: 'text-teal-400 bg-teal-500/10 border-teal-500/30' },
  ];

  return (
    <div className="space-y-6 sm:space-y-8 pb-16">
      {/* 1. Hero Portal Banner - BSEBWala Clean Portal Design */}
      <div className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 border border-blue-500/30 p-5 sm:p-8 shadow-xl overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-3.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="bg-amber-400 text-slate-950 px-2.5 py-0.5 rounded-full text-[11px] font-black uppercase tracking-wider shadow-sm flex items-center gap-1">
              BSEBwala<span className="text-blue-900 font-mono text-[10px]">.in</span>
            </span>
            <span className="bg-blue-500/20 text-blue-300 border border-blue-500/30 px-2.5 py-0.5 rounded-full text-[11px] font-bold">
              कक्षा {selectedClass} विशेष पोर्टल
            </span>
          </div>

          <h1 className="text-xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-snug">
            सीखिए Computer Science, समझिए अपनी भाषा में!
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
            बिहार विद्यालय परीक्षा समिति पाठ्यक्रम अनुकूल सरल हिंदी व्याख्या, दैनिक जीवन के उदाहरण, C++ व SQL लैब एवं परीक्षा तैयारी।
          </p>

          {/* Quick Metrics Bar */}
          <div className="pt-2 flex flex-wrap items-center gap-2.5 text-xs">
            <div className="bg-slate-950/80 border border-slate-700/80 px-3 py-1.5 rounded-xl flex items-center space-x-1.5">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-slate-300">अध्ययन निरंतरता:</span>
              <span className="font-bold text-white">{progress.streakDays} दिन</span>
            </div>

            <div className="bg-slate-950/80 border border-slate-700/80 px-3 py-1.5 rounded-xl flex items-center space-x-1.5">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-slate-300">कक्षा {selectedClass} प्रगति:</span>
              <span className="font-bold text-white">{completedInCurrentClass}/{currentClassChapters.length} पूर्ण</span>
            </div>

            <button
              onClick={() => onNavigateTab('flashcards')}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-3 py-1.5 rounded-xl text-xs shadow-md transition-all active:scale-95 flex items-center space-x-1.5"
            >
              <Layers className="w-3.5 h-3.5 text-amber-300" />
              <span>फ्लैशकार्ड रिवीजन</span>
            </button>

            <button
              onClick={() => onNavigateTab('ai-tutor')}
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3.5 py-1.5 rounded-xl text-xs shadow-md shadow-blue-600/30 transition-all active:scale-95 flex items-center space-x-1 ml-auto"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>AI ट्यूटर</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Categorized Quick Access Portal Bar (BSEBWala Style One-Tap Shortcuts) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>त्वरित सेवाएँ एवं लैब्स (Quick Access Hub)</span>
          </span>
          <span className="text-[11px] text-slate-500 hidden sm:inline">एक क्लिक में किसी भी सेक्शन पर पहुँचें</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-2.5 sm:gap-3">
          {quickServices.map((srv) => {
            const Icon = srv.icon;
            return (
              <button
                key={srv.id}
                onClick={() => onNavigateTab(srv.id)}
                className={`relative p-3.5 rounded-2xl border transition-all text-left flex items-start space-x-3 hover:scale-[1.02] active:scale-95 shadow-sm ${srv.color} hover:bg-slate-800/80 group`}
              >
                <div className="p-2 rounded-xl bg-slate-900/90 shrink-0">
                  <Icon className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center space-x-1.5">
                    <span className="text-xs font-bold text-slate-100 group-hover:text-blue-300 transition-colors truncate">
                      {srv.label}
                    </span>
                    {srv.badge && (
                      <span className="text-[9px] font-black bg-amber-400 text-slate-950 px-1 rounded uppercase">
                        {srv.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400 truncate mt-0.5">{srv.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Class Selection Cards (Compact & Responsive) */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-black text-white flex items-center space-x-2">
              <GraduationCap className="w-4 h-4 text-blue-400" />
              <span>कक्षा चयन (Select Class)</span>
            </h2>
          </div>
          <span className="text-[11px] text-slate-400">कक्षा अनुसार आधिकारिक नोट्स</span>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
          {[
            { grade: '9' as ClassGrade, title: 'कक्षा 9वीं', tag: 'फंडामेंटल्स', desc: 'मेमोरी, बाइनरी, हार्डवेयर, विंडोज' },
            { grade: '10' as ClassGrade, title: 'कक्षा 10वीं', tag: 'डिजिटल लिटरेसी', desc: 'MS Office, HTML वेब, फ्लोचार्ट' },
            { grade: '11' as ClassGrade, title: 'कक्षा 11वीं', tag: 'C++ व RDBMS', desc: 'C++ सिंटैक्स, Loops, SQL, नेटवर्क' },
            { grade: '12' as ClassGrade, title: 'कक्षा 12वीं', tag: 'बोर्ड परीक्षा', desc: 'OOPs, Classes, Advanced SQL, AI' },
          ].map((item) => {
            const isSelected = selectedClass === item.grade;
            return (
              <div
                key={item.grade}
                onClick={() => onSelectClass(item.grade)}
                className={`p-3.5 sm:p-4 rounded-2xl border cursor-pointer transition-all ${
                  isSelected
                    ? isDarkMode 
                        ? 'bg-blue-600/20 border-blue-500 ring-2 ring-blue-500/40 shadow-md' 
                        : 'bg-blue-50 border-blue-500 ring-2 ring-blue-400/30 shadow-md'
                    : isDarkMode 
                        ? 'bg-slate-900 border-slate-800 hover:border-slate-700' 
                        : 'bg-white border-slate-200 hover:border-blue-300 shadow-sm'
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className={`text-sm sm:text-base font-black ${
                    isSelected 
                      ? (isDarkMode ? 'text-blue-300' : 'text-blue-700') 
                      : (isDarkMode ? 'text-white' : 'text-slate-900')
                  }`}>
                    {item.title}
                  </span>
                  <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                    isSelected 
                      ? 'bg-blue-600 text-white' 
                      : (isDarkMode ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-600')
                  }`}>
                    {item.tag}
                  </span>
                </div>
                <p className={`text-[11px] truncate ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{item.desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Active Class Chapters List (Clean & Clutter-Free) */}
      <div className={`border rounded-3xl p-4 sm:p-6 shadow-xl space-y-4 ${
        isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className={`flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b pb-3 ${
          isDarkMode ? 'border-slate-800' : 'border-slate-200'
        }`}>
          <div>
            <h2 className={`text-base sm:text-lg font-black flex items-center space-x-2 ${
              isDarkMode ? 'text-white' : 'text-slate-900'
            }`}>
              <BookOpen className="w-4 h-4 text-blue-500" />
              <span>कक्षा {selectedClass} के निर्धारित अध्याय (Prescribed Chapters)</span>
            </h2>
            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              व्याख्या, महत्वपूर्ण परिभाषाएँ, 5 MCQs एवं प्रायोगिक अभ्यास
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('modules')}
            className={`text-xs font-bold flex items-center space-x-1 ${
              isDarkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'
            }`}
          >
            <span>सभी पाठ देखें</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {currentClassChapters.map((ch) => {
            const isCompleted = progress.completedChapterIds.includes(ch.id);
            return (
              <div
                key={ch.id}
                onClick={() => onSelectChapter(ch.id)}
                className={`p-3.5 sm:p-4 rounded-2xl border cursor-pointer transition-all group flex items-start justify-between ${
                  isDarkMode 
                    ? 'bg-slate-950 border-slate-800 hover:border-blue-500/60 hover:bg-slate-900/90' 
                    : 'bg-slate-50 border-slate-200 hover:border-blue-400 hover:bg-blue-50/40 shadow-sm'
                }`}
              >
                <div className="space-y-1 pr-2 min-w-0 flex-1">
                  <div className="flex items-center space-x-1.5 flex-wrap gap-y-1">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-semibold truncate ${
                      isDarkMode ? 'bg-blue-500/10 text-blue-300 border border-blue-500/20' : 'bg-blue-100 text-blue-800 border border-blue-200'
                    }`}>
                      {ch.moduleTitle.split(':')[0]}
                    </span>
                    {ch.chapterNumber && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                        isDarkMode ? 'bg-amber-400/20 text-amber-300 border border-amber-400/30' : 'bg-amber-100 text-amber-800 border border-amber-300'
                      }`}>
                        अध्याय {ch.chapterNumber}
                      </span>
                    )}
                    {isCompleted && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold flex items-center space-x-0.5 shrink-0 ${
                        isDarkMode ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      }`}>
                        <CheckCircle className="w-3 h-3" />
                        <span>पूर्ण</span>
                      </span>
                    )}
                  </div>
                  <h4 className={`text-xs sm:text-sm font-bold transition-colors truncate ${
                    isDarkMode ? 'text-white group-hover:text-blue-300' : 'text-slate-900 group-hover:text-blue-600'
                  }`}>
                    {ch.titleHindi}
                  </h4>
                  <p className={`text-[11px] font-mono truncate ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{ch.title}</p>
                </div>

                <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center shrink-0 transition-colors ml-2 ${
                  isDarkMode 
                    ? 'bg-slate-900 text-slate-400 group-hover:bg-blue-600 group-hover:text-white' 
                    : 'bg-white text-slate-500 border border-slate-200 group-hover:bg-blue-600 group-hover:text-white group-hover:border-transparent'
                }`}>
                  <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
