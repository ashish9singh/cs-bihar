import React, { useState } from 'react';
import { 
  BookOpen, 
  Target, 
  HelpCircle, 
  CheckCircle, 
  ChevronRight, 
  Sparkles, 
  Code, 
  ListOrdered, 
  Check, 
  X, 
  RotateCcw,
  Award,
  Bookmark,
  Share2,
  BookmarkCheck,
  ArrowLeft,
  Edit3,
  Trash2,
  ShieldCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Chapter } from '../types';
import { recordChapterComplete, recordQuizScore, toggleBookmarkQuestion } from '../utils/storage';

interface ChapterViewerProps {
  chapter: Chapter;
  onSelectAnotherChapter?: (id: string) => void;
  onAskAITutor?: (query: string) => void;
  isCompleted?: boolean;
  onCompletionStatusChanged?: () => void;
  onBack?: () => void;
  isAdmin?: boolean;
  onEditChapter?: (ch: Chapter) => void;
  onDeleteChapter?: (id: string) => void;
}

export const ChapterViewer: React.FC<ChapterViewerProps> = ({
  chapter,
  onAskAITutor,
  isCompleted = false,
  onCompletionStatusChanged,
  onBack,
  isAdmin = false,
  onEditChapter,
  onDeleteChapter,
}) => {
  const [activeTab, setActiveTab] = useState<'content' | 'mcq' | 'questions' | 'practical'>('content');
  
  // MCQ state
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [submittedQuiz, setSubmittedQuiz] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [revealedShortAnswers, setRevealedShortAnswers] = useState<Record<number, boolean>>({});

  const handleSelectOption = (questionId: string, optionIdx: number) => {
    if (submittedQuiz) return;
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: optionIdx }));
  };

  const handleSubmitQuiz = () => {
    let correctCount = 0;
    chapter.mcqs.forEach((mcq) => {
      if (selectedAnswers[mcq.id] === mcq.correctIndex) {
        correctCount++;
      }
    });

    setScore(correctCount);
    setSubmittedQuiz(true);
    recordQuizScore(chapter.id, correctCount, chapter.mcqs.length);

    if (correctCount >= Math.ceil(chapter.mcqs.length * 0.7)) {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });
      recordChapterComplete(chapter.id);
      if (onCompletionStatusChanged) onCompletionStatusChanged();
    }
  };

  const handleResetQuiz = () => {
    setSelectedAnswers({});
    setSubmittedQuiz(false);
    setScore(0);
  };

  const handleMarkCompleted = () => {
    recordChapterComplete(chapter.id);
    confetti({
      particleCount: 90,
      spread: 70,
      origin: { y: 0.6 },
    });
    if (onCompletionStatusChanged) onCompletionStatusChanged();
  };

  const toggleRevealShortAnswer = (idx: number) => {
    setRevealedShortAnswers((prev) => ({ ...prev, [idx]: !prev[idx] }));
  };

  return (
    <div className="max-w-5xl mx-auto space-y-4 pb-16">
      {/* Easy Back Navigation Button */}
      {onBack && (
        <button
          onClick={onBack}
          className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 text-xs font-bold transition-all shadow-sm group w-fit active:scale-95"
        >
          <ArrowLeft className="w-3.5 h-3.5 text-blue-400 group-hover:-translate-x-0.5 transition-transform" />
          <span>← सभी अध्याय सूची पर वापस जाएं (Back to Modules)</span>
        </button>
      )}

      {/* Chapter Hero Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-6 md:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="bg-blue-600/30 text-blue-400 border border-blue-500/40 text-xs font-bold px-3 py-1 rounded-full">
            कक्षा {chapter.classGrade}
          </span>
          {chapter.chapterNumber && (
            <span className="bg-amber-400 text-slate-950 text-xs font-black px-2.5 py-1 rounded-full shadow-sm">
              अध्याय {chapter.chapterNumber}
            </span>
          )}
          <span className="text-xs text-slate-400 bg-slate-800 px-3 py-1 rounded-full font-medium">
            {chapter.moduleTitle}
          </span>
          {chapter.isOfficialSyllabus ? (
            <span className="text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-800/60 px-3 py-1 rounded-full font-semibold flex items-center space-x-1">
              <Check className="w-3 h-3" />
              <span>BSEB आधिकारिक पाठ्यक्रम</span>
            </span>
          ) : (
            <span className="text-xs text-amber-400 bg-amber-950/40 px-3 py-1 rounded-full">
              पूरक संवर्धन सामग्री (Supplementary)
            </span>
          )}
          <span className="text-xs text-slate-400 ml-auto">
            अनुमानित समय: ~{chapter.estimatedMins} मिनट
          </span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          {chapter.titleHindi}
        </h1>
        <p className="text-sm text-slate-400 font-mono mt-1">{chapter.title}</p>

        {/* Admin Quick Edit & Remove Controls */}
        {isAdmin && (
          <div className="mt-4 p-3 rounded-2xl bg-slate-950/90 border border-amber-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center space-x-2 text-xs">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="font-bold text-amber-300">शिक्षक/एडमिन नियंत्रण:</span>
              <span className="text-slate-300">आप इस अध्याय के नोट्स व प्रश्नों को सीधे संपादित कर सकते हैं या हटा सकते हैं।</span>
            </div>

            <div className="flex items-center space-x-2 shrink-0">
              <button
                type="button"
                onClick={() => onEditChapter && onEditChapter(chapter)}
                className="bg-amber-400 hover:bg-amber-300 text-slate-950 px-3 py-1.5 rounded-xl font-black text-xs flex items-center space-x-1.5 shadow-md shadow-amber-500/20 active:scale-95 transition-all"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>अध्याय संपादित करें (Edit Notes)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (confirm(`क्या आप सचमुच अध्याय "${chapter.titleHindi}" को पाठ्यक्रम से हटाना चाहते हैं?`)) {
                    onDeleteChapter && onDeleteChapter(chapter.id);
                  }
                }}
                className="bg-rose-600/80 hover:bg-rose-600 text-white px-3 py-1.5 rounded-xl font-bold text-xs flex items-center space-x-1.5 active:scale-95 transition-all"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>हटाएं (Remove)</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab switcher buttons */}
        <div className="flex space-x-2 mt-6 pt-4 border-t border-slate-800 overflow-x-auto no-scrollbar">
          {[
            { id: 'content', label: '1. विस्तृत व्याख्या (Notes)', icon: BookOpen },
            { id: 'mcq', label: `2. वस्तुनिष्ठ प्रश्न (5 MCQs)`, icon: Award },
            { id: 'questions', label: '3. लघु व दीर्घ उत्तरीय प्रश्न', icon: HelpCircle },
            { id: 'practical', label: '4. प्रायोगिक कार्य (Exercise)', icon: Code },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-750 hover:text-white border border-slate-700/60'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: CONTENT & NOTES */}
      {activeTab === 'content' && (
        <div className="space-y-6">
          {/* 1. Learning Objectives */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h3 className="text-base font-bold text-white flex items-center space-x-2 mb-3">
              <Target className="w-5 h-5 text-cyan-400" />
              <span>सीखने के मुख्य उद्देश्य (Learning Objectives)</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm text-slate-200">
              {chapter.learningObjectives.map((obj, i) => (
                <div key={i} className="flex items-start space-x-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  <span>{obj}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 2. Introduction */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h3 className="text-base font-bold text-white mb-2">सरल परिचय (Introduction)</h3>
            <p className="text-sm text-slate-200 leading-relaxed bg-blue-950/20 p-4 rounded-xl border border-blue-900/30 whitespace-pre-line">
              {chapter.introHindi}
            </p>
          </div>

          {/* 3. Main Explanation */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl text-slate-200 leading-relaxed text-sm space-y-4">
            <div className="prose prose-invert max-w-none text-slate-200">
              {chapter.explanationHindi.split('\n\n').map((paragraph, pIdx) => {
                if (paragraph.startsWith('### ')) {
                  return (
                    <h3 key={pIdx} className="text-lg font-black text-blue-400 mt-4 mb-2 pb-1 border-b border-slate-800">
                      {paragraph.replace('### ', '')}
                    </h3>
                  );
                }
                if (paragraph.startsWith('#### ')) {
                  return (
                    <h4 key={pIdx} className="text-base font-bold text-cyan-300 mt-3 mb-1">
                      {paragraph.replace('#### ', '')}
                    </h4>
                  );
                }
                if (paragraph.startsWith('```')) {
                  const lines = paragraph.split('\n');
                  const code = lines.slice(1, -1).join('\n');
                  return (
                    <pre key={pIdx} className="bg-slate-950 p-4 rounded-xl font-mono text-xs text-emerald-300 overflow-x-auto border border-slate-800">
                      <code>{code}</code>
                    </pre>
                  );
                }
                return (
                  <p key={pIdx} className="leading-relaxed text-slate-300 whitespace-pre-line">
                    {paragraph}
                  </p>
                );
              })}
            </div>
          </div>

          {/* 4. Real-life Example Card */}
          <div className="bg-gradient-to-br from-amber-950/30 via-slate-900 to-slate-900 border border-amber-900/40 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center space-x-2 text-amber-400 font-bold text-base mb-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <span>{chapter.realLifeExample.title}</span>
            </div>
            <div className="space-y-3 text-xs sm:text-sm text-slate-200">
              <p>
                <strong className="text-amber-300">स्थिति: </strong>
                {chapter.realLifeExample.scenario}
              </p>
              <p className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 leading-relaxed">
                <strong className="text-cyan-300">सादृश्य (Analogy): </strong>
                {chapter.realLifeExample.analogy}
              </p>
              <p className="text-emerald-400 font-semibold">
                👉 मुख्य सीख: {chapter.realLifeExample.takeaway}
              </p>
            </div>
          </div>

          {/* 5. Technical Terms Glossary */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h3 className="text-base font-bold text-white mb-3 flex items-center space-x-2">
              <ListOrdered className="w-5 h-5 text-blue-400" />
              <span>महत्वपूर्ण अंग्रेजी तकनीकी शब्दावली (Key Technical Terms)</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {chapter.technicalTerms.map((term, idx) => (
                <div key={idx} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-xs sm:text-sm text-cyan-300 font-mono">{term.term}</span>
                    <span className="text-[11px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                      {term.hindiMeaning}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">{term.explanation}</p>
                </div>
              ))}
            </div>
          </div>

          {/* 6. Practical Demonstration (if exists) */}
          {chapter.practicalDemo && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
              <h3 className="text-base font-bold text-white mb-2 flex items-center space-x-2">
                <Code className="w-5 h-5 text-emerald-400" />
                <span>प्रायोगिक प्रदर्शन: {chapter.practicalDemo.title}</span>
              </h3>
              <pre className="bg-slate-950 p-4 rounded-xl font-mono text-xs text-emerald-300 overflow-x-auto border border-slate-800">
                <code>{chapter.practicalDemo.code}</code>
              </pre>
              <p className="text-xs text-slate-300 mt-2 bg-slate-850 p-3 rounded-lg border border-slate-800">
                {chapter.practicalDemo.explanation}
              </p>
            </div>
          )}

          {/* 7. Important Exam Points */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h3 className="text-base font-bold text-white mb-3 text-yellow-300 flex items-center space-x-2">
              <Award className="w-5 h-5 text-yellow-400" />
              <span>परीक्षा उपयोगी मुख्य बिंदु (Important Points for BSEB Exams)</span>
            </h3>
            <ul className="space-y-2 text-xs sm:text-sm text-slate-300">
              {chapter.importantPoints.map((pt, idx) => (
                <li key={idx} className="flex items-start space-x-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-yellow-400 font-bold shrink-0">⭐</span>
                  <span>{pt}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Action Footer: Mark as Complete / Ask AI */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-5 bg-gradient-to-r from-blue-900/30 to-indigo-900/30 border border-blue-500/30 rounded-2xl">
            <div>
              <h4 className="font-bold text-white text-sm sm:text-base">क्या यह पाठ समझ आ गया?</h4>
              <p className="text-xs text-slate-300 mt-0.5">
                प्रगति सुरक्षित करने के लिए पूर्ण चिह्नित करें और क्विज हल करें।
              </p>
            </div>
            <div className="flex items-center space-x-2 w-full sm:w-auto">
              {onAskAITutor && (
                <button
                  onClick={() => onAskAITutor(`${chapter.titleHindi} के बारे में कुछ और उदाहरण देकर समझाइए।`)}
                  className="flex-1 sm:flex-none px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold border border-slate-700 transition-all flex items-center justify-center space-x-1"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>AI से सवाल पूछें</span>
                </button>
              )}
              <button
                onClick={handleMarkCompleted}
                className="flex-1 sm:flex-none px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center space-x-1.5"
              >
                <CheckCircle className="w-4 h-4" />
                <span>{isCompleted ? 'पाठ पूर्ण हो चुका है ✅' : 'पाठ पूरा चिह्नित करें'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MCQs PRACTICE */}
      {activeTab === 'mcq' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-bold text-white">वस्तुनिष्ठ प्रश्न अभ्यास (5 Board MCQs)</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                बिहार बोर्ड 50% वस्तुनिष्ठ पैटर्न आधारित अभ्यास प्रश्न
              </p>
            </div>
            {submittedQuiz && (
              <div className="flex items-center space-x-3">
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950/40 px-3 py-1.5 rounded-xl border border-emerald-800">
                  प्राप्तांक: {score} / {chapter.mcqs.length} ({(score / chapter.mcqs.length * 100).toFixed(0)}%)
                </span>
                <button
                  onClick={handleResetQuiz}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs flex items-center space-x-1"
                  title="पुनः प्रयास करें"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>फिर से हल करें</span>
                </button>
              </div>
            )}
          </div>

          {/* Question List */}
          <div className="space-y-6">
            {chapter.mcqs.map((mcq, qIdx) => {
              const selectedOpt = selectedAnswers[mcq.id];
              const isAnswered = selectedOpt !== undefined;

              return (
                <div key={mcq.id} className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs sm:text-sm font-bold text-slate-100 flex items-start space-x-2">
                      <span className="text-blue-400 shrink-0 font-mono">Q{qIdx + 1}.</span>
                      <span>{mcq.question}</span>
                    </span>
                    {mcq.bsebYear && (
                      <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30 shrink-0">
                        {mcq.bsebYear}
                      </span>
                    )}
                  </div>

                  {/* Options */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm">
                    {mcq.options.map((opt, oIdx) => {
                      let btnStyle = 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850 hover:border-slate-700';

                      if (isAnswered && selectedOpt === oIdx) {
                        btnStyle = 'bg-blue-600/30 border-blue-500 text-blue-300 font-bold';
                      }

                      if (submittedQuiz) {
                        if (oIdx === mcq.correctIndex) {
                          btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-300 font-bold';
                        } else if (selectedOpt === oIdx && oIdx !== mcq.correctIndex) {
                          btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-300 font-bold';
                        }
                      }

                      return (
                        <button
                          key={oIdx}
                          disabled={submittedQuiz}
                          onClick={() => handleSelectOption(mcq.id, oIdx)}
                          className={`p-3 rounded-xl border text-left transition-all flex items-center justify-between ${btnStyle}`}
                        >
                          <div className="flex items-center space-x-2">
                            <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-400 text-xs font-bold flex items-center justify-center shrink-0">
                              {String.fromCharCode(65 + oIdx)}
                            </span>
                            <span>{opt}</span>
                          </div>

                          {submittedQuiz && oIdx === mcq.correctIndex && (
                            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                          )}
                          {submittedQuiz && selectedOpt === oIdx && oIdx !== mcq.correctIndex && (
                            <X className="w-4 h-4 text-rose-400 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation after submission */}
                  {submittedQuiz && (
                    <div className="mt-3 p-3 bg-slate-900/80 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-1">
                      <span className="font-bold text-cyan-300">👉 सही उत्तर की व्याख्या: </span>
                      <p className="leading-relaxed">{mcq.explanationHindi}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {!submittedQuiz && (
            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={handleSubmitQuiz}
                disabled={Object.keys(selectedAnswers).length < chapter.mcqs.length}
                className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold px-6 py-2.5 rounded-xl text-xs sm:text-sm shadow-lg shadow-blue-600/30 transition-all active:scale-95"
              >
                उत्तर जमा करें (Submit Test)
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: SHORT & LONG QUESTIONS */}
      {activeTab === 'questions' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-lg font-bold text-white">लघु उत्तरीय प्रश्न (2 अंक) व मॉडल उत्तर</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              परीक्षा में पूरे अंक प्राप्त करने के लिए सटीक लेखन शैली
            </p>
          </div>

          <div className="space-y-4">
            {chapter.shortQuestions.map((sq, idx) => {
              const isRevealed = revealedShortAnswers[idx];
              return (
                <div key={idx} className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs sm:text-sm font-bold text-slate-100 flex items-center space-x-2">
                      <span className="text-cyan-400 font-mono">Q{idx + 1}.</span>
                      <span>{sq.question}</span>
                    </span>
                    <span className="text-[10px] font-bold bg-blue-500/20 text-blue-300 px-2.5 py-0.5 rounded-full border border-blue-500/30">
                      [{sq.marks} अंक]
                    </span>
                  </div>

                  {sq.tips && (
                    <p className="text-[11px] text-amber-300/80 bg-amber-950/20 px-3 py-1.5 rounded-lg border border-amber-900/30">
                      💡 {sq.tips}
                    </p>
                  )}

                  {isRevealed ? (
                    <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-2">
                      <span className="font-bold text-emerald-400 block">आदर्श उत्तर:</span>
                      <p className="whitespace-pre-line">{sq.answerHindi}</p>
                    </div>
                  ) : null}

                  <button
                    onClick={() => toggleRevealShortAnswer(idx)}
                    className="text-xs text-blue-400 hover:text-blue-300 font-semibold transition-colors flex items-center space-x-1"
                  >
                    <span>{isRevealed ? 'उत्तर छिपाएँ' : 'आदर्श उत्तर देखें 👉'}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: PRACTICAL EXERCISE */}
      {activeTab === 'practical' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h3 className="text-lg font-bold text-white flex items-center space-x-2">
            <Code className="w-5 h-5 text-emerald-400" />
            <span>प्रायोगिक अभ्यास कार्य (Practical Exercise)</span>
          </h3>

          <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              {chapter.practicalExercise}
            </p>
            <div className="pt-2">
              <span className="text-[11px] text-slate-400">
                सुझाव: संबंधित लैब (C++ Lab या SQL Lab) में जाकर इस अभ्यास को चलाकर देखें।
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
