import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HomeDashboard } from './components/HomeDashboard';
import { ModulesList } from './components/ModulesList';
import { ChapterViewer } from './components/ChapterViewer';
import { AITutor } from './components/AITutor';
import { CppLab } from './components/CppLab';
import { SqlLab } from './components/SqlLab';
import { NetworkingLab } from './components/NetworkingLab';
import { ExamPrep } from './components/ExamPrep';
import { MCQPractice } from './components/MCQPractice';
import { ProgressDashboard } from './components/ProgressDashboard';
import { CSGames } from './components/CSGames';
import { Flashcards } from './components/Flashcards';
import { LabSubNav } from './components/LabSubNav';
import { AdminSyllabusModal } from './components/AdminSyllabusModal';
import { AdminLoginModal } from './components/AdminLoginModal';
import { initialChapters } from './data/chaptersData';
import { ClassGrade, Chapter, StudentProgress } from './types';
import { loadStudentProgress, saveStudentProgress, initialProgress, toggleBookmarkQuestion, toggleMasteredFlashcard } from './utils/storage';
import { isAdminSessionActive, logoutAdmin } from './utils/adminAuth';
import { GraduationCap, BookOpen, Bot, Code2, Award, Gamepad2, Layers } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedClass, setSelectedClass] = useState<ClassGrade>('11');
  const [activeChapterId, setActiveChapterId] = useState<string>('c11-cpp-intro');
  const [progress, setProgress] = useState<StudentProgress>(loadStudentProgress);
  const [chapters, setChapters] = useState<Chapter[]>(() => {
    try {
      const stored = localStorage.getItem('bseb_cs_custom_chapters');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Could not load custom chapters from localStorage');
    }
    return initialChapters;
  });
  const [currentSession, setCurrentSession] = useState<string>('2025-2026');
  const [aiInitialQuery, setAiInitialQuery] = useState<string>('');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('bseb_theme');
      if (saved) return saved === 'dark';
    } catch (e) {}
    return true;
  });

  // Sync theme changes to document and localStorage
  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      root.classList.remove('light');
      document.body.classList.add('dark');
      document.body.classList.remove('light');
    } else {
      root.classList.remove('dark');
      root.classList.add('light');
      document.body.classList.remove('dark');
      document.body.classList.add('light');
    }
    try {
      localStorage.setItem('bseb_theme', isDarkMode ? 'dark' : 'light');
    } catch (e) {}
  }, [isDarkMode]);
  
  // Admin Authentication State
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(isAdminSessionActive);
  const [isAdminLoginModalOpen, setIsAdminLoginModalOpen] = useState<boolean>(false);
  const [isAdminSyllabusModalOpen, setIsAdminSyllabusModalOpen] = useState<boolean>(false);
  const [chapterToEdit, setChapterToEdit] = useState<Chapter | null>(null);

  // Sync chapters changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('bseb_cs_custom_chapters', JSON.stringify(chapters));
    } catch (e) {}
  }, [chapters]);

  const handleSelectChapter = (chId: string) => {
    setActiveChapterId(chId);
    setCurrentTab('chapter-view');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAskAIAboutCode = (code: string, title: string) => {
    setAiInitialQuery(`इस C++ प्रोग्राम ("${title}") की मुख्य लाइनों को सरल हिंदी में समझाइए:\n\`\`\`cpp\n${code}\n\`\`\``);
    setCurrentTab('ai-tutor');
  };

  const handleAskAIAboutSql = (query: string) => {
    setAiInitialQuery(`इस SQL क्वेरी का अर्थ और यह डेटाबेस में क्या काम करती है, सरल हिंदी में समझाइए:\n\`\`\`sql\n${query}\n\`\`\``);
    setCurrentTab('ai-tutor');
  };

  const handleAskAIGeneral = (query: string) => {
    setAiInitialQuery(query);
    setCurrentTab('ai-tutor');
  };

  const handleRefreshProgress = () => {
    setProgress(loadStudentProgress());
  };

  const handleResetProgress = () => {
    if (confirm('क्या आप अपनी अध्ययन प्रगति (अंक, पूर्ण पाठ) रीसेट करना चाहते हैं?')) {
      saveStudentProgress(initialProgress);
      setProgress(initialProgress);
    }
  };

  const handleAddNewChapter = (newCh: Chapter) => {
    setChapters((prev) => [newCh, ...prev]);
  };

  const handleUpdateChapter = (updatedCh: Chapter) => {
    setChapters((prev) => prev.map((c) => (c.id === updatedCh.id ? updatedCh : c)));
  };

  const handleDeleteChapter = (chapterId: string) => {
    setChapters((prev) => prev.filter((c) => c.id !== chapterId));
    if (activeChapterId === chapterId) {
      const remaining = chapters.filter((c) => c.id !== chapterId);
      if (remaining.length > 0) {
        setActiveChapterId(remaining[0].id);
      }
    }
  };

  const handleTriggerEditChapter = (ch: Chapter) => {
    setChapterToEdit(ch);
    if (isAdminSessionActive()) {
      setIsAdminLoggedIn(true);
      setIsAdminSyllabusModalOpen(true);
    } else {
      setIsAdminLoggedIn(false);
      setIsAdminLoginModalOpen(true);
    }
  };

  const handleResetSyllabusToDefault = () => {
    setChapters(initialChapters);
    localStorage.removeItem('bseb_cs_custom_chapters');
  };

  const handleToggleBookmark = (qId: string) => {
    const { progress: updated } = toggleBookmarkQuestion(qId);
    setProgress({ ...updated });
  };

  const handleToggleMasteredFlashcard = (cardId: string) => {
    const { progress: updated } = toggleMasteredFlashcard(cardId);
    setProgress({ ...updated });
  };

  const handleAskAIAboutTerm = (term: string) => {
    setAiInitialQuery(`इस कंप्यूटर साइंस शब्दावली ("${term}") का अर्थ, परिभाषा और परीक्षा के लिए एक सरल उदाहरण हिंदी में समझाइए।`);
    setCurrentTab('ai-tutor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Secure Admin Access Trigger
  const handleOpenAdminPortal = () => {
    if (isAdminSessionActive()) {
      setIsAdminLoggedIn(true);
      setIsAdminSyllabusModalOpen(true);
    } else {
      setIsAdminLoggedIn(false);
      setIsAdminLoginModalOpen(true);
    }
  };

  const handleAdminLoginSuccess = () => {
    setIsAdminLoggedIn(true);
    setIsAdminLoginModalOpen(false);
    setIsAdminSyllabusModalOpen(true);
  };

  const handleAdminLogout = () => {
    logoutAdmin();
    setIsAdminLoggedIn(false);
    setIsAdminSyllabusModalOpen(false);
  };

  // Find currently active chapter for viewer
  const activeChapter = chapters.find((c) => c.id === activeChapterId) || chapters[0];

  return (
    <div className={`min-h-screen transition-colors duration-200 ${
      isDarkMode 
        ? 'bg-slate-950 text-slate-100' 
        : 'bg-slate-50 text-slate-900'
    }`}>
      {/* Universal Header with Navigation, Class Switcher, and Theme Toggle */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        selectedClass={selectedClass}
        onSelectClass={(c) => {
          setSelectedClass(c);
          const firstInClass = chapters.find((ch) => ch.classGrade === c);
          if (firstInClass) setActiveChapterId(firstInClass.id);
        }}
        isDarkMode={isDarkMode}
        onToggleTheme={() => setIsDarkMode(!isDarkMode)}
        onOpenAdmin={handleOpenAdminPortal}
        isAdminLoggedIn={isAdminLoggedIn}
        completedCount={progress.completedChapterIds.length}
      />

      {/* Main Body Content Container - Mobile screen width optimized */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-4 sm:pt-6 pb-20 sm:pb-12">
        {/* Tab 1: Home Dashboard */}
        {currentTab === 'home' && (
          <HomeDashboard
            selectedClass={selectedClass}
            onSelectClass={(c) => setSelectedClass(c)}
            onNavigateTab={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onSelectChapter={handleSelectChapter}
            progress={progress}
            chapters={chapters}
            onAskAIQuery={handleAskAIGeneral}
            isDarkMode={isDarkMode}
          />
        )}

        {/* Tab 2: Modules & Chapters Browser */}
        {currentTab === 'modules' && (
          <ModulesList
            chapters={chapters}
            selectedClass={selectedClass}
            onSelectClass={(c) => setSelectedClass(c)}
            onSelectChapter={handleSelectChapter}
            completedChapterIds={progress.completedChapterIds}
            isAdmin={isAdminLoggedIn}
            onEditChapter={handleTriggerEditChapter}
            onDeleteChapter={handleDeleteChapter}
          />
        )}

        {/* Tab 3: Detailed 14-Point Chapter Viewer */}
        {currentTab === 'chapter-view' && activeChapter && (
          <ChapterViewer
            chapter={activeChapter}
            onAskAITutor={handleAskAIGeneral}
            isCompleted={progress.completedChapterIds.includes(activeChapter.id)}
            onCompletionStatusChanged={handleRefreshProgress}
            onBack={() => setCurrentTab('modules')}
            isAdmin={isAdminLoggedIn}
            onEditChapter={handleTriggerEditChapter}
            onDeleteChapter={handleDeleteChapter}
          />
        )}

        {/* Tab: Flashcards Revision Hub (Technical Terms with 3D Flip) */}
        {currentTab === 'flashcards' && (
          <Flashcards
            selectedClass={selectedClass}
            chapters={chapters}
            masteredIds={progress.masteredFlashcardIds || []}
            onToggleMastered={handleToggleMasteredFlashcard}
            onAskAI={handleAskAIAboutTerm}
            isDarkMode={isDarkMode}
          />
        )}

        {/* Tab 4: AI CS Tutor */}
        {currentTab === 'ai-tutor' && (
          <AITutor
            selectedClass={selectedClass}
            initialQuery={aiInitialQuery}
            onClearInitialQuery={() => setAiInitialQuery('')}
            onNavigateToTab={(t) => setCurrentTab(t)}
          />
        )}

        {/* Sub-Navigation for all Practical Labs */}
        {['cpp-lab', 'sql-lab', 'games', 'networking'].includes(currentTab) && (
          <LabSubNav currentTab={currentTab} onNavigateTab={(t) => setCurrentTab(t)} />
        )}

        {/* Tab 5: C++ Virtual Lab */}
        {currentTab === 'cpp-lab' && (
          <CppLab onAskAIAboutCode={handleAskAIAboutCode} />
        )}

        {/* Tab 6: SQL Database Lab */}
        {currentTab === 'sql-lab' && (
          <SqlLab onAskAIAboutSql={handleAskAIAboutSql} />
        )}

        {/* Tab 7: Educational Programming Games (Class 11 Event Programming) */}
        {currentTab === 'games' && <CSGames />}

        {/* Tab 8: Networking Visualizer */}
        {currentTab === 'networking' && <NetworkingLab />}

        {/* Tab 8: Board Exam Prep */}
        {currentTab === 'exam-prep' && <ExamPrep />}

        {/* Tab 9: MCQ Speed Practice Room */}
        {currentTab === 'mcq' && (
          <MCQPractice
            chapters={chapters}
            selectedClass={selectedClass}
            bookmarkedQuestionIds={progress.bookmarkedQuestions}
            onToggleBookmark={handleToggleBookmark}
          />
        )}

        {/* Tab 10: Student Progress Stats */}
        {currentTab === 'progress' && (
          <ProgressDashboard
            progress={progress}
            allChapters={chapters}
            onSelectChapter={handleSelectChapter}
            onResetProgress={handleResetProgress}
          />
        )}
      </main>

      {/* Admin Login Modal (Locked Gateway) */}
      <AdminLoginModal
        isOpen={isAdminLoginModalOpen}
        onClose={() => setIsAdminLoginModalOpen(false)}
        onLoginSuccess={handleAdminLoginSuccess}
      />

      {/* Admin / Teacher Content Management Modal (Accessible after Authentication) */}
      <AdminSyllabusModal
        isOpen={isAdminSyllabusModalOpen}
        onClose={() => {
          setIsAdminSyllabusModalOpen(false);
          setChapterToEdit(null);
        }}
        chapters={chapters}
        onAddNewChapter={handleAddNewChapter}
        onUpdateChapter={handleUpdateChapter}
        onDeleteChapter={handleDeleteChapter}
        chapterToEdit={chapterToEdit}
        onClearEditingChapter={() => setChapterToEdit(null)}
        currentSession={currentSession}
        onUpdateSession={(s) => setCurrentSession(s)}
        onResetSyllabusToDefault={handleResetSyllabusToDefault}
        onLogout={handleAdminLogout}
      />

      {/* Mobile Sticky Bottom Navigation Bar (bsebwala.in style ultra-accessible for phones) */}
      <div className={`lg:hidden fixed bottom-0 left-0 right-0 z-40 backdrop-blur-md border-t px-2 py-1.5 flex justify-between items-center transition-colors duration-200 ${
        isDarkMode 
          ? 'bg-slate-900/95 border-slate-800 shadow-2xl' 
          : 'bg-white/95 border-slate-200 shadow-[0_-4px_16px_rgba(0,0,0,0.06)]'
      }`}>
        {[
          { id: 'home', label: 'होम', icon: GraduationCap, matchIds: ['home'] },
          { id: 'modules', label: 'नोट्स', icon: BookOpen, matchIds: ['modules', 'chapter-view'] },
          { id: 'flashcards', label: 'फ्लैशकार्ड', icon: Layers, matchIds: ['flashcards'] },
          { id: 'cpp-lab', label: 'लैब्स', icon: Code2, matchIds: ['cpp-lab', 'sql-lab', 'games', 'networking'] },
          { id: 'exam-prep', label: 'परीक्षा', icon: Award, matchIds: ['exam-prep', 'mcq'] },
        ].map((item) => {
          const Icon = item.icon;
          const isActive = item.matchIds.includes(currentTab);
          return (
            <button
              key={item.id}
              onClick={() => {
                setCurrentTab(item.id);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-xl text-[10.5px] font-bold transition-all ${
                isActive 
                  ? (isDarkMode 
                      ? 'text-amber-400 font-extrabold bg-slate-800/60' 
                      : 'text-blue-600 font-extrabold bg-blue-50')
                  : (isDarkMode 
                      ? 'text-slate-400 hover:text-slate-200' 
                      : 'text-slate-500 hover:text-slate-900')
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 mb-0.5 ${
                  isActive 
                    ? (isDarkMode ? 'text-amber-400 stroke-[2.5]' : 'text-blue-600 stroke-[2.5]') 
                    : (isDarkMode ? 'text-slate-400' : 'text-slate-500')
                }`} />
                {item.id === 'flashcards' && !isActive && (
                  <span className="absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                )}
              </div>
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Student Friendly Bihar Board Footer */}
      <footer className={`mt-16 border-t py-6 text-center text-xs transition-colors duration-200 ${
        isDarkMode 
          ? 'border-slate-800 bg-slate-900/60 text-slate-400' 
          : 'border-slate-200 bg-slate-100/90 text-slate-600'
      }`}>
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p className="font-semibold flex items-center justify-center gap-1.5 flex-wrap">
            <span className={`font-extrabold text-sm ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
              BSEB<span className="text-amber-500">wala</span><span className={`${isDarkMode ? 'text-blue-400' : 'text-blue-600'} font-mono`}>.in</span>
            </span>
            <span className={isDarkMode ? 'text-slate-300' : 'text-slate-700'}>– बिहार बोर्ड Computer Science AI Learning Companion • बिहार विद्यालय परीक्षा समिति</span>
          </p>
          <p className={`text-[11px] ${isDarkMode ? 'text-slate-500' : 'text-slate-500'}`}>
            "सीखिए Computer Science, समझिए अपनी भाषा में!" • Official BSEB Classes 9, 10, 11 & 12 Curriculum
          </p>
          <div className="pt-2 flex flex-wrap items-center justify-center gap-3 text-[11px] text-blue-500 font-semibold">
            <button onClick={() => setCurrentTab('home')} className="hover:underline">डैशबोर्ड</button>
            <span>•</span>
            <button onClick={() => setCurrentTab('modules')} className="hover:underline">पाठ्यक्रम नोट्स</button>
            <span>•</span>
            <button onClick={() => setCurrentTab('flashcards')} className={`hover:underline font-bold ${isDarkMode ? 'text-indigo-300' : 'text-indigo-600'}`}>फ्लैशकार्ड्स</button>
            <span>•</span>
            <button onClick={() => setCurrentTab('cpp-lab')} className="hover:underline">C++ लैब</button>
            <span>•</span>
            <button onClick={() => setCurrentTab('sql-lab')} className="hover:underline">SQL लैब</button>
            <span>•</span>
            <button onClick={() => setCurrentTab('games')} className="hover:underline">प्रोग्रामिंग खेल</button>
            <span>•</span>
            <button onClick={() => setCurrentTab('exam-prep')} className="hover:underline">बोर्ड परीक्षा</button>
            <span>•</span>
            <button onClick={handleOpenAdminPortal} className={`hover:underline font-bold ${isDarkMode ? 'text-amber-400' : 'text-amber-600'}`}>
              {isAdminLoggedIn ? 'एडमिन पोर्टल (सक्रिय)' : 'शिक्षक/एडमिन लॉगिन 🔒'}
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
