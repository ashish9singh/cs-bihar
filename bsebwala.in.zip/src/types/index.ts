export type ClassGrade = '9' | '10' | '11' | '12';

export interface TechnicalTerm {
  term: string;
  hindiMeaning: string;
  explanation: string;
}

export interface RealLifeExample {
  title: string;
  scenario: string;
  analogy: string;
  takeaway: string;
}

export interface MCQQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanationHindi: string;
  bsebYear?: string;
  isPYQ?: boolean;
}

export interface ShortQuestion {
  question: string;
  marks: number;
  answerHindi: string;
  tips?: string;
}

export interface LongQuestion {
  question: string;
  marks: number;
  answerHindi: string;
  codeSnippet?: string;
}

export interface SyllabusUnit {
  id: string;
  classGrade: ClassGrade;
  unitNumber: number;
  unitCode: string; // e.g. "UNIT-1", "UNIT-2"
  title: string;
  titleHindi: string;
  marks?: number; // e.g. 6, 10, 44, 30, 16, 8, etc.
  descriptionHindi: string;
  iconName?: string;
  chaptersCount?: number;
}

export interface Chapter {
  id: string;
  classGrade: ClassGrade;
  unitId?: string;
  unitNumber?: number;
  chapterNumber?: string; // e.g. "1.1", "1.2", "2.1"
  moduleTitle: string;
  title: string;
  titleHindi: string;
  isOfficialSyllabus: boolean;
  estimatedMins: number;
  learningObjectives: string[];
  introHindi: string;
  explanationHindi: string;
  technicalTerms: TechnicalTerm[];
  realLifeExample: RealLifeExample;
  practicalDemo?: {
    title: string;
    language: 'cpp' | 'sql' | 'html' | 'pseudo';
    code: string;
    explanation: string;
  };
  importantPoints: string[];
  faqs: { question: string; answer: string }[];
  mcqs: MCQQuestion[];
  shortQuestions: ShortQuestion[];
  practicalExercise: string;
}

export interface CppProgramPreset {
  id: string;
  title: string;
  titleHindi: string;
  category: string;
  code: string;
  defaultInput?: string;
  expectedOutput: string;
  descriptionHindi: string;
  lineByLine: { line: string; hindi: string }[];
  commonMistakes: { mistake: string; solution: string }[];
}

export interface SqlExercise {
  id: string;
  title: string;
  titleHindi: string;
  difficulty: 'Beginner' | 'Intermediate' | 'BSEB Exam Special';
  query: string;
  explanationHindi: string;
  concept: string;
}

export interface BoardExamPaper {
  id: string;
  title: string;
  classGrade: ClassGrade;
  session: string;
  type: 'model_paper' | 'pyq' | 'ai_practice';
  officialSource?: string;
  totalMarks: number;
  durationMins: number;
  objectiveQuestions: MCQQuestion[];
  shortQuestions: ShortQuestion[];
  longQuestions: LongQuestion[];
  markingSchemeTips: string[];
}

export interface FlashcardItem {
  id: string;
  term: string;
  hindiMeaning: string;
  explanationHindi: string;
  classGrade: ClassGrade;
  category: string;
  exampleOrAnalogy?: string;
  examTip?: string;
}

export interface StudentProgress {
  completedChapterIds: string[];
  quizScores: Record<string, { score: number; total: number; date: string }>;
  savedNotes: Record<string, string>;
  bookmarkedQuestions: string[];
  streakDays: number;
  lastStudiedDate: string;
  sqlRunCount: number;
  cppRunCount: number;
  masteredFlashcardIds: string[];
}

