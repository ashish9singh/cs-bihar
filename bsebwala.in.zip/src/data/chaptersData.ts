import { Chapter } from '../types';

export const initialChapters: Chapter[] = [
  // =========================================================================
  // CLASS 9: FOUNDATIONS OF COMPUTATIONAL THINKING (NEP 2020 BSEB SYLLABUS)
  // =========================================================================
  {
    id: 'c9-unit1-ipos',
    classGrade: '9',
    unitId: 'c9-u1',
    unitNumber: 1,
    chapterNumber: '1.1',
    moduleTitle: 'Unit 1: Computer System Components',
    title: 'Input-Process-Output-Storage (IPOS) Cycle and Hardware',
    titleHindi: '1.1 कंप्यूटर सिस्टम: IPOS चक्र एवं इनपुट-आउटपुट उपकरण',
    isOfficialSyllabus: true,
    estimatedMins: 20,
    learningObjectives: [
      'IPOS (Input-Process-Output-Storage) चक्र की परिभाषा और महत्व समझना',
      'कंप्यूटर सिस्टम में डेटा और निर्देशों के प्रवाह को जानना',
      'इनपुट डिवाइस (कीबोर्ड, माउस, स्कैनर, टचस्क्रीन) और डिजिटलीकरण',
      'आउटपुट डिवाइस (मॉनिटर, प्रिंटर, स्पीकर) और सॉफ्ट कॉपी बनाम हार्ड कॉपी में अंतर',
    ],
    introHindi: `नमस्कार कक्षा 9वीं के विद्यार्थियों! कंप्यूटर साइंस की इस यात्रा में आपका स्वागत है। 
राष्ट्रीय शिक्षा नीति (NEP 2020) के अनुसार, कंप्यूटर केवल एक मशीन नहीं है बल्कि कम्प्यूटेशनल सोच (Computational Thinking) विकसित करने का माध्यम है। 
कंप्यूटर किसी भी कार्य को 4 बुनियादी चरणों में करता है: Input (आंकड़ा लेना) -> Process (हल करना) -> Output (परिणाम देना) -> Storage (सुरक्षित रखना)।`,
    explanationHindi: `### 1. IPOS मॉडल क्या है?
- **Input (इनपुट):** कच्चा डेटा (Raw Data) और निर्देश दर्ज करना (उदा. एटीएम कार्ड डालना और पिन टाइप करना)।
- **Process (प्रक्रिया):** CPU द्वारा आंकड़ों पर गणना और तार्किक निर्णय लेना।
- **Output (आउटपुट):** संसाधित परिणाम या सूचना (Information) स्क्रीन पर दिखाना या प्रिंट करना (उदा. एटीएम स्क्रीन पर शेष राशि दिखना)।
- **Storage (भंडारण):** भविष्य में उपयोग के लिए डेटा को सुरक्षित रखना (उदा. बैंक के सर्वर में खाता रिकॉर्ड सहेजना)।

### 2. इनपुट और आउटपुट उपकरण:
| उपकरण प्रकार | उदाहरण | कार्य |
| :--- | :--- | :--- |
| **Input Devices** | Keyboard, Mouse, Scanner, Microphone, Touchscreen | डेटा प्रविष्टि और भौतिक संकेतों को डिजिटल (0 और 1) में बदलना। |
| **Output Devices** | Monitor, Printer, Speaker, Plotter | डिजिटल डेटा को मानव-पठनीय रूप में प्रदर्शित करना। |

### 3. सॉफ्ट कॉपी बनाम हार्ड कॉपी:
- **Soft Copy:** मॉनिटर की स्क्रीन या मोबाइल में दिखने वाला डिजिटल दस्तावेज़ (PDF, वर्ड फाइल) जिसे हाथ से छुआ नहीं जा सकता।
- **Hard Copy:** प्रिंटर द्वारा कागज पर छापा गया भौतिक दस्तावेज़ जिसे हाथ में लिया जा सकता है।`,
    technicalTerms: [
      {
        term: 'IPOS Cycle',
        hindiMeaning: 'इनपुट-प्रक्रिया-आउटपुट-भंडारण चक्र',
        explanation: 'कंप्यूटर के कार्य करने का सार्वभौमिक 4-चरणीय मॉडल।',
      },
      {
        term: 'Digitization (डिजिटलीकरण)',
        hindiMeaning: 'एनालॉग को डिजिटल रूप में बदलना',
        explanation: 'वास्तविक दुनिया की आवाज, तस्वीर या टेक्स्ट को 0 और 1 की भाषा में बदलना।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: एटीएम (ATM) से पैसे निकालना',
      scenario: 'जब आप बैंक के एटीएम में जाते हैं:',
      analogy: 'कार्ड डालना और पिन दर्ज करना = Input; बैंक सर्वर द्वारा खाते में बैलेंस जाँचना = Processing; स्क्रीन पर पुष्टिकरण और मशीन से नोट निकलना = Output; खाते का नया बैलेंस डेटाबेस में अपडेट होना = Storage।',
      takeaway: 'हर डिजिटल सेवा IPOS चक्र पर ही आधारित होती है।',
    },
    importantPoints: [
      'कच्चे तथ्यों को Data कहते हैं और संसाधित उपयोगी अर्थ को Information कहते हैं।',
      'स्कैनर एक इनपुट डिवाइस है, जबकि प्रिंटर एक आउटपुट डिवाइस है।',
      'टचस्क्रीन इनपुट और आउटपुट दोनों का कार्य करती है।',
    ],
    faqs: [
      {
        question: 'क्या पेन ड्राइव इनपुट डिवाइस है या आउटपुट?',
        answer: 'पेन ड्राइव एक स्टोरेज (Storage) डिवाइस है, जो डेटा पढ़ने (इनपुट) और लिखने (आउटपुट) दोनों में सक्षम है।',
      },
    ],
    mcqs: [
      {
        id: 'q9-ipos-1',
        question: 'IPOS मॉडल में "P" का क्या अर्थ होता है?',
        options: ['Program', 'Process', 'Print', 'Power'],
        correctIndex: 1,
        explanationHindi: 'IPOS का पूर्ण रूप Input, Process, Output, Storage होता है, जहाँ P का अर्थ Process है।',
      },
      {
        id: 'q9-ipos-2',
        question: 'निम्नलिखित में से कौन सा इनपुट डिवाइस नहीं है?',
        options: ['माउस (Mouse)', 'स्कैनर (Scanner)', 'प्रिंटर (Printer)', 'माइक्रोफ़ोन (Microphone)'],
        correctIndex: 2,
        explanationHindi: 'प्रिंटर एक आउटपुट डिवाइस है क्योंकि यह कंप्यूटर से परिणाम को कागज पर छापता है।',
      },
      {
        id: 'q9-ipos-3',
        question: 'कागज पर मुद्रित (Printed) दस्तावेज़ को क्या कहा जाता है?',
        options: ['सॉफ्ट कॉपी', 'हार्ड कॉपी', 'डिजिटल कॉपी', 'वर्चुअल कॉपी'],
        correctIndex: 1,
        explanationHindi: 'कागज पर प्रिंट किए गए भौतिक स्वरूप को हार्ड कॉपी (Hard Copy) कहते हैं।',
      },
    ],
    shortQuestions: [
      {
        question: 'IPOS चक्र के चारों चरणों के नाम लिखिए और एक वास्तविक उदाहरण दीजिए।',
        marks: 2,
        answerHindi: 'IPOS के चार चरण हैं: 1. Input (इनपुट), 2. Process (प्रक्रिया), 3. Output (आउटपुट), और 4. Storage (भंडारण)। उदाहरण: ऑनलाइन परीक्षा फॉर्म भरना - छात्र का विवरण भरना (Input), पात्रता जाँचना (Process), रसीद दिखना (Output), और फॉर्म डेटाबेस में सेव होना (Storage)।',
      },
    ],
    practicalExercise: 'अपने विद्यालय की कंप्यूटर लैब में जाकर कीबोर्ड, माउस, सीपीयू, मॉनिटर और प्रिंटर के केबल्स का कनेक्शन देखें।',
  },

  {
    id: 'c9-unit1-cpu-memory',
    classGrade: '9',
    unitId: 'c9-u1',
    unitNumber: 1,
    chapterNumber: '1.2',
    moduleTitle: 'Unit 1: Computer System Components',
    title: 'CPU Architecture, RAM vs ROM and Fetch-Decode-Execute Cycle',
    titleHindi: '1.2 सीपीयू, मेमोरी एवं स्टोरेज पदानुक्रम',
    isOfficialSyllabus: true,
    estimatedMins: 25,
    learningObjectives: [
      'CPU के घटक: ALU (Arithmetic Logic Unit) और CU (Control Unit) को समझना',
      'Fetch-Decode-Execute (FDE) चक्र की कार्यप्रणाली जानना',
      'प्राथमिक मेमोरी (RAM और ROM) और द्वितीयक स्टोरेज (HDD, SSD, Pen Drive) में अंतर',
      'स्टोरेज पदानुक्रम (गति बनाम क्षमता बनाम लागत) समझना',
    ],
    introHindi: `सीपीयू (CPU) को कंप्यूटर का मस्तिष्क कहा जाता है। जैसे मानव मस्तिष्क सोचता है, निर्णय लेता है और अंगों को निर्देश देता है, वैसे ही सीपीयू कंप्यूटर के सभी कार्यों को नियंत्रित करता है।`,
    explanationHindi: `### 1. CPU के मुख्य अंग:
1. **ALU (Arithmetic Logic Unit):** सभी गणितीय गणनाएँ (+, -, *, /) और तुलनात्मक निर्णय (<, >, ==) करता है।
2. **CU (Control Unit):** कंप्यूटर का ट्रैफिक पुलिस; यह मेमोरी से निर्देश लाता है और अन्य घटकों को संचालित करता है।
3. **Registers / Cache:** अति-तीव्र गति वाली आंतरिक मेमोरी।

### 2. Fetch-Decode-Execute (FDE) चक्र:
- **Fetch (लाना):** CU मेमोरी (RAM) से अगला निर्देश प्राप्त करता है।
- **Decode (समझना):** निर्देश का विश्लेषण कर कार्य समझता है।
- **Execute (निष्पादित करना):** ALU द्वारा गणना या कार्य पूर्ण किया जाता है।

### 3. मेमोरी पदानुक्रम (Memory Hierarchy):
\`\`\`text
[तेज गति, कम क्षमता, अधिक लागत]
  Registers -> Cache (L1, L2) -> RAM (मुख्य मेमोरी) -> SSD / HDD -> पेन ड्राइव
[धीमी गति, विशाल क्षमता, कम लागत]
\`\`\`

### 4. RAM बनाम ROM:
- **RAM (Random Access Memory):** अस्थिर (Volatile) मेमोरी। बिजली जाते ही डेटा मिट जाता है। कम रैम होने पर कंप्यूटर लैग (Lag) या हैंग करता है।
- **ROM (Read Only Memory):** गैर-वाष्पशील (Non-Volatile) मेमोरी। कंप्यूटर को बूट करने वाले BIOS निर्देश इसमें स्थायी रहते हैं।`,
    technicalTerms: [
      {
        term: 'Fetch-Decode-Execute',
        hindiMeaning: 'लाना-समझना-चलाना चक्र',
        explanation: 'सीपीयू द्वारा एक निर्देश को प्रोसेस करने का मौलिक तीन-चरणीय चक्र।',
      },
      {
        term: 'Volatile Memory',
        hindiMeaning: 'वाष्पशील / अस्थिर मेमोरी',
        explanation: 'विद्युत आपूर्ति बंद होने पर जिसका सारा डेटा समाप्त हो जाता है (जैसे RAM)।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: पढ़ाई की मेज (RAM) बनाम अलमारी (Storage)',
      scenario: 'जब आप शाम को होमवर्क करने बैठते हैं:',
      analogy: 'आपकी मेज (RAM) पर केवल वही 2-3 किताबें रखी होती हैं जिन्हें आप अभी पढ़ रहे हैं। बाकी 50 किताबें आपकी अलमारी (Hard Disk/Storage) में सुरक्षित रखी हैं। यदि मेज छोटी हो तो किताबें ठीक से नहीं फैल पाएँगी (फोन लैग होना)।',
      takeaway: 'चल रहे प्रोग्राम्स RAM में रहते हैं और स्थायी फाइलें Storage में रहती हैं।',
    },
    importantPoints: [
      'ALU गणितीय और तार्किक गणनाएं करता है।',
      'RAM वोलाटाइल और ROM नॉन-वोलाटाइल मेमोरी है।',
      'रजिस्टर और कैश मेमोरी सबसे तेज गति वाली मेमोरी होती हैं।',
    ],
    faqs: [
      {
        question: 'फोन में 4GB RAM और 64GB Storage लिखा होता है, इसका क्या मतलब है?',
        answer: '4GB RAM वर्तमान में चलने वाले ऐप्स को संभालती है, जबकि 64GB Storage में आपकी फोटो, गाने और ऐप्स स्थायी रूप से सेव रहते हैं।',
      },
    ],
    mcqs: [
      {
        id: 'q9-cpu-1',
        question: 'CPU का कौन सा भाग सभी जोड़ और घटाव करता है?',
        options: ['Control Unit', 'ALU', 'ROM', 'हार्ड डिस्क'],
        correctIndex: 1,
        explanationHindi: 'ALU (Arithmetic Logic Unit) सभी गणितीय और तार्किक गणनाएँ करता है।',
      },
      {
        id: 'q9-cpu-2',
        question: 'कंप्यूटर बंद होने पर किस मेमोरी का डेटा नष्ट हो जाता है?',
        options: ['ROM', 'RAM', 'SSD', 'हार्ड डिस्क'],
        correctIndex: 1,
        explanationHindi: 'RAM एक Volatile (अस्थायी) मेमोरी है, विद्युत बंद होते ही इसका डेटा मिट जाता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'Fetch-Decode-Execute चक्र की व्याख्या संक्षेप में कीजिए।',
        marks: 2,
        answerHindi: '1. Fetch: सीपीयू मेमोरी से निर्देश प्राप्त करता है। 2. Decode: कंट्रोल यूनिट निर्देश का अर्थ समझती है। 3. Execute: एएलयू निर्देश को चलाकर परिणाम निकालता है।',
      },
    ],
    practicalExercise: 'अपने कंप्यूटर या मोबाइल की Settings में जाकर Installed RAM और Available Internal Storage की जाँच करें।',
  },

  {
    id: 'c9-unit2-computational-thinking',
    classGrade: '9',
    unitId: 'c9-u2',
    unitNumber: 2,
    chapterNumber: '2.1',
    moduleTitle: 'Unit 2: Foundations of Computational Thinking',
    title: 'Decomposition, Pattern Recognition, Algorithms and Flowcharts',
    titleHindi: '2.1 कम्प्यूटेशनल सोच: अपघटन, पैटर्न पहचान, फ्लोचार्ट एवं स्यूडोकोड',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'कम्प्यूटेशनल सोच के 4 स्तंभ: अपघटन (Decomposition), पैटर्न पहचान, अमूर्तता (Abstraction) और एल्गोरिदम',
      'फ्लोचार्ट के मानक प्रतीक (अंडाकार, आयत, समांतर चतुर्भुज, हीरा) और ड्राई-रन तकनीक',
      'स्यूडोकोड (Pseudocode) के सामान्य निर्माण (BEGIN/END, IF-THEN-ELSE, LOOP)',
      'नियंत्रण संरचनाएं: अनुक्रम (Sequence), चयन (Selection), पुनरावृत्ति (Iteration)',
    ],
    introHindi: `कम्प्यूटेशनल सोच (Computational Thinking) किसी भी जटिल समस्या को इस तरह सुलझाने की कला है कि कंप्यूटर या इंसान उसे आसानी से समझ और हल कर सके।`,
    explanationHindi: `### 1. कम्प्यूटेशनल सोच के चार स्तंभ:
1. **Decomposition (अपघटन):** किसी बड़ी और कठिन समस्या को छोटे-छोटे प्रबंधनीय भागों में तोड़ना (उदा. स्कूल के वार्षिक उत्सव की योजना बनाना)।
2. **Pattern Recognition (पैटर्न पहचान):** समस्याओं में समानता या दोहराए गए चरणों को खोजना।
3. **Abstraction (अमूर्तता):** अनावश्यक बातों को छोड़कर केवल आवश्यक जानकारी पर ध्यान देना (उदा. गूगल मैप्स में केवल सड़कें दिखना, मकान की ईंटें नहीं)।
4. **Algorithm Design (एल्गोरिदम):** समस्या को हल करने के लिए चरण-दर-चरण (Step-by-Step) निर्देश लिखना।

### 2. फ़्लोचार्ट के मानक प्रतीक (Flowchart Symbols):
- **Start / Stop (अंडाकार / Oval):** कार्यक्रम की शुरुआत या समाप्ति।
- **Input / Output (समांतर चतुर्भुज / Parallelogram):** डेटा लेना या परिणाम दिखाना।
- **Process (आयत / Rectangle):** गणना या कार्य (उदा. Sum = A + B)।
- **Decision (हीरा / Diamond):** शर्त जाँचना (उदा. क्या Age >= 18?)।
- **Flow Lines (तीर / Arrows):** प्रवाह की दिशा दर्शाना।

### 3. स्यूडोकोड (Pseudocode):
सरल, संरचित अंग्रेजी में लिखा गया कोड-जैसा एल्गोरिदम जिसे आसानी से किसी भी प्रोग्रामिंग भाषा (C++, Python) में बदला जा सकता है।
\`\`\`text
BEGIN
  INPUT num1, num2
  SET sum = num1 + num2
  IF sum > 50 THEN
     PRINT "बड़ा योग"
  ELSE
     PRINT "छोटा योग"
  ENDIF
END
\`\`\``,
    technicalTerms: [
      {
        term: 'Decomposition (अपघटन)',
        hindiMeaning: 'समस्या को छोटे टुकड़ों में तोड़ना',
        explanation: 'जटिल कार्यों को सरल उप-समस्याओं में विभाजित करने की तकनीक।',
      },
      {
        term: 'Dry Run',
        hindiMeaning: 'कागज पर मानसिक परीक्षण',
        explanation: 'बिना कंप्यूटर चलाए कागज पर फ्लोचार्ट या कोड के इनपुट-आउटपुट की जांच करना।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: चाय बनाने की विधि (Algorithm & Flowchart)',
      scenario: 'चाय बनाने के चरण:',
      analogy: 'स्टेप 1: पानी उबालें। स्टेप 2: चायपत्ती और चीनी डालें। स्टेप 3 (Decision): क्या दूध चाहिए? यदि हाँ, तो दूध डालें। स्टेप 4: छानकर कप में परोसें। यह चरण-दर-चरण विधि ही एल्गोरिदम है!',
      takeaway: 'एल्गोरिदम किसी भी कार्य को बिना गलती किए पूरा करने का सुनिश्चित रास्ता है।',
    },
    importantPoints: [
      'फ्लोचार्ट में Decision बॉक्स के हमेशा दो निकास (Yes/No) होते हैं।',
      'स्यूडोकोड का कोई सख्त वाक्य-विन्यास (Syntax) नहीं होता।',
      'अनुक्रम (Sequence), चयन (Selection) और पुनरावृत्ति (Iteration) तीन मुख्य नियंत्रण संरचनाएं हैं।',
    ],
    faqs: [
      {
        question: 'एल्गोरिदम और फ्लोचार्ट में क्या अंतर है?',
        answer: 'एल्गोरिदम समस्या समाधान का शाब्दिक (Textual) चरण-दर-चरण विवरण है, जबकि फ्लोचार्ट उसका चित्रात्मक (Graphical) रूप है।',
      },
    ],
    mcqs: [
      {
        id: 'q9-ct-1',
        question: 'फ्लोचार्ट में निर्णय (Decision) लेने के लिए किस आकृति का उपयोग होता है?',
        options: ['आयत (Rectangle)', 'हीरा (Diamond)', 'अंडाकार (Oval)', 'वृत्त (Circle)'],
        correctIndex: 1,
        explanationHindi: 'Decision बॉक्स के लिए समचतुर्भुज / हीरा (Diamond) आकृति का उपयोग किया जाता है।',
      },
      {
        id: 'q9-ct-2',
        question: 'समस्या को छोटे-छोटे भागों में तोड़ने की प्रक्रिया को क्या कहते हैं?',
        options: ['Abstraction', 'Decomposition', 'Iteration', 'Compilation'],
        correctIndex: 1,
        explanationHindi: 'Decomposition का अर्थ बड़ी समस्या को छोटे और आसान हिस्सों में बाँटना होता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'कंप्यूटेशनल सोच के किन्हीं दो मुख्य घटकों के नाम और कार्य लिखिए।',
        marks: 2,
        answerHindi: '1. Decomposition (अपघटन): बड़ी समस्या को छोटे-छोटे टुकड़ों में विभाजित करना। 2. Pattern Recognition (पैटर्न पहचान): पहले से सुलझाई गई समस्याओं में समानताएं खोजना ताकि समाधान सरल हो सके।',
      },
    ],
    practicalExercise: 'दो संख्याओं में से बड़ी संख्या ज्ञात करने के लिए अपनी कॉपी में एक साफ-सुथरा फ्लोचार्ट बनाएँ।',
  },

  {
    id: 'c9-unit3-spreadsheets',
    classGrade: '9',
    unitId: 'c9-u3',
    unitNumber: 3,
    chapterNumber: '3.1',
    moduleTitle: 'Unit 3: Data Organization in Spreadsheets',
    title: 'Worksheets, Formulas, Functions and Data Visualization',
    titleHindi: '3.1 स्प्रेडशीट: वर्कशीट, सूत्र (Formulas), तार्किक कार्य एवं चार्ट्स',
    isOfficialSyllabus: true,
    estimatedMins: 25,
    learningObjectives: [
      'स्प्रेडशीट का परिचय और दैनिक जीवन में उपयोग (घरेलू बजट, अंक विश्लेषण)',
      'सेल और सेल एड्रेसिंग (उदा. A1, B2) और डेटा प्रकार (Text, Number, Date)',
      'सूत्रों की संरचना (= चिह्न) और बुनियादी फ़ंक्शंस (SUM, AVERAGE, COUNT)',
      'तार्किक फ़ंक्शन (IF, AND, OR) और डेटा विज़ुअलाइज़ेशन (Bar, Pie, Line Charts)',
    ],
    introHindi: `संख्याओं और तालिकाओं को व्यवस्थित करने तथा स्वतः गणना करने के लिए स्प्रेडशीट (जैसे MS Excel, Google Sheets) दुनिया का सबसे लोकप्रिय सॉफ्टवेयर है।`,
    explanationHindi: `### 1. स्प्रेडशीट की संरचना:
- **Row (पंक्ति):** क्षैतिज रेखाएं (संख्याओं 1, 2, 3 द्वारा पहचानी जाती हैं)।
- **Column (स्तंभ):** लंबवत रेखाएं (अक्षरों A, B, C द्वारा पहचाने जाते हैं)।
- **Cell (सेल):** पंक्ति और स्तंभ का कटाव बिंदु। इसका नाम कॉलम और रो मिलाकर बनता है (उदा. A1 = कॉलम A, रो 1)।

### 2. सूत्र (Formulas) और फ़ंक्शंस:
स्प्रेडशीट में प्रत्येक सूत्र हमेशा बराबर के चिह्न (\`=\`) से प्रारंभ होता है:
- \`=A1 + B1\` -> जोड़ना
- \`=SUM(B1:B10)\` -> B1 से B10 तक की सभी संख्याओं का कुल योग
- \`=AVERAGE(C1:C5)\` -> औसत मान ज्ञात करना
- \`=COUNT(A1:A20)\` -> संख्यात्मक प्रविष्टियों की गिनती करना

### 3. तार्किक कार्य (Logical IF Function):
\`\`\`excel
=IF(Marks >= 30, "पास", "अनुत्तीर्ण")
\`\`\`
यदि छात्र के अंक 30 या अधिक हैं तो "पास" दिखेगा, अन्यथा "अनुत्तीर्ण"।

### 4. चार्ट के प्रकार:
- **Bar / Column Chart:** विभिन्न श्रेणियों के मानों की तुलना करने के लिए।
- **Pie Chart:** किसी कुल मान में विभिन्न हिस्सों का प्रतिशत दर्शाने के लिए।
- **Line Graph:** समय के साथ रुझान (Trends) देखने के लिए।`,
    technicalTerms: [
      {
        term: 'Cell Address',
        hindiMeaning: 'सेल का पता',
        explanation: 'कॉलम अक्षर और रो संख्या का संयोजन (जैसे C5)।',
      },
      {
        term: 'Data Visualization',
        hindiMeaning: 'डेटा का चित्रात्मक प्रदर्शन',
        explanation: 'कच्चे आंकड़ों को चार्ट या ग्राफ के रूप में बदलना जिससे रुझान तुरंत समझ आएं।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: स्कूल का रिजल्ट कार्ड',
      scenario: 'शिक्षक महोदय छात्रों के 5 विषयों के अंक स्प्रेडशीट में भरते हैं:',
      analogy: '=SUM(B2:F2) लिखते ही छात्र का कुल योग आ जाता है और =AVERAGE(B2:F2) से प्रतिशत निकल जाता है। एक क्लिक में सभी 50 बच्चों का रिजल्ट तैयार हो जाता है!',
      takeaway: 'स्प्रेडशीट समय बचाती है और मानवीय गणना की गलतियों को शून्य कर देती है।',
    },
    importantPoints: [
      'स्प्रेडशीट में हर फार्मूला अनिवार्य रूप से = चिह्न से शुरू होता है।',
      'SUM, AVERAGE, COUNT पूर्वनिर्मित (Built-in) फ़ंक्शंस हैं।',
      'Pie Chart 100% के विभिन्न हिस्सों को वृत्त के टुकड़ों में दिखाता है।',
    ],
    faqs: [
      {
        question: 'यदि हम सूत्र के आगे = न लगाएं तो क्या होगा?',
        answer: 'स्प्रेडशीट उसे सूत्र न मानकर केवल सामान्य टेक्स्ट (लेबल) मान लेगी और कोई गणना नहीं होगी।',
      },
    ],
    mcqs: [
      {
        id: 'q9-ss-1',
        question: 'स्प्रेडशीट में प्रत्येक फॉर्मूला किस चिह्न से शुरू होना अनिवार्य है?',
        options: ['#', '=', '@', '$'],
        correctIndex: 1,
        explanationHindi: 'स्प्रेडशीट में किसी भी गणना सूत्र को सक्रिय करने के लिए बराबर (=) का चिह्न लगाया जाता है।',
      },
      {
        id: 'q9-ss-2',
        question: 'कॉलम C और रो 5 के कटान बिंदु वाले सेल का पता क्या होगा?',
        options: ['5C', 'C-5', 'C5', 'Cell5'],
        correctIndex: 2,
        explanationHindi: 'सेल का पता पहले कॉलम अक्षर और फिर रो संख्या मिलाकर बनता है, अतः C5 सही है।',
      },
    ],
    shortQuestions: [
      {
        question: 'स्प्रेडशीट में SUM और AVERAGE फ़ंक्शन का क्या उपयोग है?',
        marks: 2,
        answerHindi: 'SUM फ़ंक्शन चयनित सेलों के संख्यात्मक मानों का कुल जोड़ निकालता है (उदा. =SUM(A1:A5))। AVERAGE फ़ंक्शन दी गई संख्याओं का औसत (माध्य) ज्ञात करता है।',
      },
    ],
    practicalExercise: 'एक स्प्रेडशीट में अपने 5 दोस्तों के नाम और उनके गणित के अंक लिखकर कुल योग और औसत निकालें।',
  },

  {
    id: 'c9-unit4-cyber-safety',
    classGrade: '9',
    unitId: 'c9-u4',
    unitNumber: 4,
    chapterNumber: '4.1',
    moduleTitle: 'Unit 4: Internet Basics, Cyber Safety & Ethics',
    title: 'Internet, URLs, Cyber Threats, Digital Footprint and Netiquette',
    titleHindi: '4.1 इंटरनेट, साइबर सुरक्षा, डिजिटल पदचिह्न एवं ऑनलाइन शिष्टाचार',
    isOfficialSyllabus: true,
    estimatedMins: 25,
    learningObjectives: [
      'इंटरनेट की परिभाषा, वेब ब्राउज़र बनाम सर्च इंजन और URL की संरचना',
      'साइबर खतरे: मैलवेयर (वायरस, ट्रोजन), फ़िशिंग (Phishing) और पहचान की चोरी (Identity Theft)',
      'सुरक्षित ऑनलाइन आदतें: मजबूत पासवर्ड, 2-फैक्टर प्रमाणीकरण (2FA)',
      'डिजिटल पदचिह्न (Digital Footprint), साइबरबुलिंग और ऑनलाइन शिष्टाचार (Netiquette)',
    ],
    introHindi: `आज के युग में इंटरनेट ज्ञान और संचार का सबसे बड़ा खजाना है। परंतु जिस प्रकार सड़क पर चलते समय यातायात नियमों का पालन आवश्यक है, उसी प्रकार इंटरनेट की दुनिया में सुरक्षित रहने के लिए साइबर सुरक्षा और नैतिक नियमों का ज्ञान अनिवार्य है।`,
    explanationHindi: `### 1. वेब ब्राउज़र बनाम खोज इंजन (Search Engine):
- **Web Browser:** वह सॉफ्टवेयर जिसकी मदद से हम वेबसाइट खोलते हैं (उदा. Google Chrome, Mozilla Firefox)।
- **Search Engine:** वह वेबसाइट जो इंटरनेट पर सूचना खोजने का काम करती है (उदा. Google, Bing)।

### 2. URL (Uniform Resource Locator) की संरचना:
\`https://www.biharboardonline.bihar.gov.in/index.html\`
- \`https://\` -> सुरक्षित प्रोटोकॉल (HyperText Transfer Protocol Secure)
- \`biharboardonline.bihar.gov.in\` -> डोमेन नाम (Domain Name / सर्वर पता)
- \`/index.html\` -> वेबपेज फ़ाइल का पथ (Path)

### 3. सामान्य साइबर खतरे (Cyber Threats):
- **Malware:** दुर्भावनापूर्ण सॉफ्टवेयर (Virus, Worm, Spyware) जो सिस्टम को नुकसान पहुँचाते हैं।
- **Phishing (फ़िशिंग):** फर्जी ईमेल या लिंक भेजकर पासवर्ड या बैंक ओटीपी चुराने की धोखाधड़ी।
- **Identity Theft:** किसी अन्य व्यक्ति के नाम और फोटो का गलत उपयोग कर फर्जी अकाउंट बनाना।

### 4. डिजिटल पदचिह्न (Digital Footprint):
इंटरनेट पर आप जो भी लाइक, कमेंट, पोस्ट या सर्च करते हैं, उसका एक स्थायी डिजिटल रिकॉर्ड बन जाता है। इसे ही आपका **डिजिटल पदचिह्न** कहते हैं। हमेशा सम्मानजनक और जिम्मेदार भाषा का प्रयोग करें।`,
    technicalTerms: [
      {
        term: 'Phishing (फ़िशिंग)',
        hindiMeaning: 'डिजिटल जालसाजी',
        explanation: 'असली जैसी दिखने वाली नकली वेबसाइट या संदेश भेजकर गोपनीय जानकारी चुराना।',
      },
      {
        term: 'Two-Factor Authentication (2FA)',
        hindiMeaning: 'दोहरा सुरक्षा सत्यापन',
        explanation: 'पासवर्ड के साथ मोबाइल पर आने वाले OTP द्वारा पहचान की अतिरिक्त पुष्टि।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: "आपको 25 लाख की लॉटरी लगी है" का फर्जी मैसेज',
      scenario: 'व्हाट्सएप पर अनजान नंबर से लॉटरी का लिंक आना:',
      analogy: 'जैसे अनजान व्यक्ति के बुलावे पर अपना घर का ताला नहीं खोलते, वैसे ही अनजान लिंक पर क्लिक करके बैंक ओटीपी या पासवर्ड नहीं देना चाहिए। यह फ़िशिंग हमला है!',
      takeaway: 'सतर्क रहें: बैंक या बोर्ड कभी भी फोन पर पासवर्ड या ओटीपी नहीं मांगते।',
    },
    importantPoints: [
      'मजबूत पासवर्ड में अक्षर (A-Z, a-z), संख्याएं (0-9) और विशेष चिह्न (@, #, $) शामिल होने चाहिए।',
      'HTTPS में "S" का अर्थ Secure (सुरक्षित) होता है।',
      'साइबरबुलिंग (ऑनलाइन किसी को डराना या परेशान करना) एक दंडनीय अपराध है।',
    ],
    faqs: [
      {
        question: 'डिजिटल फुटप्रिंट को पूरी तरह कैसे मिटाया जा सकता है?',
        answer: 'इंटरनेट पर एक बार अपलोड की गई सामग्री पूरी तरह मिटाना लगभग असंभव है क्योंकि अन्य लोग उसका स्क्रीनशॉट या बैकअप रख सकते हैं। इसलिए सोच-समझकर ही पोस्ट करें।',
      },
    ],
    mcqs: [
      {
        id: 'q9-cs-1',
        question: 'वेबसाइट्स को खोलने और देखने के लिए किस सॉफ्टवेयर का उपयोग किया जाता है?',
        options: ['वेब ब्राउज़र (Web Browser)', 'सर्च इंजन', 'ऑपरेटिंग सिस्टम', 'स्प्रेडशीट'],
        correctIndex: 0,
        explanationHindi: 'Google Chrome, Edge आदि वेब ब्राउज़र हैं जो वेबपेजों को लोड कर स्क्रीन पर दिखाते हैं।',
      },
      {
        id: 'q9-cs-2',
        question: 'पासवर्ड को और अधिक सुरक्षित बनाने के लिए किस तकनीक का प्रयोग किया जाता है?',
        options: ['2-Factor Authentication (2FA)', 'Screen Brightness', 'Airplane Mode', 'Bluetooth'],
        correctIndex: 0,
        explanationHindi: '2FA में पासवर्ड के बाद ओटीपी द्वारा दूसरी बार सत्यापन होता है जिससे सुरक्षा बहुत बढ़ जाती है।',
      },
    ],
    shortQuestions: [
      {
        question: 'फ़िशिंग (Phishing) क्या है और इससे कैसे बचा जा सकता है?',
        marks: 2,
        answerHindi: 'फ़िशिंग एक प्रकार की साइबर धोखाधड़ी है जिसमें फर्जी संदेश या लिंक के माध्यम से उपयोगकर्ताओं के पासवर्ड, बैंक विवरण या व्यक्तिगत डेटा चुराए जाते हैं। बचाव: किसी भी अनजान लिंक पर क्लिक न करें और कभी भी अपना पासवर्ड या ओटीपी किसी से साझा न करें।',
      },
    ],
    practicalExercise: 'एक ऐसा मजबूत पासवर्ड बनाकर देखें जिसमें 8 से अधिक अक्षर, बड़े-छोटे लेटर्स, अंक और स्पेशल सिंबल हों।',
  },

  // =========================================================================
  // CLASS 10: TRANSITION TO FORMAL COMPUTING (NEP 2020 BSEB SYLLABUS)
  // =========================================================================
  {
    id: 'c10-unit1-binary-logic',
    classGrade: '10',
    unitId: 'c10-u1',
    unitNumber: 1,
    chapterNumber: '1.1',
    moduleTitle: 'Unit 1: Number Systems and Boolean Logic',
    title: 'Decimal to Binary Conversion, Bits/Bytes and Logic Gates (AND, OR, NOT)',
    titleHindi: '1.1 संख्या प्रणाली, बाइनरी रूपांतरण एवं लॉजिक गेट्स',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'दशमलव (आधार-10) और बाइनरी (आधार-2) संख्या प्रणाली की समझ',
      'दशमलव से बाइनरी (2 से भाग विधि) और बाइनरी से दशमलव (2 की घातों द्वारा विस्तार) रूपांतरण',
      'बिट्स, बाइट्स और स्टोरेज इकाइयाँ (KB, MB, GB, TB) तथा ASCII एन्कोडिंग',
      'बूलियन लॉजिक और बेसिक लॉजिक गेट्स: AND, OR, NOT एवं सत्य तालिकाएँ (Truth Tables)',
    ],
    introHindi: `नमस्कार कक्षा 10वीं के विद्यार्थियों! कंप्यूटर एक इलेक्ट्रॉनिक उपकरण है जो केवल बिजली के दो स्तर समझता है: चालू (ON = 1) और बंद (OFF = 0)। इसी 0 और 1 की व्यवस्था को **बाइनरी संख्या प्रणाली (Binary Number System)** कहा जाता है।`,
    explanationHindi: `### 1. संख्या प्रणालियाँ:
- **दशमलव (Decimal System):** आधार = 10 (अंक: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
- **बाइनरी (Binary System):** आधार = 2 (केवल दो अंक: 0 और 1)

### 2. दशमलव से बाइनरी रूपांतरण (उदा. 13 का बाइनरी):
\`\`\`text
13 ÷ 2 = 6, शेष = 1
 6 ÷ 2 = 3, शेष = 0
 3 ÷ 2 = 1, शेष = 1
 1 ÷ 2 = 0, शेष = 1
नीचे से ऊपर पढ़ने पर: (13)₁₀ = (1101)₂
\`\`\`

### 3. मेमोरी इकाइयाँ:
- 1 Bit = 0 या 1
- 1 Nibble = 4 Bits
- 1 Byte = 8 Bits
- 1 KB (Kilobyte) = 1024 Bytes
- 1 MB (Megabyte) = 1024 KB
- 1 GB (Gigabyte) = 1024 MB

### 4. बेसिक लॉजिक गेट्स (Logic Gates):
1. **AND Gate:** आउटपुट केवल तभी 1 होता है जब **दोनों इनपुट 1** हों (सत्य तालिका: 1 AND 1 = 1, अन्यथा 0)।
2. **OR Gate:** आउटपुट 1 होता है यदि **कम से कम एक इनपुट 1** हो (1 OR 0 = 1, 0 OR 0 = 0)।
3. **NOT Gate (इनवर्टर):** इनपुट को उलट देता है (NOT 1 = 0, NOT 0 = 1)।`,
    technicalTerms: [
      {
        term: 'Logic Gate',
        hindiMeaning: 'तार्किक द्वार',
        explanation: 'इलेक्ट्रॉनिक परिपथ का वह बुनियादी घटक जो एक या अधिक इनपुट पर बूलियन निर्णय लेता है।',
      },
      {
        term: 'Truth Table (सत्य तालिका)',
        hindiMeaning: 'तार्किक परिणाम सारणी',
        explanation: 'सभी संभावित इनपुट्स और उनके संबंधित आउटपुट्स को दर्शाने वाली तालिका।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: कमरे की दोहरी कुंडी (AND Gate) बनाम दो दरवाजे (OR Gate)',
      scenario: 'सुरक्षा व्यवस्था:',
      analogy: 'AND गेट: तिजोरी खोलने के लिए मैनेजर और कैशियर दोनों की चाभी चाहिए (दोनों हाँ = काम होगा)। OR गेट: कमरे में दो खिड़कियाँ हैं, किसी एक को भी खोल दें तो ताजी हवा आ जाएगी (कोई एक भी हाँ = काम होगा)।',
      takeaway: 'लॉजिक गेट्स कंप्यूटर के निर्णय लेने की आधारशिला हैं।',
    },
    importantPoints: [
      'बाइनरी में केवल दो अंक 0 और 1 होते हैं।',
      '8 बिट्स मिलकर 1 बाइट बनाते हैं।',
      'ASCII कोड प्रत्येक अक्षर (जैसे A = 65) को एक संख्यात्मक मान देता है।',
    ],
    faqs: [
      {
        question: 'मेमोरी में 1000 के स्थान पर 1024 का प्रयोग क्यों होता है?',
        answer: 'क्योंकि कंप्यूटर 2 की घातों पर कार्य करता है और 2¹⁰ = 1024 होता है, जो 1000 के सबसे निकट है।',
      },
    ],
    mcqs: [
      {
        id: 'q10-bin-1',
        question: 'संख्या (5)₁₀ का बाइनरी मान क्या होगा?',
        options: ['101', '110', '111', '100'],
        correctIndex: 0,
        explanationHindi: '5 = 4 + 1 = (1×2²) + (0×2¹) + (1×2⁰) = 101।',
      },
      {
        id: 'q10-bin-2',
        question: '1 बाइट में कितने बिट्स होते हैं?',
        options: ['4 बिट्स', '8 बिट्स', '16 बिट्स', '32 बिट्स'],
        correctIndex: 1,
        explanationHindi: '8 बिट्स के समूह को 1 बाइट (Byte) कहा जाता है।',
      },
      {
        id: 'q10-bin-3',
        question: 'किस लॉजिक गेट का आउटपुट 1 होता है जब दोनों इनपुट 1 हों?',
        options: ['OR Gate', 'AND Gate', 'NOT Gate', 'NAND Gate'],
        correctIndex: 1,
        explanationHindi: 'AND गेट में जब दोनों इनपुट सत्य (1) होते हैं तभी आउटपुट सत्य (1) होता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'AND गेट और OR गेट की सत्य तालिका (Truth Table) बनाइए।',
        marks: 2,
        answerHindi: 'AND गेट: (0,0->0), (0,1->0), (1,0->0), (1,1->1)। OR गेट: (0,0->0), (0,1->1), (1,0->1), (1,1->1)।',
      },
    ],
    practicalExercise: 'संख्या 25 को 2 से भाग विधि द्वारा बाइनरी में बदलकर अपनी कॉपी में लिखें।',
  },

  {
    id: 'c10-unit2-cpp-basics',
    classGrade: '10',
    unitId: 'c10-u2',
    unitNumber: 2,
    chapterNumber: '2.1',
    moduleTitle: 'Unit 2: Fundamentals of Programming',
    title: 'C++ Program Structure, Variables, Operators, IF-ELSE and Loops',
    titleHindi: '2.2 C++ प्रोग्रामिंग: संरचना, चर, ऑपरेटर, IF-ELSE और लूप्स',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'कंपाइलर बनाम इंटरप्रेटर और C++ प्रोग्राम की संरचना (`#include`, `main()`)',
      'चर (Variables), डेटा प्रकार (`int`, `float`, `char`) और नामकरण के नियम',
      'ऑपरेटर: अंकगणितीय (+, -, *, /, %) और संबंधपरक (==, !=, <, >, <=, >=)',
      'नियंत्रण प्रवाह: `if`, `if-else`, `nested if` और `for`, `while` लूप्स',
    ],
    introHindi: `कक्षा 10वीं में हम प्रोग्रामिंग के व्यावहारिक पक्ष में प्रवेश करते हैं। C++ एक उच्च-स्तरीय, तेज और शक्तिशाली प्रोग्रामिंग भाषा है।`,
    explanationHindi: `### 1. C++ प्रोग्राम का ढांचा:
\`\`\`cpp
#include <iostream>
using namespace std;

int main() {
    int roll_no = 15;
    float marks = 85.5;
    
    cout << "रोल नंबर: " << roll_no << endl;
    cout << "प्राप्तांक: " << marks << endl;
    
    if (marks >= 30) {
        cout << "परिणाम: उत्तीर्ण (Pass)" << endl;
    } else {
        cout << "परिणाम: अनुत्तीर्ण (Fail)" << endl;
    }
    
    return 0;
}
\`\`\`

### 2. डेटा प्रकार (Data Types):
- \`int\`: पूर्णांक संख्याओं के लिए (उदा. 10, -25)।
- \`float\`: दशमलव वाली संख्याओं के लिए (उदा. 75.6)।
- \`char\`: एकल अक्षर के लिए (उदा. 'A', 'M')।

### 3. लूप्स (Loops):
जब किसी कार्य को बार-बार दोहराना हो:
\`\`\`cpp
// 1 से 5 तक संख्याएं प्रिंट करना
for (int i = 1; i <= 5; i++) {
    cout << i << " ";
}
// आउटपुट: 1 2 3 4 5
\`\`\``,
    technicalTerms: [
      {
        term: 'Variable (चर)',
        hindiMeaning: 'मान सहेजने वाला मेमोरी बॉक्स',
        explanation: 'मेमोरी में वह स्थान जिसका मान प्रोग्राम चलते समय बदला जा सकता है।',
      },
      {
        term: 'Syntax Error',
        hindiMeaning: 'व्याकरण संबंधी त्रुटि',
        explanation: 'नियमों के उल्लंघन (जैसे सेमीकोलन भूलना) पर कंपाइलर द्वारा दी जाने वाली त्रुटि।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: परीक्षा पास/फेल का नियम',
      scenario: 'यदि अंक 30 या अधिक हों तो पास, नहीं तो फेल:',
      analogy: 'C++ में if-else कथन बिल्कुल इसी तरह निर्णय लेता है: condition सत्य होने पर if ब्लॉक चलता है, असत्य होने पर else ब्लॉक।',
      takeaway: 'प्रोग्रामिंग तार्किक सोच को कोड में ढालने का साधन है।',
    },
    importantPoints: [
      'प्रोग्राम का निष्पादन हमेशा main() फ़ंक्शन से प्रारंभ होता है।',
      'तुलना के लिए == का प्रयोग होता है, = मान असाइन करने के लिए है।',
      'प्रत्येक निर्देश के अंत में सेमीकोलन (;) लगाना न भूलें।',
    ],
    faqs: [
      {
        question: 'int और float में क्या अंतर है?',
        answer: 'int केवल पूर्ण संख्या (जैसे 5) संग्रहीत करता है, जबकि float दशमलव वाली संख्या (जैसे 5.75) संग्रहीत करता है।',
      },
    ],
    mcqs: [
      {
        id: 'q10-cpp-1',
        question: 'C++ में स्क्रीन पर आउटपुट दिखाने के लिए किसका उपयोग होता है?',
        options: ['cin', 'cout', 'scanf', 'print'],
        correctIndex: 1,
        explanationHindi: 'cout (Character Output) का उपयोग स्क्रीन पर टेक्स्ट या मान प्रिंट करने के लिए होता है।',
      },
      {
        id: 'q10-cpp-2',
        question: 'C++ में दो मानों की बराबरी की तुलना करने के लिए कौन सा ऑपरेटर प्रयुक्त होता है?',
        options: ['=', '==', '!=', ':='],
        correctIndex: 1,
        explanationHindi: '== रिलेशनल ऑपरेटर है जो दो मानों की समानता जाँचता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'C++ में चर (Variable) क्या है? इसके नामकरण का एक नियम बताइए।',
        marks: 2,
        answerHindi: 'चर मेमोरी में एक नामित स्थान है जो किसी डेटा मान को सुरक्षित रखता है। नियम: चर का नाम किसी अक्षर या अंडरस्कोर (_) से शुरू होना चाहिए, अंक से शुरू नहीं हो सकता।',
      },
    ],
    practicalExercise: 'C++ Lab में जाकर दो संख्याओं को जोड़ने का प्रोग्राम चलाकर देखें।',
  },

  {
    id: 'c10-unit3-databases-sql',
    classGrade: '10',
    unitId: 'c10-u3',
    unitNumber: 3,
    chapterNumber: '3.1',
    moduleTitle: 'Unit 3: Fundamentals of Databases & SQL',
    title: 'Tables, Fields, Primary Keys and SQL SELECT Queries',
    titleHindi: '3.1 डेटाबेस सिद्धांत: टेबल्स, प्राइमरी की एवं SQL SELECT क्वेरी',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'डेटाबेस और DBMS का परिचय एवं स्प्रेडशीट से तुलना',
      'तालिका (Table/Relation), फ़ील्ड (Attribute) और रिकॉर्ड (Tuple)',
      'Primary Key की अवधारणा और डेटा अखंडता (Data Integrity)',
      'SQL का परिचय, SELECT, FROM, WHERE क्लॉज और तुलना ऑपरेटर',
    ],
    introHindi: `जब डेटा लाखों और करोड़ों में हो (जैसे बिहार बोर्ड के सभी परीक्षार्थियों के रोल नंबर और प्राप्तांक), तब स्प्रेडशीट धीमी पड़ जाती है। ऐसे विशाल डेटा को सुरक्षित और तीव्र गति से संभालने के लिए **Database (डेटाबेस)** और **SQL** का उपयोग होता है।`,
    explanationHindi: `### 1. डेटाबेस की मूल शब्दावली:
- **Table:** पंक्तियों और स्तंभों में व्यवस्थित डेटा संग्रह।
- **Field / Attribute (कॉलम):** विशेष श्रेणी (उदा. Roll_No, Name, Marks)।
- **Record / Tuple (पंक्ति):** किसी एक छात्र का संपूर्ण व्यक्तिगत ब्योरा।

### 2. Primary Key (प्राइमरी कुंजी):
तालिका का वह विशिष्ट कॉलम जो प्रत्येक रिकॉर्ड को अलग पहचानता है।
- यह कभी **NULL (खाली)** नहीं हो सकता।
- इसका मान कभी **Duplicate (दोहराव)** नहीं हो सकता।
*उदा.* छात्र का **Roll_No** या नागरिक का **Aadhaar Number**।

### 3. SQL (Structured Query Language):
डेटाबेस से बातचीत करने की मानक भाषा:
\`\`\`sql
-- 1. सभी छात्रों का पूरा रिकॉर्ड देखना
SELECT * FROM STUDENT;

-- 2. केवल नाम और अंक देखना जहाँ अंक 80 से ज्यादा हों
SELECT Name, Marks 
FROM STUDENT 
WHERE Marks > 80;
\`\`\``,
    technicalTerms: [
      {
        term: 'Primary Key',
        hindiMeaning: 'प्राथमिक पहचान कुंजी',
        explanation: 'प्रत्येक रिकॉर्ड को विशिष्ट पहचान देने वाला कॉलम जो कभी खाली नहीं हो सकता।',
      },
      {
        term: 'SQL',
        hindiMeaning: 'संरचित क्वेरी भाषा',
        explanation: 'रिलेशनल डेटाबेस से डेटा निकालने और प्रबंधित करने की मानक भाषा।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: स्कूल का एडमिशन नंबर',
      scenario: 'एक ही नाम के दो बच्चे:',
      analogy: 'यदि एक ही कक्षा में दो छात्र "अमित कुमार" हों, तो शिक्षक उन्हें उनके Roll_No या Admission_No से पहचानते हैं। डेटाबेस में यही काम Primary Key करती है।',
      takeaway: 'Primary Key डेटा में किसी भी भ्रम या डुप्लीकेसी को रोकती है।',
    },
    importantPoints: [
      'टेबल की क्षैतिज पंक्ति को Tuple/Record कहते हैं।',
      'टेबल के लंबवत कॉलम को Attribute/Field कहते हैं।',
      'SQL में * का अर्थ "सभी कॉलम" होता है।',
    ],
    faqs: [
      {
        question: 'क्या एक टेबल में दो Primary Key हो सकती हैं?',
        answer: 'नहीं, एक तालिका में केवल एक ही प्राइमरी की हो सकती है।',
      },
    ],
    mcqs: [
      {
        id: 'q10-db-1',
        question: 'डेटाबेस में टेबल की एक पंक्ति (Row) को क्या कहा जाता है?',
        options: ['Attribute', 'Tuple', 'Field', 'Key'],
        correctIndex: 1,
        explanationHindi: 'रिलेशनल डेटाबेस में पंक्ति को Tuple या Record कहा जाता है।',
      },
      {
        id: 'q10-db-2',
        question: 'Primary Key का मान क्या कभी खाली (NULL) हो सकता है?',
        options: ['हाँ', 'नहीं', 'केवल एक बार', 'शर्त के अनुसार'],
        correctIndex: 1,
        explanationHindi: 'Primary Key की प्रमुख विशेषता है कि यह कभी भी खाली (NULL) नहीं हो सकती।',
      },
    ],
    shortQuestions: [
      {
        question: 'डेटाबेस में Primary Key का क्या महत्व है?',
        marks: 2,
        answerHindi: 'Primary Key तालिका के प्रत्येक रिकॉर्ड को विशिष्ट (Unique) रूप से पहचानती है और डेटा के अवांछित दोहराव को रोककर डेटा की अखंडता व शुद्धता सुनिश्चित करती है।',
      },
    ],
    practicalExercise: 'SQL Lab में जाकर STUDENT टेबल से 80 से अधिक अंक वाले छात्रों को खोजने की क्वेरी चलाएँ।',
  },

  {
    id: 'c10-unit4-networks-html',
    classGrade: '10',
    unitId: 'c10-u4',
    unitNumber: 4,
    chapterNumber: '4.1',
    moduleTitle: 'Unit 4: Computer Networks and HTML Web Designing',
    title: 'LAN vs WAN, Client-Server Model and HTML Web Designing',
    titleHindi: '4.1 कंप्यूटर नेटवर्क (LAN/WAN), क्लाइंट-सर्वर एवं HTML वेब डिज़ाइनिंग',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'कंप्यूटर नेटवर्क के उद्देश्य और प्रकार: LAN (Local Area Network) बनाम WAN (Wide Area Network)',
      'नेटवर्क उपकरण (Router, Switch, Modem) और वायर्ड बनाम वायरलेस संचार',
      'क्लाइंट-सर्वर मॉडल और वेब होस्टिंग की अवधारणा',
      'HTML का परिचय, संरचना और मूल टैग्स (`<html>`, `<head>`, `<title>`, `<body>`, `<h1>`-`<h6>`, `<p>`, `<a>`, `<ol>`, `<ul>`)',
    ],
    introHindi: `इंटरनेट पर उपलब्ध वेबसाइट्स कैसे बनती हैं और हमारे फोन तक कैसे पहुँचती हैं? यह कंप्यूटर नेटवर्किंग और HTML वेब डिजाइनिंग का अद्भुत संगम है।`,
    explanationHindi: `### 1. LAN बनाम WAN:
- **LAN (Local Area Network):** एक कमरे या स्कूल कंप्यूटर लैब में सीमित नेटवर्क। तीव्र गति (100 Mbps - 1 Gbps)।
- **WAN (Wide Area Network):** पूरे देश या विश्व में फैला नेटवर्क (उदा. **Internet**)।

### 2. क्लाइंट-सर्वर मॉडल:
- **Client (ग्राहक):** सेवा का अनुरोध करने वाला उपकरण (उदा. आपका मोबाइल फोन)।
- **Server (सेवक):** सेवा और डेटा प्रदान करने वाला केंद्रीय कंप्यूटर (उदा. BSEB रिजल्ट सर्वर)।

### 3. HTML (HyperText Markup Language):
वेबपेज का ढांचा तैयार करने वाली भाषा:
\`\`\`html
<!DOCTYPE html>
<html>
  <head>
    <title>मेरा पहला वेबपेज</title>
  </head>
  <body>
    <h1>नमस्ते बिहार!</h1>
    <p>सीखिए कंप्यूटर साइंस अपनी भाषा में।</p>
    <a href="https://biharboardonline.bihar.gov.in">BSEB पोर्टल</a>
  </body>
</html>
\`\`\``,
    technicalTerms: [
      {
        term: 'Router (राउटर)',
        hindiMeaning: 'नेटवर्क मार्गदर्शक',
        explanation: 'विभिन्न नेटवर्क्स को जोड़ने और डेटा पैकेट्स को सही रास्ता दिखाने वाला उपकरण।',
      },
      {
        term: 'HTML Tags',
        hindiMeaning: 'वेबपेज संरचना निर्देश',
        explanation: 'कोण कोष्ठकों (< >) में लिखे विशेष शब्द जो ब्राउज़र को निर्देश देते हैं।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: ग्राहक और दुकानदार (Client-Server)',
      scenario: 'दुकान से सामान खरीदना:',
      analogy: 'आप (Client) दुकान पर जाकर कहते हैं "मुझे एक कॉपी दीजिए" (Request)। दुकानदार (Server) अलमारी से कॉपी निकालकर आपको देता है (Response)। इंटरनेट पर भी मोबाइल और सर्वर ऐसे ही बात करते हैं!',
      takeaway: 'क्लाइंट अनुरोध करता है और सर्वर प्रतिक्रिया देता है।',
    },
    importantPoints: [
      'इंटरनेट WAN का सबसे बड़ा उदाहरण है।',
      'HTML कोई प्रोग्रामिंग भाषा नहीं बल्कि मार्कअप भाषा है।',
      '<h1> सबसे बड़ी हेडिंग और <h6> सबसे छोटी हेडिंग होती है।',
    ],
    faqs: [
      {
        question: 'HTML फाइलों को कैसे सहेजा (Save) जाता है?',
        answer: 'HTML फाइलों को .html एक्सटेंशन (जैसे index.html) के साथ सहेजा जाता है और किसी भी ब्राउज़र में खोला जा सकता है।',
      },
    ],
    mcqs: [
      {
        id: 'q10-net-1',
        question: 'इंटरनेट निम्नलिखित में से किसका उदाहरण है?',
        options: ['LAN', 'MAN', 'WAN', 'PAN'],
        correctIndex: 2,
        explanationHindi: 'इंटरनेट संपूर्ण विश्व में फैला हुआ Wide Area Network (WAN) है।',
      },
      {
        id: 'q10-net-2',
        question: 'HTML में हाइपरलिंक बनाने के लिए किस टैग का प्रयोग होता है?',
        options: ['<link>', '<a>', '<href>', '<url>'],
        correctIndex: 1,
        explanationHindi: 'हाइपरलिंक बनाने के लिए <a> (Anchor) टैग का उपयोग किया जाता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'LAN और WAN में दो मुख्य अंतर लिखिए।',
        marks: 2,
        answerHindi: '1. LAN एक छोटे भौगोलिक क्षेत्र (जैसे स्कूल लैब) में सीमित होता है, जबकि WAN पूरे देश या विश्व में फैला होता है। 2. LAN की गति बहुत तेज होती है, जबकि WAN की गति माध्यम पर निर्भर करती है।',
      },
    ],
    practicalExercise: 'एक साधारण वेबपेज कोड लिखकर उसमें अपना नाम, स्कूल का नाम और पसंदीदा विषय प्रदर्शित करें।',
  },

  // =========================================================================
  // CLASS 11: COMPUTER SCIENCE (BSEB 70 MARKS THEORY + 30 MARKS PRACTICAL)
  // =========================================================================
  {
    id: 'c11-unit1-fundamentals',
    classGrade: '11',
    unitId: 'c11-u1',
    unitNumber: 1,
    chapterNumber: '1.1',
    moduleTitle: 'Unit 1: Computer Fundamentals (6 Marks)',
    title: 'Evolution of Computers, OS Functions and Software Concepts',
    titleHindi: '1.1 कंप्यूटर फंडामेंटल्स: विकास, ऑपरेटिंग सिस्टम एवं सॉफ्टवेयर',
    isOfficialSyllabus: true,
    estimatedMins: 25,
    learningObjectives: [
      'कंप्यूटर का विकास और बुनियादी संचालन (बूटिंग की अवधारणा)',
      'ऑपरेटिंग सिस्टम के कार्य: प्रोसेसर, मेमोरी, फाइल और डिवाइस प्रबंधन',
      'ओएस के प्रकार: GUI, Time-Sharing, Real-Time और Distributed (Solaris, UNIX, LINUX, Windows)',
      'सॉफ्टवेयर के प्रकार: सिस्टम सॉफ्टवेयर, यूटिलिटी सॉफ्टवेयर और एप्लीकेशन सॉफ्टवेयर',
    ],
    introHindi: `कक्षा 11वीं के प्रिय विद्यार्थियों! बिहार बोर्ड के आधिकारिक 70 अंकों के पाठ्यक्रम का पहला यूनिट 'Computer Fundamentals' (6 अंक) कंप्यूटर की आंतरिक कार्यप्रणाली और ऑपरेटिंग सिस्टम के कार्यों को गहराई से समझाता है।`,
    explanationHindi: `### 1. बूटिंग (Booting) क्या है?
जब कंप्यूटर को चालू किया जाता है, तो ROM में स्थित BIOS (Basic Input Output System) हार्डवेयर की जाँच (POST - Power On Self Test) करता है और ऑपरेटिंग सिस्टम को हार्ड डिस्क से मुख्य मेमोरी (RAM) में लोड करता है। इस प्रक्रिया को **बूटिंग** कहते हैं:
- **Cold Booting:** पूरी तरह बंद कंप्यूटर को पावर बटन दबाकर चालू करना।
- **Warm Booting:** पहले से चालू कंप्यूटर को रीस्टार्ट (Ctrl+Alt+Del) करना।

### 2. ऑपरेटिंग सिस्टम के 4 प्रमुख कार्य:
1. **Processor Management:** CPU समय का विभिन्न प्रक्रियाओं में कुशल आवंटन (Scheduling)।
2. **Memory Management:** रैम में प्रोग्राम्स को स्थान देना और कार्य समाप्त होने पर मुक्त करना।
3. **File Management:** फाइलों और फ़ोल्डरों को श्रेणीबद्ध निर्देशिका (Hierarchical Directory Structure) में व्यवस्थित करना।
4. **Device Management:** इनपुट-आउटपुट उपकरणों के ड्राइवर्स को नियंत्रित करना।

### 3. ऑपरेटिंग सिस्टम के प्रकार:
- **GUI (Graphical User Interface):** आइकन्स और माउस आधारित (Windows, Mac OS)।
- **Time Sharing OS:** एक ही सीपीयू का समय कई उपयोगकर्ताओं में बाँटना (UNIX, Linux)।
- **Real-Time OS:** निश्चित समय सीमा में परिणाम देना अनिवार्य (मिसाइल नियंत्रण, हवाई यातायात)।
- **Distributed OS:** कई अलग-अलग कंप्यूटर मिलकर एक साझा कार्य हल करते हैं।`,
    technicalTerms: [
      {
        term: 'Booting (बूटिंग)',
        hindiMeaning: 'कंप्यूटर प्रारंभ प्रक्रिया',
        explanation: 'हार्ड डिस्क से ऑपरेटिंग सिस्टम को मुख्य मेमोरी (RAM) में लोड करने की प्रक्रिया।',
      },
      {
        term: 'Device Driver',
        hindiMeaning: 'उपकरण अनुवादक सॉफ्टवेयर',
        explanation: 'वह सिस्टम सॉफ्टवेयर जो ऑपरेटिंग सिस्टम को हार्डवेयर (जैसे प्रिंटर) से बातचीत कराता है।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: विद्यालय का प्रधानाध्यापक (Operating System)',
      scenario: 'विद्यालय का सुचारू संचालन:',
      analogy: 'प्रधानाध्यापक तय करते हैं कि कौन सा शिक्षक किस कक्षा में जाएगा (Processor Management), कौन सा कमरा किसे मिलेगा (Memory Management), और खेल का मैदान कब खुलेगा (Device Management)। कंप्यूटर में यही काम ऑपरेटिंग सिस्टम करता है!',
      takeaway: 'बिना ऑपरेटिंग सिस्टम के कंप्यूटर का कोई भी हार्डवेयर काम नहीं कर सकता।',
    },
    importantPoints: [
      'POST (Power On Self Test) बूटिंग के समय हार्डवेयर की जाँच करता है।',
      'लिनक्स (LINUX) और यूनिक्स (UNIX) मल्टी-यूजर और टाइम-शेयरिंग ऑपरेटिंग सिस्टम हैं।',
      'BSEB परीक्षा में ओएस के कार्यों पर 2 या 5 अंक का प्रश्न निश्चित रूप से पूछा जाता है।',
    ],
    faqs: [
      {
        question: 'यूटिलिटी सॉफ्टवेयर क्या होता है?',
        answer: 'वह सॉफ्टवेयर जो कंप्यूटर के रख-रखाव और सुरक्षा में मदद करता है, जैसे एंटीवायरस, डिस्क क्लीनअप और फाइल कम्प्रेशन टूल्स।',
      },
    ],
    mcqs: [
      {
        id: 'q11-u1-1',
        question: 'कंप्यूटर स्टार्ट होते ही हार्डवेयर की जांच करने वाली प्रक्रिया क्या कहलाती है?',
        options: ['POST', 'BOOT', 'COMPILE', 'LOAD'],
        correctIndex: 0,
        explanationHindi: 'POST (Power On Self Test) बूटिंग के समय सभी हार्डवेयर घटकों की सक्रियता की जांच करता है।',
      },
      {
        id: 'q11-u1-2',
        question: 'निम्नलिखित में से कौन सा ऑपरेटिंग सिस्टम का मुख्य कार्य नहीं है?',
        options: ['प्रोसेसर प्रबंधन', 'मेमोरी प्रबंधन', 'इंटरनेट पर वीडियो देखना', 'फाइल प्रबंधन'],
        correctIndex: 2,
        explanationHindi: 'इंटरनेट वीडियो देखना एक एप्लीकेशन का कार्य है, ओएस का कार्य सिस्टम संसाधनों का प्रबंधन करना है।',
      },
    ],
    shortQuestions: [
      {
        question: 'Cold Booting और Warm Booting में अंतर स्पष्ट कीजिए।',
        marks: 2,
        answerHindi: 'Cold Booting में कंप्यूटर को पूरी तरह बंद अवस्था से पावर बटन दबाकर शुरू किया जाता है। Warm Booting में पहले से चालू कंप्यूटर को रीस्टार्ट किया जाता है (बिना पावर काटे)।',
      },
    ],
    practicalExercise: 'विंडोज कमांड प्रॉम्प्ट में जाकर `dir` कमांड चलाकर फाइलों और डायरेक्ट्रीज की सूची देखें।',
  },

  {
    id: 'c11-unit2-programming-methodology',
    classGrade: '11',
    unitId: 'c11-u2',
    unitNumber: 2,
    chapterNumber: '2.1',
    moduleTitle: 'Unit 2: Programming Methodology (10 Marks)',
    title: 'Problem Solving, Modular Approach, Documentation and Errors',
    titleHindi: '2.1 प्रोग्रामिंग कार्यप्रणाली: मॉड्यूलर दृष्टिकोण एवं त्रुटियों के प्रकार',
    isOfficialSyllabus: true,
    estimatedMins: 25,
    learningObjectives: [
      'समस्या समाधान तकनीक: समस्या को समझना, न्यूनतम इनपुट पहचानना, चरण-दर-चरण समाधान',
      'मॉड्यूलर दृष्टिकोण (Modular Approach) और कोड स्पष्टता',
      'दस्तावेजीकरण (Documentation), टिप्पणियाँ (Comments) और इंडेंटेशन (Indentation)',
      'प्रोग्रामिंग त्रुटियों के प्रकार: सिंटैक्स एरर, रन-टाइम एरर, लॉजिकल एरर',
    ],
    introHindi: `सफल प्रोग्रामर बनने के लिए केवल कोड लिखना काफी नहीं है, बल्कि समस्या को सुनियोजित तरीके से छोटे-छोटे मॉड्यूल्स में तोड़ना और त्रुटियों (Bugs) को पहचानना आवश्यक है।`,
    explanationHindi: `### 1. मॉड्यूलर दृष्टिकोण (Modular Approach):
किसी बड़े और जटिल प्रोग्राम को छोटे-छोटे स्वतंत्र फ़ंक्शंस या मॉड्यूल्स में विभाजित करके लिखना। 
- **लाभ:** कोड को पढ़ना, टेस्ट करना और सुधारना बहुत आसान हो जाता है।

### 2. प्रोग्रामिंग त्रुटियों के 3 मुख्य प्रकार (BSEB बोर्ड का पसंदीदा प्रश्न):
1. **Syntax Error (सिंटैक्स त्रुटि):**
   - प्रोग्रामिंग भाषा के व्याकरण के नियमों का उल्लंघन (उदा. सेमीकोलन छूट जाना, गलत स्पेलिंग)।
   - यह प्रोग्राम के कंपाइल होते समय ही पकड़ा जाता है।
2. **Run-Time Error (रन-टाइम त्रुटि):**
   - कंपाइलेशन सही होता है, लेकिन प्रोग्राम चलते समय अप्रत्याशित स्थिति के कारण क्रैश हो जाता है।
   - *उदा.* किसी संख्या को शून्य से भाग देना (\`X / 0\`), या फाइल न मिलना।
3. **Logical Error (तार्किक त्रुटि):**
   - प्रोग्राम बिना किसी एरर मैसेज के सफलतापूर्वक चलता है, लेकिन **गलत परिणाम (Wrong Output)** देता है।
   - *उदा.* दो संख्याओं का जोड़ निकालने के लिए \`+\` की जगह \`*\` लिख देना। कंपाइलर इसे पकड़ नहीं सकता, इसे ड्राई-रन द्वारा ढूंढना पड़ता है।`,
    technicalTerms: [
      {
        term: 'Indentation (इंडेंटेशन)',
        hindiMeaning: 'उचित हाशिया छोड़ना',
        explanation: 'लूप्स और कंडीशन्स के अंदर कोड को आगे खिसकाकर लिखना जिससे प्रोग्राम की पठनीयता बढ़ती है।',
      },
      {
        term: 'Logical Error',
        hindiMeaning: 'तार्किक भूल',
        explanation: 'प्रोग्रामर के गलत लॉजिक के कारण सही कोड द्वारा गलत उत्तर प्राप्त होना।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: गणित के प्रश्न में गलत सूत्र लगाना',
      scenario: 'परीक्षा में त्रिभुज का क्षेत्रफल निकालना:',
      analogy: 'यदि आपने कॉपी में साफ लिखा है और हैंडराइटिंग सही है (No Syntax Error), लेकिन क्षेत्रफल के सूत्र में ½ × आधार × ऊँचाई की जगह आधार + ऊँचाई लगा दिया, तो उत्तर गलत आएगा। यही Logical Error है!',
      takeaway: 'कंपाइलर आपके नियम जांच सकता है, आपकी सोच का लॉजिक नहीं।',
    },
    importantPoints: [
      'सिंटैक्स एरर कंपाइलर द्वारा तुरंत बता दिया जाता है।',
      'किसी संख्या को 0 से भाग देना रन-टाइम एरर (Division by Zero) है।',
      'इंडेंटेशन और कमेंट्स कोड को समझने योग्य बनाते हैं।',
    ],
    faqs: [
      {
        question: 'टिप्पणियों (Comments) का क्या महत्व है?',
        answer: 'Comments कंपाइलर द्वारा अनदेखे कर दिए जाते हैं। ये प्रोग्रामर और शिक्षकों को यह समझाने के लिए होते हैं कि कोई विशेष कोड क्या कार्य कर रहा है।',
      },
    ],
    mcqs: [
      {
        id: 'q11-pm-1',
        question: 'किसी संख्या को शून्य (0) से भाग देने पर किस प्रकार की त्रुटि होती है?',
        options: ['Syntax Error', 'Run-Time Error', 'Logical Error', 'Compiler Error'],
        correctIndex: 1,
        explanationHindi: 'शून्य से भाग देना गणितीय रूप से अपरिभाषित है, अतः यह प्रोग्राम निष्पादन के समय रन-टाइम एरर उत्पन्न करता है।',
      },
      {
        id: 'q11-pm-2',
        question: 'यदि प्रोग्राम बिना किसी एरर के चलता है पर उत्तर गलत आता है, तो वह कौन सी त्रुटि है?',
        options: ['Syntax Error', 'Run-Time Error', 'Logical Error', 'Linking Error'],
        correctIndex: 2,
        explanationHindi: 'गलत लॉजिक या गलत फॉर्मूला लगाने पर होने वाली भूल Logical Error कहलाती है।',
      },
    ],
    shortQuestions: [
      {
        question: 'Syntax Error और Logical Error में क्या अंतर है?',
        marks: 2,
        answerHindi: 'Syntax Error प्रोग्रामिंग भाषा के व्याकरण के नियम टूटने पर आती है और कंपाइलर इसे तुरंत रोक देता है। Logical Error प्रोग्रामर के गलत तर्क के कारण होती है, कंपाइलर कोई एरर नहीं दिखाता लेकिन आउटपुट गलत आता है।',
      },
    ],
    practicalExercise: 'C++ लैब में जाकर जानबूझकर एक सेमीकोलन हटाएं और देखें कंपाइलर क्या एरर संदेश देता है।',
  },

  {
    id: 'c11-unit3-cpp-comprehensive',
    classGrade: '11',
    unitId: 'c11-u3',
    unitNumber: 3,
    chapterNumber: '3.1',
    moduleTitle: 'Unit 3: Introduction to Programming in C++ (44 Marks)',
    title: 'Tokens, Operators, Flow of Control, Arrays, Strings and Functions',
    titleHindi: '3.1 संपूर्ण C++ प्रोग्रामिंग: टोकन, ऑपरेटर, एरे, स्ट्रिंग्स एवं फ़ंक्शंस',
    isOfficialSyllabus: true,
    estimatedMins: 35,
    learningObjectives: [
      'C++ टोकन: कीवर्ड्स, आइडेंटिफायर्स, लिटरल्स/कांस्टेंट, बैकस्लैश कैरेक्टर (`\\n`, `\\t`)',
      'ऑपरेटर: इंक्रीमेंट/डिक्रीमेंट (`++`, `--`), टर्नरी ऑपरेटर (`? :`), टाइप कास्टिंग',
      'फ्लो ऑफ कंट्रोल: `switch..case..default`, `break`, `while`, `do-while`, `for`',
      '1D व 2D Arrays, String फंक्शंस (`strcpy`, `strcat`, `strlen`, `strcmp`) एवं User Defined Functions',
    ],
    introHindi: `यूनिट 3 कक्षा 11वीं का सबसे महत्वपूर्ण खंड है जिसका बोर्ड परीक्षा में 44 अंकों का वेटेज है! इसमें C++ भाषा के बुनियादी से लेकर उन्नत प्रोग्रामिंग घटकों का पूर्ण समावेश है।`,
    explanationHindi: `### 1. C++ टोकन (Tokens):
प्रोग्राम की सबसे छोटी व्यक्तिगत इकाई टोकन कहलाती है:
- **Keywords:** आरक्षित शब्द (उदा. \`int\`, \`float\`, \`if\`, \`return\`, \`const\`)।
- **Identifiers:** चरों, ऐरे और फ़ंक्शंस के नाम।
- **Constants (लिटरल्स):** अचर मान (उदा. 100, 3.14, 'A', "Patna")।
- **Backslash Characters:** \`\\n\` (नई लाइन), \`\\t\` (टैब स्पेस)।

### 2. विशेष ऑपरेटर्स:
- **Increment / Decrement:**
  - \`++x\` (Pre-increment): पहले मान 1 बढ़ेगा, फिर उपयोग होगा।
  - \`x++\` (Post-increment): पहले वर्तमान मान उपयोग होगा, फिर 1 बढ़ेगा।
- **Conditional (Ternary) Operator:**
  \`int max = (a > b) ? a : b;\`

### 3. स्ट्रक्चर्ड डेटा टाइप: Arrays (सरणी):
- **1D Array:** \`int marks[5] = {85, 90, 78, 92, 88};\` (इंडेक्स 0 से 4 तक)।
- **2D Array (मैट्रिक्स):** \`int matrix[3][3];\` (3 पंक्तियाँ और 3 कॉलम)।

### 4. स्ट्रिंग और कैरेक्टर फ़ंक्शंस:
- \`strlen(str)\`: स्ट्रिंग की लंबाई गिनना।
- \`strcpy(dest, src)\`: एक स्ट्रिंग को दूसरी में कॉपी करना।
- \`strcat(s1, s2)\`: दो स्ट्रिंग्स को आपस में जोड़ना।
- \`strcmp(s1, s2)\`: दो स्ट्रिंग्स की तुलना करना।
- \`toupper(c)\`, \`tolower(c)\`: अक्षर को बड़ा/छोटा करना (\`<ctype.h>\`)।

### 5. Call by Value बनाम Call by Reference:
- **Call by Value:** फ़ंक्शन को चर की प्रतिलिपि (Copy) भेजी जाती है; मुख्य मान नहीं बदलता।
- **Call by Reference (\`&\`):** चर का मेमोरी पता भेजा जाता है; फ़ंक्शन के अंदर का बदलाव मुख्य चर में भी दिखता है।`,
    technicalTerms: [
      {
        term: 'Array (सरणी)',
        hindiMeaning: 'समान डेटा प्रकार का क्रमबद्ध समूह',
        explanation: 'मेमोरी में लगातार स्थानों पर रखे गए समान डेटा टाइप के तत्वों का संग्रह।',
      },
      {
        term: 'Call by Reference',
        hindiMeaning: 'मेमोरी पते द्वारा फ़ंक्शन कॉल',
        explanation: 'फ़ंक्शन में मान की बजाय वेरिएबल का एड्रेस (&) भेजना।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: स्कूल का हाजिरी रजिस्टर (2D Array)',
      scenario: '30 छात्र और 6 दिन की हाजिरी:',
      analogy: 'रजिस्टर में हर छात्र की अपनी एक पंक्ति (Row) है और सप्ताह के प्रत्येक दिन का अपना कॉलम (Column) है। C++ में matrix[row][col] भी बिल्कुल हाजिरी रजिस्टर की तरह 2-आयामी डेटा सहेजता है!',
      takeaway: '2D ऐरे टेबल या ग्रिड जैसी समस्याओं को हल करने का सबसे शक्तिशाली औजार है।',
    },
    importantPoints: [
      'एरे का पहला इंडेक्स हमेशा 0 से शुरू होता है।',
      'switch कथन में केवल int और char डेटा टाइप का परीक्षण हो सकता है।',
      '44 अंकों के लिए C++ सिंटैक्स और ड्राई-रन का अभ्यास अत्यंत आवश्यक है।',
    ],
    faqs: [
      {
        question: 'cin >> str और gets(str) में क्या अंतर है?',
        answer: 'cin >> स्पेस आने पर इनपुट पढ़ना बंद कर देता है, जबकि gets() पूरी लाइन (स्पेस सहित) पढ़ता है।',
      },
    ],
    mcqs: [
      {
        id: 'q11-cpp-all-1',
        question: 'स्ट्रिंग की लंबाई ज्ञात करने के लिए string.h का कौन सा फ़ंक्शन उपयोग होता है?',
        options: ['length()', 'strlen()', 'size()', 'strcount()'],
        correctIndex: 1,
        explanationHindi: 'C++ में C-स्टाइल स्ट्रिंग की लंबाई गिनने के लिए strlen() फ़ंक्शन का प्रयोग होता है।',
      },
      {
        id: 'q11-cpp-all-2',
        question: 'यदि a = 5 हो, तो int b = ++a; के बाद a और b का मान क्या होगा?',
        options: ['a = 5, b = 6', 'a = 6, b = 6', 'a = 6, b = 5', 'a = 5, b = 5'],
        correctIndex: 1,
        explanationHindi: 'Pre-increment (++a) में पहले a 1 बढ़कर 6 होता है, फिर वह 6 मान b में चला जाता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'Call by Value और Call by Reference में दो अंतर स्पष्ट कीजिए।',
        marks: 2,
        answerHindi: '1. Call by Value में वेरिएबल की कॉपी भेजी जाती है, जिससे मूल मान अपरिवर्तित रहता है। 2. Call by Reference में वेरिएबल का रेफरेंस (&) भेजा जाता है, जिससे फ़ंक्शन के भीतर किए गए परिवर्तन मुख्य वेरिएबल में भी लागू हो जाते हैं।',
      },
    ],
    practicalExercise: 'C++ Lab में जाकर 1D ऐरे के 5 तत्वों का योग और औसत निकालने का प्रोग्राम चलाएँ।',
  },

  {
    id: 'c11-unit4-system-organisation',
    classGrade: '11',
    unitId: 'c11-u4',
    unitNumber: 4,
    chapterNumber: '4.1',
    moduleTitle: 'Unit 4: Computer System Organisation (10 Marks)',
    title: 'Microprocessors, Memory Hierarchy, Number Systems and Ports',
    titleHindi: '4.1 कंप्यूटर सिस्टम संगठन: माइक्रोप्रोसेसर, पोर्ट्स, मेमोरी एवं एन्कोडिंग',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'संख्या प्रणालियाँ: बाइनरी, ऑक्टल (आधार 8), दशमलव और हेक्साडेसिमल (आधार 16) एवं 2 का पूरक (2s Complement)',
      'आंतरिक कैरेक्टर एन्कोडिंग: ASCII, ISCII (भारतीय लिपियों का मानक कोड), UNICODE',
      'माइक्रोप्रोसेसर: क्लॉक स्पीड (MHz, GHz), 32-बिट/64-बिट, CISC बनाम RISC, सिस्टम बसें (Address, Data, Control)',
      'मेमोरी और पोर्ट्स: L1/L2 कैश, DRAM/SDRAM, SMPS (पावर सप्लाई), UPS, USB, HDMI, सीरियल/पैरेलल पोर्ट्स',
    ],
    introHindi: `यूनिट 4 (10 अंक) हमें यह सिखाता है कि कंप्यूटर का मदरबोर्ड, प्रोसेसर, मेमोरी चिप्स और पोर्ट्स आपस में मिलकर एक शक्तिशाली सिस्टम का निर्माण कैसे करते हैं।`,
    explanationHindi: `### 1. संख्या प्रणालियाँ और 2 का पूरक:
- **Binary (2):** 0, 1
- **Octal (8):** 0 से 7
- **Hexadecimal (16):** 0 से 9, और A(10), B(11), C(12), D(13), E(14), F(15)
- **2's Complement:** बाइनरी में ऋणात्मक संख्याओं को प्रदर्शित करने की विधि (1's Complement + 1)।

### 2. भारतीय एवं वैश्विक एन्कोडिंग:
- **ASCII:** 7 या 8 बिट्स (केवल अंग्रेजी और पश्चिमी अक्षर)।
- **ISCII:** Indian Script Standard Code for Information Interchange (देवनागरी, मैथिली, भोजपुरी सहित भारतीय लिपियों के लिए)।
- **UNICODE:** 16/32 बिट्स, जो दुनिया की सभी भाषाओं को समाहित करता है।

### 3. माइक्रोप्रोसेसर और बसें:
- **Clock Speed:** प्रति सेकंड अरबों चक्रों में गति (GHz में मापी जाती है)।
- **Address Bus:** मेमोरी का पता ले जाने वाली बस (एकदिशीय / Unidirectional)।
- **Data Bus:** डेटा का आदान-प्रदान करने वाली बस (द्विदिशीय / Bidirectional)।
- **Accumulator, IR, PC:** निर्देश निष्पादित करने वाले मुख्य आंतरिक रजिस्टर्स।

### 4. बिजली आपूर्ति (Power Supply):
- **SMPS (Switched Mode Power Supply):** एसी वोल्टेज (220V) को कंप्यूटर के उपयुक्त सुरक्षित डीसी वोल्टेज (+5V, +12V) में बदलता है।
- **UPS (Uninterrupted Power Supply):** बिजली जाने पर बिना रुकावट बैटरी बैकअप देता है।`,
    technicalTerms: [
      {
        term: 'SMPS',
        hindiMeaning: 'स्विच्ड मोड पावर सप्लाई',
        explanation: 'मदरबोर्ड और हार्ड डिस्क को सुरक्षित स्थिर डीसी बिजली देने वाला उपकरण।',
      },
      {
        term: 'ISCII',
        hindiMeaning: 'भारतीय लिपि सूचना विनिमय मानक कोड',
        explanation: 'भारतीय भाषाओं और देवनागरी लिपि के मानकीकरण हेतु 8-बिट एन्कोडिंग योजना।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: शहर की चौड़ी सड़कें (System Buses)',
      scenario: 'पटना की सड़कें:',
      analogy: 'Data Bus एक टू-वे सड़क है जिस पर गाड़ियाँ दोनों तरफ जा सकती हैं (डेटा आना और जाना)। Address Bus वन-वे सड़क है जो केवल पते की दिशा बताती है। बस जितनी चौड़ी (64-बिट) होगी, उतना अधिक ट्रैफिक एक साथ गुजर सकेगा!',
      takeaway: '64-बिट प्रोसेसर 32-बिट की तुलना में दोगुनी तेजी से डेटा प्रोसेस कर सकता है।',
    },
    importantPoints: [
      'हेक्साडेसिमल में 10 को A, 11 को B, 12 को C, 13 को D, 14 को E और 15 को F लिखा जाता है।',
      'Address Bus एकदिशीय और Data Bus द्विदिशीय होती है।',
      'L1 और L2 कैश मेमोरी सीपीयू चिप के सबसे करीब होती हैं।',
    ],
    faqs: [
      {
        question: 'CISC और RISC प्रोसेसर में क्या अंतर है?',
        answer: 'RISC (Reduced Instruction Set Computer) में कम और तेज निर्देश होते हैं, जबकि CISC (Complex Instruction Set Computer) में अधिक जटिल और बहु-चरणीय निर्देश होते हैं।',
      },
    ],
    mcqs: [
      {
        id: 'q11-cso-1',
        question: 'हेक्साडेसिमल संख्या प्रणाली में आधार (Base) कितना होता है?',
        options: ['2', '8', '10', '16'],
        correctIndex: 3,
        explanationHindi: 'हेक्साडेसिमल में 0 से F तक कुल 16 प्रतीक होते हैं, अतः आधार 16 होता है।',
      },
      {
        id: 'q11-cso-2',
        question: 'कंप्यूटर के आंतरिक पुर्जों को AC से DC में बिजली आपूर्ति कौन करता है?',
        options: ['RAM', 'SMPS', 'ALU', 'BIOS'],
        correctIndex: 1,
        explanationHindi: 'SMPS (Switched Mode Power Supply) 220V AC को मदरबोर्ड के लिए आवश्यक DC करंट में बदलता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'Address Bus और Data Bus में अंतर बताइए।',
        marks: 2,
        answerHindi: 'Address Bus सीपीयू से मेमोरी या इनपुट-आउटपुट डिवाइस की ओर मेमोरी एड्रेस ले जाती है और यह एकदिशीय (Unidirectional) होती है। Data Bus डेटा और निर्देशों को सीपीयू और मेमोरी के बीच दोनों दिशाओं में ले जाती है और यह द्विदिशीय (Bidirectional) होती है।',
      },
    ],
    practicalExercise: 'संख्या (15)₁₀ को हेक्साडेसिमल में बदलें और देखें कि इसका उत्तर "F" क्यों आता है।',
  },

  // =========================================================================
  // CLASS 12: ADVANCED COMPUTER SCIENCE (BSEB 70 MARKS THEORY + 30 PRACTICAL)
  // =========================================================================
  {
    id: 'c12-unit1-oop-files',
    classGrade: '12',
    unitId: 'c12-u1',
    unitNumber: 1,
    chapterNumber: '1.1',
    moduleTitle: 'Unit 1: Programming in C++ (30 Marks)',
    title: 'OOP Concepts, Classes, Constructors, Inheritance, Data Files and Pointers',
    titleHindi: '1.1 ऑब्जेक्ट ओरिएंटेड प्रोग्रामिंग, इनहेरिटेंस, डेटा फाइल हैंडलिंग एवं पॉइंटर्स',
    isOfficialSyllabus: true,
    estimatedMins: 35,
    learningObjectives: [
      'OOP के 4 स्तंभ: Data Hiding, Encapsulation, Inheritance और Polymorphism',
      'क्लास और ऑब्जेक्ट, कंस्ट्रक्टर (Default, Parameterized, Copy) एवं डिस्ट्रक्टर (`~`)',
      'इनहेरिटेंस के प्रकार: Single, Multilevel, Multiple एवं विजिबिलिटी मोड्स (private, public, protected)',
      'डेटा फाइल हैंडलिंग: Text और Binary फाइल्स, `fstream.h`, `open()`, `read()`, `write()`, `eof()`, `tellg()`, `seekg()`',
      'पॉइंटर्स (`*`, `->`), डायनामिक मेमोरी आवंटन (`new`, `delete`)',
    ],
    introHindi: `कक्षा 12वीं के परीक्षार्थियों के लिए यह सबसे बड़ा यूनिट (30 अंक) है! इसमें C++ की सबसे आधुनिक तकनीक ऑब्जेक्ट ओरिएंटेड प्रोग्रामिंग, फाइल हैंडलिंग और पॉइंटर्स शामिल हैं।`,
    explanationHindi: `### 1. OOP के प्रमुख सिद्धांत:
- **Data Encapsulation:** डेटा और उससे संबंधित फ़ंक्शंस को एक ही क्लास में बाँधना।
- **Data Hiding:** डेटा को \`private\` रखकर बाहरी अनधिकृत पहुंच से बचाना।
- **Polymorphism:** बहुरूपता (जैसे Function Overloading - एक ही नाम के कई फ़ंक्शंस)।
- **Inheritance:** पुरानी क्लास (Base Class) से नई क्लास (Derived Class) बनाकर कोड का पुनः उपयोग करना।

### 2. Constructor और Destructor:
\`\`\`cpp
class Student {
public:
    int roll;
    // 1. Default Constructor
    Student() { roll = 1; }
    
    // 2. Parameterized Constructor
    Student(int r) { roll = r; }
    
    // 3. Destructor (ऑब्जेक्ट नष्ट होने पर स्वतः चलता है)
    ~Student() { cout << "ऑब्जेक्ट समाप्त हुआ!"; }
};
\`\`\`

### 3. इनहेरिटेंस (Inheritance) के प्रकार:
- **Single Inheritance:** एक बेस क्लास से एक डिराइव्ड क्लास (A -> B)।
- **Multilevel Inheritance:** एक से दूसरा, दूसरे से तीसरा (A -> B -> C)।
- **Multiple Inheritance:** दो या अधिक बेस क्लासों से एक डिराइव्ड क्लास (A, B -> C)।

### 4. डेटा फाइल हैंडलिंग (Data File Handling):
- हेडर फाइल: \`<fstream.h>\`
- \`ifstream\`: फाइल से डेटा पढ़ने के लिए (Read mode - \`ios::in\`)।
- \`ofstream\`: फाइल में डेटा लिखने के लिए (Write mode - \`ios::out\`)।
- \`fstream\`: पढ़ने और लिखने दोनों के लिए।
- \`file.read((char*)&obj, sizeof(obj));\` -> बाइनरी फाइल पढ़ना।
- \`file.write((char*)&obj, sizeof(obj));\` -> बाइनरी फाइल में लिखना।`,
    technicalTerms: [
      {
        term: 'Destructor',
        hindiMeaning: 'विनाशक फ़ंक्शन',
        explanation: 'विशेष सदस्य फ़ंक्शन जो ऑब्जेक्ट की मेमोरी समाप्त होते समय स्वतः निष्पादित होता है (टिल्ड ~ चिह्न)।',
      },
      {
        term: 'Inheritance',
        hindiMeaning: 'वंशानुक्रम / विरासत',
        explanation: 'मौजूदा क्लास के गुणों को नई क्लास में ग्रहण करने की तकनीक।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: वाहन (Vehicle) और कार (Car) का संबंध',
      scenario: 'वाहनों का वर्गीकरण:',
      analogy: 'Vehicle एक बेस क्लास है जिसके गुण हैं (पहिए, इंजन, गति)। Car क्लास ने Vehicle के इन गुणों को इनहेरिट (विरासत में प्राप्त) किया और अपना नया गुण "एसी और म्यूजिक सिस्टम" जोड़ लिया।',
      takeaway: 'Inheritance पुराने कोड को दोबारा लिखे बिना नई सुविधाएं जोड़ने की शक्ति देता है।',
    },
    importantPoints: [
      'कंस्ट्रक्टर का नाम क्लास के नाम जैसा होता है और इसका कोई रिटर्न टाइप नहीं होता।',
      'फाइल के अंत का पता लगाने के लिए eof() फ़ंक्शन का उपयोग होता है।',
      'BSEB परीक्षा में Constructor और File Handling पर 5 अंक के प्रश्न अनिवार्य रूप से आते हैं।',
    ],
    faqs: [
      {
        question: 'Text File और Binary File में क्या अंतर है?',
        answer: 'Text File में डेटा मानव-पठनीय ASCII रूप में लाइन-बाय-लाइन सेव होता है, जबकि Binary File में डेटा मेमोरी की तरह हूबहू 0 और 1 के बाइट्स में तीव्र गति से सुरक्षित होता है।',
      },
    ],
    mcqs: [
      {
        id: 'q12-oop-1',
        question: 'डिस्ट्रक्टर (Destructor) के नाम के आगे कौन सा चिह्न लगाया जाता है?',
        options: ['#', '&', '~', '*'],
        correctIndex: 2,
        explanationHindi: 'डिस्ट्रक्टर के नाम के आगे टिल्ड (~) चिह्न लगाया जाता है, जैसे ~Student()।',
      },
      {
        id: 'q12-oop-2',
        question: 'फाइलों में इनपुट-आउटपुट कार्य करने के लिए किस हेडर फाइल की आवश्यकता होती है?',
        options: ['<iostream.h>', '<fstream.h>', '<math.h>', '<stdio.h>'],
        correctIndex: 1,
        explanationHindi: '<fstream.h> फाइल स्ट्रीम्स (ifstream, ofstream, fstream) प्रदान करती है।',
      },
    ],
    shortQuestions: [
      {
        question: 'Single Inheritance और Multiple Inheritance में अंतर स्पष्ट कीजिए।',
        marks: 2,
        answerHindi: 'Single Inheritance में केवल एक बेस क्लास से एक डिराइव्ड क्लास बनती है। Multiple Inheritance में दो या अधिक बेस क्लासों से मिलकर एक नई डिराइव्ड क्लास बनाई जाती है।',
      },
    ],
    practicalExercise: 'C++ Lab में जाकर एक सरल क्लास बनाकर उसका ऑब्जेक्ट निर्मित करें और सदस्य फ़ंक्शन चलाएँ।',
  },

  {
    id: 'c12-unit2-data-structures',
    classGrade: '12',
    unitId: 'c12-u2',
    unitNumber: 2,
    chapterNumber: '2.1',
    moduleTitle: 'Unit 2: Data Structures (16 Marks)',
    title: 'Linear & Binary Search, Sorting, Stack (PUSH/POP) and Queues',
    titleHindi: '2.1 डेटा संरचनाएं: सर्चिंग, सॉर्टिंग, स्टैक (PUSH/POP) एवं क्यू',
    isOfficialSyllabus: true,
    estimatedMins: 35,
    learningObjectives: [
      'सर्चिंग एल्गोरिदम: लीनियर सर्च (Linear Search) और बाइनरी सर्च (Binary Search)',
      'सॉर्टिंग एल्गोरिदम: बबल सॉर्ट (Bubble Sort), इंसर्शन सॉर्ट, सेलेक्शन सॉर्ट',
      'स्टैक (Stack): LIFO सिद्धांत, PUSH और POP ऑपरेशन्स, इनफिक्स से पोस्टफिक्स रूपांतरण',
      'क्यू (Queue): FIFO सिद्धांत, इन्सर्ट और डिलीट ऑपरेशन्स, सर्कुलर क्यू',
    ],
    introHindi: `यूनिट 2 (16 अंक) कंप्यूटर साइंस की आत्मा है। इसमें हम सीखते हैं कि डेटा को मेमोरी में इस प्रकार कैसे व्यवस्थित किया जाए कि खोजना और छाँटना सबसे तेज हो सके।`,
    explanationHindi: `### 1. सर्चिंग (Searching):
- **Linear Search:** पहले तत्व से अंतिम तत्व तक एक-एक करके खोजना। ऐरे का क्रमबद्ध होना जरूरी नहीं।
- **Binary Search:** केवल छाँटी हुई (Sorted) सूची में काम करता है। यह हर बार सूची को दो बराबर हिस्सों (Middle) में बाँटकर बहुत तेजी से खोजता है।

### 2. सॉर्टिंग (बबल सॉर्ट - Bubble Sort):
पास-पास के दो तत्वों की तुलना करना और यदि वे गलत क्रम में हों तो उनकी अदला-बदली (Swap) करना। सबसे बड़ा तत्व हर पास में बुलबुले की तरह तैरकर अंत में पहुँच जाता है।

### 3. स्टैक (Stack - LIFO):
- **LIFO:** Last In First Out (जो सबसे अंत में आएगा, वह सबसे पहले निकलेगा)।
- **PUSH:** स्टैक के शीर्ष (Top) पर नया तत्व डालना। (फुल होने पर Stack Overflow)।
- **POP:** स्टैक के शीर्ष से तत्व हटाना। (खाली होने पर Stack Underflow)।
- **अनुप्रयोग:** ब्राउज़र का Back बटन, C++ में फ़ंक्शन कॉल, एक्सप्रेशन का मूल्यांकन।

### 4. क्यू (Queue - FIFO):
- **FIFO:** First In First Out (जो पहले आएगा, वह पहले सेवा पाएगा)।
- **Front:** जहाँ से तत्व हटाया जाता है (Delete / Dequeue)।
- **Rear:** जहाँ नया तत्व जोड़ा जाता है (Insert / Enqueue)।`,
    technicalTerms: [
      {
        term: 'LIFO (Last In First Out)',
        hindiMeaning: 'अंतिम आया, प्रथम निकला',
        explanation: 'स्टैक डेटा संरचना का मौलिक सिद्धांत।',
      },
      {
        term: 'FIFO (First In First Out)',
        hindiMeaning: 'पहले आया, पहले निकला',
        explanation: 'क्यू डेटा संरचना का मौलिक सिद्धांत।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: शादी में भोजन की प्लेटें (Stack) बनाम टिकट काउंटर (Queue)',
      scenario: 'प्लेटें और कतार:',
      analogy: 'भोजन की प्लेटें एक के ऊपर एक रखी होती हैं; वेटर सबसे ऊपर वाली प्लेट उठाता है जो सबसे बाद में रखी गई थी (LIFO - Stack)। रेलवे स्टेशन पर टिकट काउंटर पर जो पहले खड़ा हुआ, उसे पहले टिकट मिलता है (FIFO - Queue)।',
      takeaway: 'Stack में एक ही सिरा (Top) होता है, Queue में दो सिरे (Front और Rear) होते हैं।',
    },
    importantPoints: [
      'बाइनरी सर्च के लिए डेटा का सॉर्टेड (क्रमबद्ध) होना अनिवार्य है।',
      'Stack में PUSH और POP केवल Top से होता है।',
      'Queue में इन्सर्ट Rear से और डिलीट Front से होता है।',
    ],
    faqs: [
      {
        question: 'स्टैक ओवरफ्लो (Stack Overflow) कब होता है?',
        answer: 'जब स्टैक पहले से ही पूरी तरह भरा हो और हम उसमें एक और नया तत्व PUSH करने का प्रयास करते हैं।',
      },
    ],
    mcqs: [
      {
        id: 'q12-ds-1',
        question: 'स्टैक (Stack) किस सिद्धांत पर कार्य करता है?',
        options: ['FIFO', 'LIFO', 'LILO', 'Random'],
        correctIndex: 1,
        explanationHindi: 'स्टैक LIFO (Last In First Out) सिद्धांत पर कार्य करता है।',
      },
      {
        id: 'q12-ds-2',
        question: 'क्यू (Queue) में नया तत्व किस सिरे पर जोड़ा जाता है?',
        options: ['Front', 'Rear', 'Middle', 'Top'],
        correctIndex: 1,
        explanationHindi: 'Queue में नया तत्व Rear सिरे पर जुड़ता है और Front सिरे से हटाया जाता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'Linear Search और Binary Search में दो मुख्य अंतर बताइए।',
        marks: 2,
        answerHindi: '1. Linear Search असॉर्टेड सूची में भी काम करता है, जबकि Binary Search केवल सॉर्टेड (क्रमबद्ध) सूची में काम करता है। 2. Linear Search धीमा होता है, जबकि Binary Search बहुत तेज होता है क्योंकि यह हर चरण में सूची को आधा कर देता है।',
      },
    ],
    practicalExercise: 'अपनी कॉपी में 5 तत्वों {40, 10, 50, 20, 30} पर Bubble Sort का पहला पास चलाकर दिखाएँ।',
  },

  {
    id: 'c12-unit3-db-sql-advanced',
    classGrade: '12',
    unitId: 'c12-u3',
    unitNumber: 3,
    chapterNumber: '3.1',
    moduleTitle: 'Unit 3: Databases and SQL (8 Marks)',
    title: 'Relational Model, Keys, Relational Algebra, DDL/DML and SQL Functions',
    titleHindi: '3.1 रिलेशनल डेटाबेस, रिलेशनल अलजेब्रा, DDL/DML एवं SQL फ़ंक्शंस',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'रिलेशनल मॉडल: डोमेन, टपल, रिलेशन, प्राइमरी की, अल्टरनेट की, कैंडिडेट की',
      'रिलेशनल अलजेब्रा: Selection, Projection, Union और Cartesian Product',
      'SQL कमांड्स: CREATE TABLE, DROP TABLE, ALTER TABLE, INSERT, UPDATE, DELETE, SELECT',
      'क्लॉजेस एवं फ़ंक्शंस: WHERE, IN, BETWEEN, GROUP BY, HAVING, ORDER BY, SUM, AVG, COUNT, MAX, MIN',
    ],
    introHindi: `यूनिट 3 (8 अंक) में रिलेशनल डेटाबेस की गणितीय नींव (Relational Algebra) और शक्तिशाली SQL प्रश्नों का अध्ययन किया जाता है।`,
    explanationHindi: `### 1. कुंजियाँ (Keys in DBMS):
- **Candidate Key:** वे सभी कॉलम या कॉलम समूह जो टपल को विशिष्ट रूप से पहचान सकते हैं।
- **Primary Key:** कैंडिडेट कीज में से चुनी गई मुख्य विशिष्ट कुंजी (Unique & Not Null)।
- **Alternate Key:** जो कैंडिडेट कीज प्राइमरी की नहीं बन पाईं, वे अल्टरनेट की कहलाती हैं।

### 2. रिलेशनल अलजेब्रा (Relational Algebra):
- **Selection (σ):** पंक्तियों को शर्त के आधार पर छाँटना (SQL में WHERE)।
- **Projection (π):** विशिष्ट कॉलमों का चयन करना (SQL में SELECT Col1, Col2)।
- **Union (∪):** दो तालिकाओं के सभी विशिष्ट रिकॉर्ड्स का विलय।
- **Cartesian Product (×):** दोनों तालिकाओं की प्रत्येक पंक्ति का आपस में गुणन।

### 3. SQL में HAVING बनाम WHERE:
- **WHERE:** व्यक्तिगत पंक्तियों पर शर्त लगाने के लिए प्रयोग होता है।
- **HAVING:** समूह बनाकर (GROUP BY के बाद) समूह पर शर्त लगाने के लिए प्रयुक्त होता है।
\`\`\`sql
-- कक्षा-वार औसत अंक जहाँ औसत 80 से अधिक हो
SELECT Class, AVG(Marks) 
FROM STUDENT 
GROUP BY Class 
HAVING AVG(Marks) > 80;
\`\`\``,
    technicalTerms: [
      {
        term: 'Cartesian Product',
        hindiMeaning: 'कार्तीय गुणन',
        explanation: 'यदि टेबल A में 3 पंक्तियाँ और B में 4 पंक्तियाँ हों, तो कार्तीय गुणन में 3 × 4 = 12 पंक्तियाँ होंगी।',
      },
      {
        term: 'HAVING Clause',
        hindiMeaning: 'समूह-शर्त क्लॉज',
        explanation: 'GROUP BY द्वारा बने समूहों पर शर्त लगाने वाला SQL क्लॉज।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: कक्षा के मॉनिटर का चुनाव (Candidate Keys)',
      scenario: 'कक्षा में 3 छात्र मॉनिटर बनने योग्य हैं:',
      analogy: 'वे तीनों Candidate Keys हैं। शिक्षक ने उनमें से राहुल को मॉनिटर चुन लिया (Primary Key)। बाकी दोनों छात्र अब Alternate Keys बन गए!',
      takeaway: 'हर प्राइमरी की पहले एक कैंडिडेट की होती है।',
    },
    importantPoints: [
      'WHERE क्लॉज aggregate फ़ंक्शंस के साथ काम नहीं करता, वहाँ HAVING का उपयोग होता है।',
      'DROP TABLE पूरी टेबल और उसकी संरचना मिटा देता है, जबकि DELETE केवल पंक्तियाँ हटाता है।',
      'DISTINCT कीवर्ड आउटपुट से डुप्लिकेट मानों को हटा देता है।',
    ],
    faqs: [
      {
        question: 'DELETE और DROP में क्या अंतर है?',
        answer: 'DELETE एक DML कमांड है जो टेबल का डेटा मिटाता है पर टेबल बनी रहती है। DROP एक DDL कमांड है जो डेटा सहित पूरी टेबल को डेटाबेस से नष्ट कर देता है।',
      },
    ],
    mcqs: [
      {
        id: 'q12-sql-adv-1',
        question: 'GROUP BY क्लॉज के साथ समूहों पर शर्त लगाने के लिए किसका उपयोग होता है?',
        options: ['WHERE', 'HAVING', 'ORDER BY', 'CHECK'],
        correctIndex: 1,
        explanationHindi: 'GROUP BY के साथ समूहों पर शर्त लगाने के लिए HAVING क्लॉज का उपयोग किया जाता है।',
      },
      {
        id: 'q12-sql-adv-2',
        question: 'यदि टेबल R1 में 4 पंक्तियाँ और R2 में 3 पंक्तियाँ हों, तो R1 × R2 में कितनी पंक्तियाँ होंगी?',
        options: ['7', '1', '12', '4'],
        correctIndex: 2,
        explanationHindi: 'Cartesian Product में पंक्तियों की संख्या का गुणनफल होता है: 4 × 3 = 12।',
      },
    ],
    shortQuestions: [
      {
        question: 'Primary Key और Candidate Key में संबंध स्पष्ट कीजिए।',
        marks: 2,
        answerHindi: 'तालिका के सभी अद्वितीय कॉलम जो रिकॉर्ड को पहचान सकते हैं, Candidate Keys कहलाते हैं। डेटाबेस डिज़ाइनर इनमें से जिस एक सबसे उपयुक्त कुंजी को मुख्य पहचानकर्ता चुनता है, वह Primary Key कहलाती है।',
      },
    ],
    practicalExercise: 'SQL Lab में जाकर `SELECT DISTINCT Class FROM STUDENT;` क्वेरी चलाकर देखें।',
  },

  {
    id: 'c12-unit4-boolean-algebra',
    classGrade: '12',
    unitId: 'c12-u4',
    unitNumber: 4,
    chapterNumber: '4.1',
    moduleTitle: 'Unit 4: Boolean Algebra (8 Marks)',
    title: 'Boolean Laws, De Morgan Theorems, SOP, POS and Karnaugh Maps (K-Map)',
    titleHindi: '4.1 बूलियन बीजगणित: नियम, डी मॉर्गन प्रमेय, SOP/POS एवं K-Map',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'बूलियन चर, बूलियन स्थिरांक और मौलिक ऑपरेटर (AND, OR, NOT)',
      'बूलियन नियम: क्रमविनिमेय, साहचर्य, वितरण, अवशोषण (Absorption) एवं डी मॉर्गन प्रमेय',
      'सत्य तालिका से SOP (Sum of Product) और POS (Product of Sum) व्यंजक प्राप्त करना',
      'Karnaugh Map (K-Map) द्वारा 4 चरों तक के बूलियन समीकरणों का न्यूनीकरण (Minimization)',
    ],
    introHindi: `यूनिट 4 (8 अंक) गणित और डिजिटल इलेक्ट्रॉनिक्स का अद्भुत संयोजन है। जॉर्ज बूले द्वारा प्रतिपादित बूलियन बीजगणित आधुनिक कंप्यूटर चिप्स के सर्किट डिजाइन का आधार है।`,
    explanationHindi: `### 1. डी मॉर्गन के दो महान प्रमेय (De Morgan's Laws):
1. **पहला प्रमेय:** \`(A + B)' = A' . B'\`
   - योग का पूरक = पूरकों का गुणनफल।
2. **दूसरा प्रमेय:** \`(A . B)' = A' + B'\`
   - गुणन का पूरक = पूरकों का योग।

### 2. SOP बनाम POS रूप:
- **SOP (Sum of Products):** मिंटर्म्स (Minterms) का योग जहाँ परिणाम 1 होता है। (उदा. \`A'B + AB'\`)।
- **POS (Product of Sums):** मैक्सटर्म्स (Maxterms) का गुणनफल जहाँ परिणाम 0 होता है। (उदा. \`(A + B)(A' + B')\`)।

### 3. K-Map (Karnaugh Map) क्या है?
बूलियन व्यंजकों को बीजगणितीय नियमों के बिना चित्रात्मक रूप से न्यूनतम (सुलझाने) करने की ग्रिड विधि:
- 2 चरों के लिए 2² = 4 सेल।
- 3 चरों के लिए 2³ = 8 सेल।
- 4 चरों के लिए 2⁴ = 16 सेल।
- पास-पास के 1 वाले सेलों के पेयर (2 का समूह), क्वाड (4 का समूह) या ऑक्टेट (8 का समूह) बनाकर वेरिएबल्स कम किए जाते हैं।`,
    technicalTerms: [
      {
        term: 'Minterm',
        hindiMeaning: 'लघु पद',
        explanation: 'SOP रूप में सभी चरों का गुणनफल जिसमें चर सामान्य या पूरक रूप में होते हैं।',
      },
      {
        term: 'K-Map',
        hindiMeaning: 'कार्नौ मानचित्र',
        explanation: 'ग्रे कोड पर आधारित ग्रिड आरेख जिससे बूलियन सर्किट को सरल बनाया जाता है।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: डी मॉर्गन का नियम',
      scenario: 'शिक्षक का आदेश:',
      analogy: `"न तो मोबाइल चलेगा और न ही बात होगी" = (मोबाइल + बात)' = (मोबाइल नहीं) AND (बात नहीं)। गणितीय रूप से दोनों कथन बिल्कुल एक समान हैं!`,
      takeaway: 'डी मॉर्गन का नियम जटिल इलेक्ट्रॉनिक सर्किट्स में गेट्स की संख्या कम कर देता है।',
    },
    importantPoints: [
      'K-Map में 1, 2, 4, 8, 16 के समूहों में ही लूप बनते हैं।',
      'NAND और NOR को Universal Gates कहा जाता है क्योंकि इनसे सभी गेट्स बनाए जा सकते हैं।',
      'BSEB परीक्षा में 4 चरों के K-Map को हल करने का 5 अंक का प्रश्न निश्चित रूप से आता है।',
    ],
    faqs: [
      {
        question: 'Principle of Duality (द्वैतता का सिद्धांत) क्या है?',
        answer: 'किसी भी मान्य बूलियन समीकरण में + को . से, . को + से, 0 को 1 से और 1 को 0 से बदलने पर भी समीकरण सत्य रहता है।',
      },
    ],
    mcqs: [
      {
        id: 'q12-ba-1',
        question: 'डी मॉर्गन के अनुसार (A + B)\' किसके बराबर होता है?',
        options: ['A\' + B\'', 'A\' . B\'', 'A . B', 'A + B'],
        correctIndex: 1,
        explanationHindi: 'डी मॉर्गन के पहले नियम के अनुसार (A + B)\' = A\' . B\' होता है।',
      },
      {
        id: 'q12-ba-2',
        question: '3 चरों वाले K-Map में कुल कितने खाने (Cells) होते हैं?',
        options: ['4', '6', '8', '16'],
        correctIndex: 2,
        explanationHindi: 'n चरों के K-Map में 2ⁿ सेल होते हैं, अतः 3 चरों के लिए 2³ = 8 सेल होंगे।',
      },
    ],
    shortQuestions: [
      {
        question: 'यूनिवर्सल गेट्स (Universal Gates) किन्हें कहते हैं और क्यों?',
        marks: 2,
        answerHindi: 'NAND और NOR गेट्स को यूनिवर्सल गेट्स कहा जाता है, क्योंकि केवल इन गेट्स के संयोजन से अन्य सभी बुनियादी गेट्स (AND, OR, NOT) का निर्माण किया जा सकता है।',
      },
    ],
    practicalExercise: 'सत्य तालिका बनाकर सिद्ध करें कि A + A\' = 1 और A . A\' = 0 होता है।',
  },

  {
    id: 'c12-unit5-communication-networks',
    classGrade: '12',
    unitId: 'c12-u5',
    unitNumber: 5,
    chapterNumber: '5.1',
    moduleTitle: 'Unit 5: Communication and Network Concepts (8 Marks)',
    title: 'ARPANET, Media, Topologies, Protocols, Security and Web Technologies',
    titleHindi: '5.1 संचार एवं नेटवर्क अवधारणाएँ: ट्रांसमिशन मीडिया, प्रोटोकॉल्स एवं सुरक्षा',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'नेटवर्किंग का विकास (ARPANET से इंटरनेट) और स्विचिंग तकनीकें (Packet Switching)',
      'ट्रांसमिशन मीडिया: ट्विस्टेड पेयर, कोएक्सियल, ऑप्टिकल फाइबर, माइक्रोवेव और सैटेलाइट',
      'नेटवर्क डिवाइस: मॉडेम, आरजे45, ईथरनेट कार्ड, हब, स्विच, गेटवे और टोपोलॉजी (Bus, Star, Tree)',
      'प्रोटोकॉल्स (TCP/IP, FTP, HTTP, Telnet, VoIP) एवं नेटवर्क सुरक्षा (फ़ायरवॉल, वायरस, साइबर कानून)',
    ],
    introHindi: `यूनिट 5 (8 अंक) हमें पूरे विश्व को जोड़ने वाले इंटरनेट और डेटा संचार की रीढ़ की हड्डी से परिचित कराता है।`,
    explanationHindi: `### 1. नेटवर्किंग का इतिहास:
- **ARPANET (1969):** अमेरिकी रक्षा विभाग द्वारा शुरू किया गया पहला नेटवर्क जिसने इंटरनेट को जन्म दिया।
- **Bandwidth:** प्रति सेकंड डेटा स्थानांतरण की क्षमता (bps, Mbps, Gbps)।

### 2. ट्रांसमिशन मीडिया (Transmission Media):
- **Twisted Pair Cable:** सबसे सस्ती, कम दूरी (स्कूल लैब) के लिए उपयुक्त (RJ45 कनेक्टर)।
- **Coaxial Cable:** केबल टीवी में प्रयुक्त।
- **Optical Fiber:** प्रकाश की गति से डेटा ले जाने वाला सबसे तीव्र और सुरक्षित माध्यम (कांच के पतले रेशे)।
- **Wireless Links:** इन्फ्रारेड, रेडियो तरंगे, माइक्रोवेव और उपग्रह (Satellite)।

### 3. Tree Topology (ट्री टोपोलॉजी):
Star और Bus टोपोलॉजी का पदानुक्रमित (Hierarchical) संयोजन, जिसमें एक मुख्य रूट केबल से विभिन्न स्टार सब-नेटवर्क जुड़े होते हैं।

### 4. महत्वपूर्ण नेटवर्क सुरक्षा अवधारणाएँ:
- **Firewall:** कंप्यूटर नेटवर्क के चारों ओर एक सुरक्षा दीवार जो अनधिकृत बाहरी ट्रैफिक (हैकर्स) को रोकती है।
- **Cookies:** उपयोगकर्ता की प्राथमिकताओं को याद रखने के लिए ब्राउज़र में सहेजी गई छोटी टेक्स्ट फाइलें।
- **Cyber Law (IT Act 2000):** भारत में साइबर अपराधों को रोकने का कानूनी ढांचा।`,
    technicalTerms: [
      {
        term: 'Optical Fiber',
        hindiMeaning: 'प्रकाशीय तंतु केबल',
        explanation: 'पूर्ण आंतरिक परावर्तन (Total Internal Reflection) द्वारा प्रकाश के रूप में डेटा ले जाने वाली अति-तीव्र केबल।',
      },
      {
        term: 'Firewall (फ़ायरवॉल)',
        hindiMeaning: 'डिजिटल सुरक्षा दीवार',
        explanation: 'नेटवर्क में आने और जाने वाले ट्रैफिक की सुरक्षा जांच करने वाला हार्डवेयर या सॉफ्टवेयर।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: समुद्र के नीचे बिछी ऑप्टिकल फाइबर केबल्स',
      scenario: 'अमेरिका से भारत यूट्यूब वीडियो आना:',
      analogy: 'जब आप कैलिफ़ोर्निया के सर्वर से वीडियो देखते हैं, तो डेटा प्रकाश की गति से समुद्र के नीचे बिछी फाइबर केबल्स से होकर मुंबई तट पर आता है और आपके मोबाइल तक पहुँचता है!',
      takeaway: 'ऑप्टिकल फाइबर दुनिया भर के इंटरनेट की जीवन रेखा है।',
    },
    importantPoints: [
      'ARPANET पहला नेटवर्क था जिसने पैकेट स्विचिंग का उपयोग किया।',
      'हब डेटा को सभी नोड्स पर भेजता है (Broadcast), स्विच केवल गंतव्य को भेजता है (Unicast)।',
      'भारत में सूचना प्रौद्योगिकी कानून (IT Act) वर्ष 2000 में लागू हुआ।',
    ],
    faqs: [
      {
        question: 'मॉडेम (Modem) का क्या कार्य है?',
        answer: 'मॉडेम का पूरा नाम Modulator-Demodulator है। यह एनालॉग सिग्नल को डिजिटल में और डिजिटल को एनालॉग में बदलता है।',
      },
    ],
    mcqs: [
      {
        id: 'q12-net-1',
        question: 'प्रकाश के रूप में सबसे तेज गति से डेटा संचारित करने वाला माध्यम कौन सा है?',
        options: ['ट्विस्टेड पेयर केबल', 'कोएक्सियल केबल', 'ऑप्टिकल फाइबर', 'टेलीफोन तार'],
        correctIndex: 2,
        explanationHindi: 'ऑप्टिकल फाइबर केबल प्रकाश के पूर्ण आंतरिक परावर्तन के सिद्धांत पर कार्य करती है और सबसे तेज होती है।',
      },
      {
        id: 'q12-net-2',
        question: 'अनधिकृत नेटवर्क प्रवेश और हैकर्स से सुरक्षा प्रदान करने वाली व्यवस्था को क्या कहते हैं?',
        options: ['Modem', 'Firewall', 'Repeater', 'Cookie'],
        correctIndex: 1,
        explanationHindi: 'Firewall नेटवर्क ट्रैफिक को फिल्टर कर अनधिकृत पहुंच को रोकता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'Hub और Switch में क्या मुख्य अंतर है?',
        marks: 2,
        answerHindi: 'Hub एक गैर-बुद्धिमान उपकरण है जो आने वाले डेटा पैकेट को सभी जुड़े कंप्यूटरों में प्रसारित (Broadcast) कर देता है। Switch एक बुद्धिमान उपकरण है जो डेटा पैकेट को उसके MAC एड्रेस के आधार पर केवल लक्षित गंतव्य कंप्यूटर के पास ही भेजता है।',
      },
    ],
    practicalExercise: 'अपने कंप्यूटर में Windows Firewall सेटिंग्स खोलकर देखें कि यह कैसे इनकमिंग और आउटगोइंग ट्रैफिक को नियंत्रित करती है।',
  },

  // -------------------------------------------------------------------------
  // CLASS 9: ADDITIONAL OFFICIAL SYLLABUS CHAPTERS
  // -------------------------------------------------------------------------
  {
    id: 'c9-unit1-software-os',
    classGrade: '9',
    unitId: 'c9-u1',
    unitNumber: 1,
    chapterNumber: '1.3',
    moduleTitle: 'Unit 1: Components of a Computer System',
    title: 'Software and Operating System (OS Functions, GUI vs CLI)',
    titleHindi: '1.3 सॉफ्टवेयर एवं ऑपरेटिंग सिस्टम: सिस्टम सॉफ्टवेयर, अनुप्रयोग सॉफ्टवेयर व ओएस कार्य',
    isOfficialSyllabus: true,
    estimatedMins: 25,
    learningObjectives: [
      'सिस्टम सॉफ्टवेयर और अनुप्रयोग (Application) सॉफ्टवेयर में अंतर समझना',
      'ऑपरेटिंग सिस्टम (OS) की परिभाषा और संसाधन प्रबंधन (Resource Management) के रूप में भूमिका',
      'ओएस के 4 मुख्य कार्य: प्रोसेस प्रबंधन, मेमोरी प्रबंधन, फाइल प्रबंधन, इनपुट-आउटपुट प्रबंधन',
      'GUI (Graphical User Interface) बनाम CLI (Command Line Interface)',
      'मल्टीटास्किंग और फाइल/फ़ोल्डर संगठन की समझ',
    ],
    introHindi: `नमस्कार विद्यार्थियों! हार्डवेयर केवल लोहे और प्लास्टिक का ढांचा है। इसे चलाने के लिए सॉफ्टवेयर रूपी आत्मा की आवश्यकता होती है। इस अध्याय में हम ऑपरेटिंग सिस्टम के कामकाज को समझेंगे।`,
    explanationHindi: `### 1. सॉफ्टवेयर का वर्गीकरण:
1. **System Software (सिस्टम सॉफ्टवेयर):** वह सॉफ्टवेयर जो कंप्यूटर हार्डवेयर को नियंत्रित और संचालित करता है।
   - *Operating System (OS):* Windows, Linux, Android, iOS आदि।
   - *Device Drivers:* प्रिंटर या वाई-फाई को हार्डवेयर से जोड़ने वाले प्रोग्राम।
2. **Application Software (अनुप्रयोग सॉफ्टवेयर):** जो उपयोगकर्ता की विशिष्ट आवश्यकताओं को पूरा करता है।
   - *General Purpose:* MS Word (दस्तावेज़ लेखन), Google Chrome (वेब ब्राउजिंग)।
   - *Specific Purpose:* स्कूल ईआरपी, बिलिंग सॉफ्टवेयर, रेलवे टिकट आरक्षण प्रणाली।

### 2. ऑपरेटिंग सिस्टम के 4 प्रमुख कार्य:
- **Processor Management (प्रोसेसर प्रबंधन):** कौन सा प्रोग्राम कब और कितनी देर CPU का उपयोग करेगा।
- **Memory Management (मेमोरी प्रबंधन):** RAM में ऐप्स को जगह देना और काम खत्म होने पर खाली करना।
- **File Management (फाइल प्रबंधन):** फाइलों और फ़ोल्डरों को सुरक्षित रूप से सहेजना।
- **Device Management (उपकरण प्रबंधन):** कीबोर्ड, माउस, प्रिंटर के साथ समन्वय।

### 3. GUI बनाम CLI:
| विशेषता | GUI (Graphical User Interface) | CLI (Command Line Interface) |
| :--- | :--- | :--- |
| **इंटरैक्शन** | आइकन, बटन और माउस क्लिक द्वारा | टेक्स्ट कमांड टाइप करके |
| **सीखना** | बहुत आसान (शुरुआती उपयोगकर्ताओं के लिए उत्तम) | कठिन (कमांड याद रखने पड़ते हैं) |
| **उदाहरण** | Windows 11, macOS, Android | MS-DOS, Linux Terminal |`,
    technicalTerms: [
      {
        term: 'Operating System (OS)',
        hindiMeaning: 'प्रचालन तंत्र',
        explanation: 'हार्डवेयर और उपयोगकर्ता के बीच मध्यस्थ (Interface) का कार्य करने वाला मुख्य सिस्टम सॉफ्टवेयर।',
      },
      {
        term: 'Multitasking',
        hindiMeaning: 'बहु-कार्यण',
        explanation: 'एक ही समय में कंप्यूटर पर एक से अधिक एप्लिकेशन (जैसे गाने सुनना और टाइपिंग करना) चलाना।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: विद्यालय का प्रधानाध्यापक (Principal)',
      scenario: 'जिस प्रकार विद्यालय में:',
      analogy: 'प्रधानाध्यापक सभी कक्षाओं, शिक्षकों, घंटी और कमरों का प्रबंधन करते हैं ताकि कोई अव्यवस्था न हो, ठीक उसी प्रकार ऑपरेटिंग सिस्टम CPU, RAM, हार्ड डिस्क और सभी ऐप्स का प्रबंधन करता है।',
      takeaway: 'ऑपरेटिंग सिस्टम कंप्यूटर का प्रबंधक (Resource Manager) है।',
    },
    importantPoints: [
      'ऑपरेटिंग सिस्टम के बिना कोई भी कंप्यूटर चालू (Boot) नहीं हो सकता।',
      'GUI में काम करना माउस क्लिक से आसान होता है, जबकि CLI में कमांड टाइप करना होता है।',
      'Windows और Android सबसे लोकप्रिय GUI ऑपरेटिंग सिस्टम हैं।',
    ],
    faqs: [
      {
        question: 'क्या एंड्रॉइड (Android) भी एक ऑपरेटिंग सिस्टम है?',
        answer: 'हाँ, एंड्रॉइड स्मार्टफोन और टैबलेट के लिए गूगल द्वारा विकसित दुनिया का सबसे लोकप्रिय मोबाइल ऑपरेटिंग सिस्टम है।',
      },
    ],
    mcqs: [
      {
        id: 'q9-os-1',
        question: 'निम्नलिखित में से कौन सा सिस्टम सॉफ्टवेयर का उदाहरण है?',
        options: ['MS Word', 'Operating System', 'Photoshop', 'VLC Player'],
        correctIndex: 1,
        explanationHindi: 'ऑपरेटिंग सिस्टम हार्डवेयर को नियंत्रित करने वाला मुख्य सिस्टम सॉफ्टवेयर है।',
      },
      {
        id: 'q9-os-2',
        question: 'GUI का पूर्ण रूप क्या होता है?',
        options: ['General User Interface', 'Graphical User Interface', 'Global Unique Identifier', 'Graphic Utility Integration'],
        correctIndex: 1,
        explanationHindi: 'GUI का पूर्ण रूप Graphical User Interface होता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'सिस्टम सॉफ्टवेयर और एप्लीकेशन सॉफ्टवेयर में दो मुख्य अंतर बताइए।',
        marks: 2,
        answerHindi: '1. सिस्टम सॉफ्टवेयर कंप्यूटर के हार्डवेयर को चलाता है (उदा. Windows), जबकि एप्लीकेशन सॉफ्टवेयर उपयोगकर्ता के विशेष कार्य करता है (उदा. MS Excel)। 2. सिस्टम सॉफ्टवेयर के बिना कंप्यूटर काम नहीं कर सकता, जबकि एप्लीकेशन सॉफ्टवेयर वैकल्पिक होते हैं।',
      },
    ],
    practicalExercise: 'अपने कंप्यूटर पर फाइल एक्सप्लोरर खोलें और नया फोल्डर बनाकर उसके अंदर दो अलग-अलग फाइलें सेव करके देखें।',
  },
  {
    id: 'c9-unit2-control-structures',
    classGrade: '9',
    unitId: 'c9-u2',
    unitNumber: 2,
    chapterNumber: '2.2',
    moduleTitle: 'Unit 2: Foundations of Computational Thinking',
    title: 'Basic Control Structures (Sequence, Selection IF-ELSE, Iteration Loops)',
    titleHindi: '2.2 बुनियादी नियंत्रण संरचनाएं: अनुक्रम, चयन (IF-ELSE) एवं पुनरावृत्ति (Loops)',
    isOfficialSyllabus: true,
    estimatedMins: 25,
    learningObjectives: [
      'प्रोग्राम प्रवाह की तीन बुनियादी नियंत्रण संरचनाओं की समझ',
      'Sequence (अनुक्रम): एक के बाद एक निर्देशों का क्रमिक निष्पादन',
      'Selection (चयन): शर्त के आधार पर निर्णय लेना (IF-THEN-ELSE)',
      'Iteration (पुनरावृत्ति / Loops): निश्चित या शर्त आधारित पुनरावृत्ति',
      'नेस्टेड लॉजिक (Nested Logic) का परिचय',
    ],
    introHindi: `कंप्यूटर बुद्धिमान नहीं होता, लेकिन वह हमारे दिए गए तार्किक नियमों का बहुत तेजी से पालन करता है। किसी भी एल्गोरिदम में नियंत्रण का प्रवाह (Control Flow) कैसे होता है, यह इस अध्याय में समझेंगे।`,
    explanationHindi: `### 1. अनुक्रम (Sequence):
निर्देश उसी क्रम में निष्पादित होते हैं जिस क्रम में लिखे गए हैं (ऊपर से नीचे)।
- *उदाहरण:* आयत का क्षेत्रफल निकालना -> 1. लंबाई लो, 2. चौड़ाई लो, 3. Area = L * B करो, 4. Area प्रिंट करो।

### 2. चयन (Selection / Decision Making):
शर्त जाँचना। यदि शर्त सत्य (True) हो तो एक मार्ग, असत्य (False) हो तो दूसरा मार्ग।
\`\`\`text
IF marks >= 30 THEN
   PRINT "पास (Pass)"
ELSE
   PRINT "फेल (Fail)"
ENDIF
\`\`\`

### 3. पुनरावृत्ति (Iteration / Loops):
जब किसी कार्य को बार-बार दोहराना हो:
- **निश्चित पुनरावृत्ति (Fixed Repetition):** 1 से 10 तक गिनती लिखना (10 बार चलेगा)।
- **शर्त-आधारित पुनरावृत्ति (Condition-based):** जब तक सही पासवर्ड न डाला जाए, तब तक पूछते रहो।`,
    technicalTerms: [
      {
        term: 'Selection (चयन)',
        hindiMeaning: 'शर्त के आधार पर निर्णय',
        explanation: 'IF-ELSE द्वारा शर्त की सत्यता के आधार पर निष्पादन मार्ग चुनना।',
      },
      {
        term: 'Loop (लूप)',
        hindiMeaning: 'पुनरावृत्ति चक्र',
        explanation: 'शर्त पूरी होने तक निर्देशों के समूह को बार-बार निष्पादित करने की संरचना।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: ट्रैफिक लाइट (Traffic Light)',
      scenario: 'सड़क पर सिग्नल का नियम:',
      analogy: 'IF लाइट लाल (Red) है -> रुकें (Stop); ELSE IF पीली है -> तैयार हों; ELSE (हरी) -> आगे बढ़ें। यह चयन (Selection) का जीवंत उदाहरण है।',
      takeaway: 'हमारे हर दिन के निर्णय नियंत्रण संरचनाओं के अनुसार ही होते हैं।',
    },
    importantPoints: [
      'Sequence में कोई भी कदम छोड़ा नहीं जाता।',
      'IF-ELSE में हमेशा एक समय पर केवल एक ही ब्लॉक निष्पादित होता है।',
      'लूप का उपयोग समय और कोड की पंक्तियों को बचाने के लिए किया जाता है।',
    ],
    faqs: [
      {
        question: 'इनफिनिट लूप (Infinite Loop) क्या होता है?',
        answer: 'जब लूप की समाप्ति शर्त कभी पूरी नहीं होती और वह अनंत काल तक चलता रहता है, तो उसे इनफिनिट लूप कहते हैं।',
      },
    ],
    mcqs: [
      {
        id: 'q9-cs-struct-1',
        question: 'दो विकल्पों में से एक चुनने के लिए किस नियंत्रण संरचना का प्रयोग किया जाता है?',
        options: ['Sequence', 'Selection (IF-ELSE)', 'Array', 'Constant'],
        correctIndex: 1,
        explanationHindi: 'चयन (Selection / IF-ELSE) का उपयोग शर्त के आधार पर दो या अधिक विकल्पों में से निर्णय लेने के लिए होता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'कंप्यूटर साइंस में लूप्स (Loops) की क्या आवश्यकता है?',
        marks: 2,
        answerHindi: 'लूप्स दोहराए जाने वाले कार्यों को स्वचालित करते हैं। उदाहरण के लिए, 100 छात्रों के अंक प्रिंट करने के लिए 100 बार कोड लिखने के बजाय 1 लूप में 100 बार निष्पादित किया जा सकता है।',
      },
    ],
    practicalExercise: 'कागज पर एक फ्लोचार्ट बनाएं जो उपयोगकर्ता से उम्र (Age) पूछे और यदि Age >= 18 हो तो "मतदान के पात्र" प्रिंट करे।',
  },

  // -------------------------------------------------------------------------
  // CLASS 10: ADDITIONAL OFFICIAL SYLLABUS CHAPTERS
  // -------------------------------------------------------------------------
  {
    id: 'c10-unit1-logic-gates',
    classGrade: '10',
    unitId: 'c10-u1',
    unitNumber: 1,
    chapterNumber: '1.2',
    moduleTitle: 'Unit 1: Number Systems, Data Encoding & Logic Gates',
    title: 'Boolean Logic, Basic Logic Gates (AND, OR, NOT) & Truth Tables',
    titleHindi: '1.2 बूलियन लॉजिक, बेसिक लॉजिक गेट्स (AND, OR, NOT) एवं सत्य तालिकाएं',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'बूलियन बीजगणित में True (1) और False (0) की मूल अवधारणा',
      'बेसिक लॉजिक गेट्स: AND, OR, NOT का कार्य और प्रतीक',
      'दो-चर सत्य तालिकाएं (2-variable Truth Tables) बनाना',
      'दैनिक जीवन की उपमाएं और डिजिटल परिपथ (Digital Circuits) में अनुप्रयोग',
    ],
    introHindi: `प्रिय विद्यार्थियों! कंप्यूटर के अंदर लाखों छोटे-छोटे इलेक्ट्रॉनिक स्विच (ट्रांजिस्टर) होते हैं। ये स्विच 0 (Off) और 1 (On) पर कार्य करते हैं। लॉजिक गेट्स इन डिजिटल सिग्नलों पर तार्किक निर्णय लेते हैं।`,
    explanationHindi: `### 1. बेसिक लॉजिक गेट्स (Basic Logic Gates):
1. **AND गेट (तार्किक गुणन - .):**
   - *नियम:* आउटपुट केवल तभी 1 होता है जब **दोनों इनपुट 1** हों।
   - *सत्य तालिका:* 0.0=0, 0.1=0, 1.0=0, 1.1=1
2. **OR गेट (तार्किक योग - +):**
   - *नियम:* आउटपुट 1 होता है यदि **कम से कम एक इनपुट 1** हो।
   - *सत्य तालिका:* 0+0=0, 0+1=1, 1+0=1, 1+1=1
3. **NOT गेट (इनवर्टर - '):**
   - *नियम:* यह इनपुट को उलट देता है। 0 को 1 और 1 को 0 बनाता है।
   - *सत्य तालिका:* 0' = 1, 1' = 0

### 2. सत्य तालिका (Truth Table):
| इनपुट A | इनपुट B | A AND B (A.B) | A OR B (A+B) | NOT A (A') |
| :---: | :---: | :---: | :---: | :---: |
| 0 | 0 | 0 | 0 | 1 |
| 0 | 1 | 0 | 1 | 1 |
| 1 | 0 | 0 | 1 | 0 |
| 1 | 1 | 1 | 1 | 0 |`,
    technicalTerms: [
      {
        term: 'Logic Gate',
        hindiMeaning: 'तार्किक द्वार / गेट',
        explanation: 'एक या अधिक बाइनरी इनपुट लेकर एक बाइनरी आउटपुट देने वाला बुनियादी इलेक्ट्रॉनिक परिपथ।',
      },
      {
        term: 'Truth Table',
        hindiMeaning: 'सत्य तालिका',
        explanation: 'इनपुट के सभी संभावित संयोजनों और उनके संबंधित आउटपुट को दर्शाने वाली सारणी।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: परीक्षा हॉल में प्रवेश और फीस भुगतान',
      scenario: 'वास्तविक दुनिया के नियम:',
      analogy: 'AND गेट: "परीक्षा देने के लिए एडमिट कार्ड AND पेन दोनों चाहिए।" (एक भी नहीं तो परीक्षा नहीं)। OR गेट: "दुकानदार को नकद OR ऑनलाइन पेमेंट में से कोई भी एक दे सकते हैं।" NOT गेट: "स्विच उल्टा कर देना।"',
      takeaway: 'डिजिटल कंप्यूटर का पूरा मस्तिष्क इन तीन प्राथमिक गेटों के संयोजन से बनता है।',
    },
    importantPoints: [
      'NOT गेट में केवल एक ही इनपुट और एक ही आउटपुट होता है।',
      'AND गेट को "श्रृंखला (Series)" स्विच की तरह देखा जा सकता है।',
      'OR गेट को "समानांतर (Parallel)" स्विच की तरह देखा जा सकता है।',
    ],
    faqs: [
      {
        question: 'क्या 3 इनपुट वाला AND गेट भी हो सकता है?',
        answer: 'हाँ, 3 इनपुट AND गेट में आउटपुट 1 तभी होगा जब तीनों इनपुट A=1, B=1, और C=1 हों।',
      },
    ],
    mcqs: [
      {
        id: 'q10-gates-1',
        question: 'यदि AND गेट के इनपुट 1 और 0 हों, तो आउटपुट क्या होगा?',
        options: ['1', '0', 'अनिश्चित', '-1'],
        correctIndex: 1,
        explanationHindi: 'AND गेट में आउटपुट 1 केवल तभी होता है जब दोनों इनपुट 1 हों। 1 AND 0 = 0।',
      },
      {
        id: 'q10-gates-2',
        question: 'इनपुट को उल्टा करने वाला (Inverter) कौन सा गेट कहलाता है?',
        options: ['OR Gate', 'AND Gate', 'NOT Gate', 'NAND Gate'],
        correctIndex: 2,
        explanationHindi: 'NOT गेट 0 को 1 और 1 को 0 में बदल देता है, इसलिए इसे इनवर्टर भी कहते हैं।',
      },
    ],
    shortQuestions: [
      {
        question: 'OR गेट की परिभाषा दीजिए और 2 इनपुट वाली सत्य तालिका बनाइए।',
        marks: 2,
        answerHindi: 'OR गेट वह लॉजिक गेट है जिसका आउटपुट 1 होता है यदि कम से कम कोई एक इनपुट 1 हो। सत्य तालिका: (0,0)=0; (0,1)=1; (1,0)=1; (1,1)=1।',
      },
    ],
    practicalExercise: 'कागज पर दो बल्ब और दो स्विच की सर्किट बनाकर AND और OR गेट का व्यवहार सिद्ध कीजिए।',
  },
  {
    id: 'c10-unit4-html-webpages',
    classGrade: '10',
    unitId: 'c10-u4',
    unitNumber: 4,
    chapterNumber: '4.2',
    moduleTitle: 'Unit 4: Fundamentals of Computer Networks & Web',
    title: 'HTML Basics, Tags (Headings, Paragraphs, Links, Lists) & Web Designing',
    titleHindi: '4.2 HTML वेबपेज निर्माण: मूल टैग्स, हेडिंग्स, पैराग्राफ, हाइपरलिंक एवं सूचियाँ',
    isOfficialSyllabus: true,
    estimatedMins: 30,
    learningObjectives: [
      'HTML (HyperText Markup Language) का परिचय और वेब डिजाइन में उद्देश्य',
      'HTML दस्तावेज़ की बुनियादी संरचना: <html>, <head>, <title>, <body>',
      'सामग्री स्वरूपण टैग्स: हेडिंग्स <h1> से <h6>, पैराग्राफ <p>, लाइन ब्रेक <br>',
      'हाइपरलिंक बनाना: एंकर टैग <a> और href एट्रिब्यूट',
      'सूचियाँ (Lists): क्रमित सूची <ol> और अक्रमित सूची <ul>',
      'नोटपैड में HTML फाइल बनाना और वेब ब्राउज़र में चलाकर देखना',
    ],
    introHindi: `नमस्कार विद्यार्थियों! आज हम इंटरनेट पर दिखने वाले वेबपेजों को बनाना सीखेंगे। दुनिया की हर वेबसाइट HTML की नींव पर खड़ी होती है। आइए, अपना पहला वेबपेज बनाते हैं!`,
    explanationHindi: `### 1. HTML दस्तावेज़ का बुनियादी ढांचा:
\`\`\`html
<!DOCTYPE html>
<html>
  <head>
    <title>मेरा पहला वेबपेज</title>
  </head>
  <body>
    <h1>नमस्ते बिहार! Welcome to BSEBwala.in</h1>
    <p>यह मेरा कंप्यूटर साइंस का पहला HTML वेबपेज है।</p>
  </body>
</html>
\`\`\`

### 2. आवश्यक HTML टैग्स:
- **<h1> से <h6>:** हेडिंग टैग्स। <h1> सबसे बड़ा और <h6> सबसे छोटा शीर्षक होता है।
- **<p>:</p>** पैराग्राफ लिखने के लिए।
- **<br>:** लाइन ब्रेक (अगली लाइन में जाने के लिए - यह Empty tag है)।
- **<a href="URL">टेक्स्ट</a>:** दूसरे वेबपेज से जोड़ने वाला हाइपरलिंक।
- **<ul> और <li>:** बुलेट वाली अक्रमित सूची (Unordered List)।
- **<ol> और <li>:** 1, 2, 3 वाली क्रमित सूची (Ordered List)।`,
    technicalTerms: [
      {
        term: 'HTML',
        hindiMeaning: 'हाइपरटेक्स्ट मार्कअप लैंग्वेज',
        explanation: 'वेबपेज की संरचना तैयार करने वाली मानक मार्कअप भाषा।',
      },
      {
        term: 'Hyperlink (हाइपरलिंक)',
        hindiMeaning: 'वेबपेज जोड़ने वाली कड़ी',
        explanation: 'क्लिक करने योग्य टेक्स्ट या इमेज जो उपयोगकर्ता को दूसरे वेबपेज या रिसोर्स पर ले जाती है।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: पुस्तक की अनुक्रमणिका (Index & Chapters)',
      scenario: 'जैसे किसी किताब में:',
      analogy: 'किताब का नाम = <title>; मुख्य पाठ का शीर्षक = <h1>; पाठ के अनुच्छेद = <p>; और "पेज नंबर 25 पर जाएं" = <a href="..."> हाइपरलिंक।',
      takeaway: 'HTML दस्तावेज़ को ठीक उसी तरह सजाता है जैसे छपी हुई पुस्तक को संवारा जाता है।',
    },
    practicalDemo: {
      title: 'एक सरल HTML वेबपेज कोड',
      language: 'html',
      code: `<!DOCTYPE html>
<html>
<head>
  <title>BSEB Class 10 CS</title>
</head>
<body>
  <h1>कक्षा 10 - कंप्यूटर साइंस</h1>
  <p>सीखिए अपनी भाषा में!</p>
  <h3>मेरी पसंदीदा भाषाएं:</h3>
  <ul>
    <li>C++ प्रोग्रामिंग</li>
    <li>HTML वेब डिजाइन</li>
    <li>SQL डेटाबेस</li>
  </ul>
</body>
</html>`,
      explanation: 'यह कोड ब्राउज़र में शीर्ष हेडिंग, पैराग्राफ और बुलेटेड लिस्ट प्रदर्शित करता है।',
    },
    importantPoints: [
      'HTML एक प्रोग्रामिंग भाषा नहीं है, बल्कि एक मार्कअप भाषा (Markup Language) है।',
      'HTML फाइल को हमेशा .html या .htm एक्सटेंशन के साथ सहेजा जाता है।',
      '<br> और <img> जैसे टैग्स को बंद (Close) करने की आवश्यकता नहीं होती (Empty Tags)।',
    ],
    faqs: [
      {
        question: 'HTML कोड चलाने के लिए किस सॉफ्टवेयर की आवश्यकता होती है?',
        answer: 'कोड लिखने के लिए नोटपैड (Notepad) और उसे देखने के लिए किसी भी वेब ब्राउज़र (जैसे Chrome या Edge) की आवश्यकता होती है।',
      },
    ],
    mcqs: [
      {
        id: 'q10-html-1',
        question: 'HTML में सबसे बड़ा हेडिंग टैग कौन सा होता है?',
        options: ['<h6>', '<h1>', '<head>', '<header>'],
        correctIndex: 1,
        explanationHindi: '<h1> सबसे मुख्य और सबसे बड़ा हेडिंग टैग होता है।',
      },
      {
        id: 'q10-html-2',
        question: 'वेबपेज में हाइपरलिंक बनाने के लिए किस टैग का उपयोग होता है?',
        options: ['<link>', '<href>', '<a>', '<url>'],
        correctIndex: 2,
        explanationHindi: 'एंकर टैग <a> (Anchor tag) का उपयोग href एट्रिब्यूट के साथ हाइपरलिंक बनाने के लिए होता है।',
      },
    ],
    shortQuestions: [
      {
        question: '<ol> और <ul> टैग में क्या अंतर है?',
        marks: 2,
        answerHindi: '<ol> (Ordered List) में सूची के आइटम 1, 2, 3 या A, B, C क्रम में आते हैं, जबकि <ul> (Unordered List) में आइटम बुलेट (•) चिह्नों के साथ प्रदर्शित होते हैं।',
      },
    ],
    practicalExercise: 'नोटपैड में अपने परिचय (नाम, कक्षा, स्कूल) का एक छोटा HTML वेबपेज बनाएं और उसे क्रोम ब्राउज़र में खोलकर देखें।',
  },

  // -------------------------------------------------------------------------
  // CLASS 11: ADDITIONAL OFFICIAL SYLLABUS CHAPTERS
  // -------------------------------------------------------------------------
  {
    id: 'c11-unit3-arrays-functions',
    classGrade: '11',
    unitId: 'c11-u3',
    unitNumber: 3,
    chapterNumber: '3.2',
    moduleTitle: 'UNIT-3: Introduction to Programming in C++ (44 Marks)',
    title: '1D & 2D Arrays, String Manipulation and User Defined Functions',
    titleHindi: '3.2 C++ एरे, स्ट्रिंग मैनिपुलेशन एवं यूज़र डिफाइंड फंक्शन्स',
    isOfficialSyllabus: true,
    estimatedMins: 35,
    learningObjectives: [
      'One-Dimensional (1D) एरे की घोषणा, इनपुट, लीनियर सर्च और अधिकतम/न्यूनतम मान खोजना',
      'स्ट्रिंग मैनिपुलेशन और string.h फ़ंक्शंस (strlen, strcpy, strcat, strcmp)',
      'ctype.h फ़ंक्शंस (isalnum, isalpha, isdigit, toupper, tolower)',
      'Two-Dimensional (2D) एरे: मैट्रिक्स इनपुट, पंक्तियों/स्तंभों का योग, विकर्ण (Diagonals)',
      'यूज़र डिफाइंड फ़ंक्शंस: प्रोटोटाइप, कॉल बाई वैल्यू (Call by Value) बनाम कॉल बाई रेफरेंस (Call by Reference)',
      'वेरिएबल का स्कोप: Local बनाम Global Variables',
    ],
    introHindi: `प्रिय विद्यार्थियों! जब हमें एक ही प्रकार के 50 या 100 मान (जैसे 50 छात्रों के अंक) सुरक्षित रखने हों, तो 50 अलग-अलग चर बनाने के बजाय हम 'एरे (Array)' का उपयोग करते हैं।`,
    explanationHindi: `### 1. 1-Dimensional Array:
\`\`\`cpp
int marks[5] = {85, 92, 78, 90, 88};
// marks[0] = 85, marks[4] = 88
\`\`\`
एरे में इंडेक्स हमेशा **0 से शुरू** होता है और **(Size - 1)** पर समाप्त होता है।

### 2. string.h और ctype.h लाइब्रेरी फ़ंक्शंस:
- **strlen(str):** स्ट्रिंग में वर्णों की संख्या गिनता है।
- **strcpy(dest, src):** एक स्ट्रिंग को दूसरी में कॉपी करता है।
- **strcat(s1, s2):** दोनों स्ट्रिंग्स को आपस में जोड़ता है।
- **strcmp(s1, s2):** दो स्ट्रिंग्स की तुलना करता है (समान होने पर 0 देता है)।
- **isdigit(ch):** यदि वर्ण 0-9 है तो सत्य देता है।
- **toupper(ch):** छोटे अक्षर को बड़े (Capital) में बदलता है।

### 3. Call by Value बनाम Call by Reference:
| विशेषता | Call by Value | Call by Reference |
| :--- | :--- | :--- |
| **सिंटैक्स** | \`void swap(int a, int b)\` | \`void swap(int &a, int &b)\` |
| **प्रभाव** | फ़ंक्शन में किए गए परिवर्तन मुख्य चर में नहीं दिखते। | फ़ंक्शन में किए गए परिवर्तन मुख्य चर में प्रतिबिंबित होते हैं। |
| **मेमोरी** | चरों की प्रतिलिपि (Copy) बनती है। | मूल मेमोरी पते का संदर्भ प्रयुक्त होता है। |`,
    technicalTerms: [
      {
        term: 'Array (एरे)',
        hindiMeaning: 'सजातीय डेटा का समूह',
        explanation: 'समान डेटा प्रकार के मानों का एक सन्निहित (Contiguous) मेमोरी संग्रह।',
      },
      {
        term: 'Call by Reference',
        hindiMeaning: 'संदर्भ द्वारा कॉल',
        explanation: 'फ़ंक्शन में मान के स्थान पर मूल चर का मेमोरी पता (&) पास करना।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: डाकघर का लेटर बॉक्स कैबिनेट',
      scenario: 'जैसे डाकघर में:',
      analogy: 'एक बड़ी अलमारी में 50 दराजें हैं, जिन पर 0, 1, 2... 49 लिखा है। पूरी अलमारी = Array; प्रत्येक दराज = Element; और दराज का नंबर = Index।',
      takeaway: 'इंडेक्स नंबर के माध्यम से हम किसी भी दराज से तुरंत डेटा निकाल सकते हैं।',
    },
    practicalDemo: {
      title: 'एरे में लीनियर सर्च (Linear Search in C++)',
      language: 'cpp',
      code: `#include <iostream.h>
int main() {
    int arr[5] = {10, 25, 40, 55, 70};
    int key = 40, found = 0;
    for(int i = 0; i < 5; i++) {
        if(arr[i] == key) {
            cout << "तत्व इंडेक्स " << i << " पर मिला!" << endl;
            found = 1;
            break;
        }
    }
    if(!found) cout << "तत्व नहीं मिला!";
    return 0;
}`,
      explanation: 'यह कोड एरे के प्रत्येक तत्व की तुलना सर्च की जाने वाली संख्या से करता है।',
    },
    importantPoints: [
      'C++ में एरे इंडेक्स हमेशा 0 से प्रारंभ होता है।',
      'स्ट्रिंग के अंत में हमेशा नल कैरेक्टर ("\\0") जुड़ा होता है।',
      '2D एरे का उपयोग गणितीय मैट्रिक्स (Rows और Columns) के लिए किया जाता है।',
    ],
    faqs: [
      {
        question: 'एरे और वेरिएबल में मुख्य अंतर क्या है?',
        answer: 'एक साधारण चर में एक समय पर केवल एक मान रखा जा सकता है, जबकि एरे में एक ही नाम के अंतर्गत कई मान रखे जा सकते हैं।',
      },
    ],
    mcqs: [
      {
        id: 'q11-arr-1',
        question: 'यदि int a[10] घोषित किया जाए, तो पहले और अंतिम तत्व का इंडेक्स क्या होगा?',
        options: ['1 और 10', '0 और 9', '0 और 10', '1 और 9'],
        correctIndex: 1,
        explanationHindi: 'C++ में 10 तत्वों वाले एरे का पहला इंडेक्स 0 और अंतिम इंडेक्स 10 - 1 = 9 होता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'Call by Value और Call by Reference में अंतर स्पष्ट करें।',
        marks: 2,
        answerHindi: 'Call by Value में फ़ंक्शन को वास्तविक मान की प्रतिलिपि (Copy) मिलती है जिससे मूल चर नहीं बदलता। Call by Reference में चर का पता (&) भेजा जाता है, अतः फ़ंक्शन में हुआ परिवर्तन मूल चर को भी बदल देता है।',
      },
    ],
    practicalExercise: 'C++ में 5 संख्याओं का इनपुट लेकर उनमें से सबसे बड़ी संख्या (Maximum) ज्ञात करने का प्रोग्राम लिखें।',
  },

  // -------------------------------------------------------------------------
  // CLASS 12: ADDITIONAL OFFICIAL SYLLABUS CHAPTERS
  // -------------------------------------------------------------------------
  {
    id: 'c12-unit1-constructors-inheritance',
    classGrade: '12',
    unitId: 'c12-u1',
    unitNumber: 1,
    chapterNumber: '1.2',
    moduleTitle: 'UNIT-1: Programming in C++ (30 Marks)',
    title: 'Constructors, Destructors and Inheritance in C++',
    titleHindi: '1.2 कंस्ट्रक्टर, डिस्ट्रक्टर एवं इनहेरिटेंस (वर्ग विस्तार)',
    isOfficialSyllabus: true,
    estimatedMins: 35,
    learningObjectives: [
      'कंस्ट्रक्टर की विशेषताएं: नाम क्लास जैसा, कोई रिटर्न टाइप नहीं, ऑब्जेक्ट निर्माण पर स्वतः कॉल',
      'कंस्ट्रक्टर के प्रकार: Default, Parameterized, Overloaded, Copy Constructor',
      'डिस्ट्रक्टर (Destructor ~) की कार्यप्रणाली और मेमोरी मुक्ति',
      'इनहेरिटेंस की अवधारणा: बेस क्लास (Base Class) और डिराइव्ड क्लास (Derived Class)',
      'विजिबिलिटी मोड्स: Public, Private, Protected डेरिवेटिव्स',
      'इनहेरिटेंस के रूप: Single, Multilevel, Multiple Inheritance',
    ],
    introHindi: `कक्षा 12वीं के होनहार विद्यार्थियों! बोर्ड परीक्षा में यूनिट-1 से सबसे अधिक 30 अंक के प्रश्न पूछे जाते हैं। कंस्ट्रक्टर, डिस्ट्रक्टर और इनहेरिटेंस इस यूनिट के सबसे महत्वपूर्ण और स्कोरिंग विषय हैं।`,
    explanationHindi: `### 1. कंस्ट्रक्टर (Constructor):
यह क्लास का एक विशेष सदस्य फ़ंक्शन (Member Function) होता है जिसका नाम क्लास के नाम के समान होता है।
- **स्वतः निष्पादन:** जैसे ही क्लास का ऑब्जेक्ट बनता है, यह स्वतः चल पड़ता है।
- **कोई रिटर्न टाइप नहीं:** इसका कोई रिटर्न टाइप (यहाँ तक कि void भी) नहीं होता।
- **प्रकार:**
  1. *Default Constructor:* कोई तर्क (Argument) नहीं लेता।
  2. *Parameterized Constructor:* ऑब्जेक्ट बनाते समय मान लेता है (उदा. \`Student s1(101, "राहुल");\`)।
  3. *Copy Constructor:* एक ऑब्जेक्ट के मानों को दूसरे नए ऑब्जेक्ट में कॉपी करता है (उदा. \`Student s2(s1);\`)।

### 2. डिस्ट्रक्टर (Destructor):
- नाम के आगे टिल्ड चिह्न (\`~\`) लगाया जाता है (उदा. \`~Student()\`)।
- जब ऑब्जेक्ट का स्कोप समाप्त होता है, तो यह मेमोरी को खाली करने के लिए स्वतः चलता है।

### 3. इनहेरिटेंस के प्रकार:
1. **Single Inheritance:** एक बेस क्लास से एक डिराइव्ड क्लास (A -> B)।
2. **Multilevel Inheritance:** पीढ़ी-दर-पीढ़ी विस्तार (दादाजी A -> पिताजी B -> पुत्र C)।
3. **Multiple Inheritance:** एक से अधिक बेस क्लास से एक डिराइव्ड क्लास (माता A + पिता B -> संतान C)।`,
    technicalTerms: [
      {
        term: 'Constructor',
        hindiMeaning: 'निर्माता / आरंभीकरण फ़ंक्शन',
        explanation: 'ऑब्जेक्ट बनते ही उसके डेटा मेंबर्स को प्रारंभिक मान देने वाला विशेष क्लास फ़ंक्शन।',
      },
      {
        term: 'Inheritance',
        hindiMeaning: 'विरासती गुण ग्रहण / वर्ग विस्तार',
        explanation: 'पुरानी क्लास (Base) के गुणों और विधियों को नई क्लास (Derived) में पुनः उपयोग करने की क्षमता।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: माता-पिता से संतान में गुणों का आना (Inheritance)',
      scenario: 'जैसे परिवार में:',
      analogy: 'माता-पिता (Base Class) के गुण (जैसे आंख का रंग, स्वभाव) संतान (Derived Class) को स्वतः मिल जाते हैं। साथ ही संतान के पास अपने कुछ नए गुण भी होते हैं। यही इनहेरिटेंस (Reusability) है!',
      takeaway: 'इनहेरिटेंस से कोड को बार-बार लिखने की मेहनत बचती है।',
    },
    practicalDemo: {
      title: 'C++ में कंस्ट्रक्टर और इनहेरिटेंस का उदाहरण',
      language: 'cpp',
      code: `#include <iostream.h>
class Person {
protected:
    char name[20];
public:
    Person() { cout << "Person निर्मित हुआ!" << endl; }
};

class Student : public Person {
    int roll;
public:
    Student(int r) { roll = r; cout << "Student रोल " << roll << " तैयार!" << endl; }
    ~Student() { cout << "Student नष्ट हुआ!" << endl; }
};

int main() {
    Student s(105);
    return 0;
}`,
      explanation: 'जब Student का ऑब्जेक्ट बनता है, तो पहले Person का कंस्ट्रक्टर चलता है, फिर Student का।',
    },
    importantPoints: [
      'डिस्ट्रक्टर न तो कोई तर्क ले सकता है और न ही इसे ओवरलोड किया जा सकता है।',
      'Protected सदस्य डिराइव्ड क्लास में एक्सेस किए जा सकते हैं, लेकिन क्लास के बाहर नहीं।',
      'इनहेरिटेंस का मुख्य लाभ कोड का पुनः उपयोग (Code Reusability) है।',
    ],
    faqs: [
      {
        question: 'क्या एक क्लास में एक से अधिक कंस्ट्रक्टर हो सकते हैं?',
        answer: 'हाँ! इसे "कंस्ट्रक्टर ओवरलोडिंग (Constructor Overloading)" कहते हैं, जहाँ अलग-अलग पैरामीटर वाले कई कंस्ट्रक्टर हो सकते हैं।',
      },
    ],
    mcqs: [
      {
        id: 'q12-cons-1',
        question: 'डिस्ट्रक्टर के नाम के आगे कौन सा प्रतीक लगाया जाता है?',
        options: ['#', '&', '~', '*'],
        correctIndex: 2,
        explanationHindi: 'डिस्ट्रक्टर के नाम के आगे टिल्ड (~) लगाया जाता है, जैसे ~Student()।',
      },
      {
        id: 'q12-inh-1',
        question: 'जब एक डिराइव्ड क्लास दो या दो से अधिक बेस क्लासों से गुण लेती है, तो इसे क्या कहते हैं?',
        options: ['Single Inheritance', 'Multiple Inheritance', 'Multilevel Inheritance', 'Hierarchical Inheritance'],
        correctIndex: 1,
        explanationHindi: 'एक से अधिक बेस क्लासों से इनहेरिट होने वाली संरचना को Multiple Inheritance कहते हैं।',
      },
    ],
    shortQuestions: [
      {
        question: 'कंस्ट्रक्टर और साधारण मेंबर फ़ंक्शन में दो मुख्य अंतर लिखिए।',
        marks: 2,
        answerHindi: '1. कंस्ट्रक्टर का नाम क्लास के नाम के समान होता है, जबकि मेंबर फ़ंक्शन का कोई भी वैध नाम हो सकता है। 2. कंस्ट्रक्टर ऑब्जेक्ट बनते ही स्वतः कॉल होता है और इसका कोई रिटर्न टाइप नहीं होता।',
      },
    ],
    practicalExercise: 'एक C++ प्रोग्राम लिखें जिसमें Rectangle क्लास में Default और Parameterized दोनों कंस्ट्रक्टर हों।',
  },
  {
    id: 'c12-unit2-stack-queue',
    classGrade: '12',
    unitId: 'c12-u2',
    unitNumber: 2,
    chapterNumber: '2.2',
    moduleTitle: 'UNIT-2: Data Structures (16 Marks)',
    title: 'Stack (PUSH, POP, Infix to Postfix) and Queue Operations',
    titleHindi: '2.2 स्टैक (PUSH/POP, इनफिक्स से पोस्टफिक्स) एवं क्यू (Queue) संचालन',
    isOfficialSyllabus: true,
    estimatedMins: 35,
    learningObjectives: [
      'स्टैक (Stack) का सिद्धांत: LIFO (Last In First Out)',
      'स्टैक के प्राथमिक संचालन: PUSH (तत्व जोड़ना) और POP (तत्व निकालना)',
      'Overflow (स्टैक भरा होना) और Underflow (स्टैक खाली होना) की स्थितियाँ',
      'एक्सप्रेशन रूपांतरण: Infix से Postfix संकेतन (Notation) में बदलना',
      'क्यू (Queue) का सिद्धांत: FIFO (First In First Out), Front और Rear',
      'सर्कुलर क्यू (Circular Queue) की आवश्यकता और संचालन',
    ],
    introHindi: `डेटा स्ट्रक्चर्स बोर्ड परीक्षा का 16 अंकों का अत्यंत महत्वपूर्ण हिस्सा है। स्टैक और क्यू दो प्रमुख लीनियर डेटा स्ट्रक्चर्स हैं जिनका उपयोग ब्राउज़र के बैक बटन से लेकर प्रिंटर के कतार प्रबंधन तक हर जगह होता है।`,
    explanationHindi: `### 1. स्टैक (Stack) - LIFO (Last In First Out):
जो तत्व सबसे अंत में डाला जाता है, वह सबसे पहले बाहर निकलता है।
- **PUSH:** स्टैक के शीर्ष (TOP) पर नया तत्व जोड़ना। यदि स्टैक भरा हो तो **Overflow** स्थिति होती है।
- **POP:** स्टैक के शीर्ष (TOP) से तत्व हटाना। यदि स्टैक खाली हो तो **Underflow** स्थिति होती है।
- **TOP:** वह चर जो स्टैक के सबसे ऊपरी तत्व का इंडेक्स रखता है।

### 2. इनफिक्स से पोस्टफिक्स (Infix to Postfix):
- *Infix:* ऑपरेटर बीच में (उदा. \`A + B\`)
- *Postfix:* ऑपरेटर बाद में (उदा. \`A B +\`)
- *नियम:* कोष्ठक और ऑपरेटर वरीयता (^ > * / > + -) के अनुसार स्टैक का प्रयोग कर रूपांतरण किया जाता है।

### 3. क्यू (Queue) - FIFO (First In First Out):
जो पहले आएगा, वह पहले सेवा पाएगा।
- **Rear (पिछला सिरा):** जहाँ से नया तत्व जुड़ता है (Enqueue)।
- **Front (अगला सिरा):** जहाँ से पुराना तत्व हटता है (Dequeue)।
- **Circular Queue:** सामान्य क्यू में खाली जगह का सदुपयोग करने के लिए अंतिम स्थान को पहले स्थान से जोड़ दिया जाता है।`,
    technicalTerms: [
      {
        term: 'LIFO (Last In First Out)',
        hindiMeaning: 'अंतिम आया, पहले पाया',
        explanation: 'स्टैक का कार्य सिद्धांत जहाँ सबसे बाद में प्रविष्ट तत्व सबसे पहले निकाला जाता है।',
      },
      {
        term: 'FIFO (First In First Out)',
        hindiMeaning: 'पहले आया, पहले पाया',
        explanation: 'क्यू (कतार) का कार्य सिद्धांत जहाँ कतार में सबसे आगे खड़ा तत्व पहले हटाया जाता है।',
      },
    ],
    realLifeExample: {
      title: 'दैनिक जीवन से उदाहरण: शादी की प्लेट्स (Stack) बनाम टिकट की लाइन (Queue)',
      scenario: 'वास्तविक जीवन की तुलना:',
      analogy: 'विवाह समारोह में सजाई गई प्लेटों का ढेर स्टैक (Stack) है - वेटर सबसे ऊपर रखी प्लेट पहले उठाता है (LIFO)। पटना रेलवे स्टेशन पर टिकट काउंटर की लाइन क्यू (Queue) है - जो यात्री पहले लाइन में लगा, उसे टिकट पहले मिलता है (FIFO)।',
      takeaway: 'कंप्यूटर सिस्टम कार्य प्राथमिकता के आधार पर स्टैक या क्यू का चयन करता है।',
    },
    practicalDemo: {
      title: 'एरे द्वारा स्टैक का PUSH और POP संचालन (C++)',
      language: 'cpp',
      code: `#include <iostream.h>
int stack[5], top = -1;

void push(int val) {
    if(top == 4) cout << "Stack Overflow!" << endl;
    else stack[++top] = val;
}

void pop() {
    if(top == -1) cout << "Stack Underflow!" << endl;
    else cout << "हटाया गया तत्व: " << stack[top--] << endl;
}

int main() {
    push(10);
    push(20);
    pop(); // 20 बाहर आएगा (LIFO)
    return 0;
}`,
      explanation: 'यह कोड LIFO सिद्धांत पर आधारित PUSH और POP ऑपरेशंस को प्रदर्शित करता है।',
    },
    importantPoints: [
      'खाली स्टैक में TOP का मान प्रायः -1 होता है।',
      'Queue में इंसर्शन REAR से और डिलीशन FRONT से होता है।',
      'Infix (A + B) का Postfix रूप AB+ होता है।',
    ],
    faqs: [
      {
        question: 'Underflow की स्थिति कब उत्पन्न होती है?',
        answer: 'जब स्टैक या क्यू में कोई तत्व नहीं होता (खाली होता है) और हम उसमें से तत्व निकालने (POP) का प्रयास करते हैं।',
      },
    ],
    mcqs: [
      {
        id: 'q12-ds-stk-1',
        question: 'स्टैक में तत्व किस सिरे से जोड़ा और हटाया जाता है?',
        options: ['Front', 'Rear', 'Top', 'Bottom'],
        correctIndex: 2,
        explanationHindi: 'स्टैक में PUSH और POP दोनों केवल एक ही सिरे Top से होते हैं।',
      },
      {
        id: 'q12-ds-stk-2',
        question: 'एक्सप्रेशन A + B * C का पोस्टफिक्स (Postfix) रूप क्या होगा?',
        options: ['ABC*+', 'AB+C*', '+A*BC', 'A+BC*'],
        correctIndex: 0,
        explanationHindi: 'गुणा (*) की प्राथमिकता जोड़ (+) से अधिक होती है, अतः पहले B*C -> BC* होगा, फिर A जोड़कर ABC*+ बनेगा।',
      },
    ],
    shortQuestions: [
      {
        question: 'Stack Overflow और Stack Underflow में क्या अंतर है?',
        marks: 2,
        answerHindi: 'Overflow तब होता है जब भरा हुआ स्टैक होने पर भी नया तत्व PUSH करने का प्रयास किया जाए। Underflow तब होता है जब खाली स्टैक में से तत्व POP करने का प्रयास किया जाए।',
      },
    ],
    practicalExercise: 'हाथ से हल करें: इनफिक्स एक्सप्रेशन (A + B) * (C - D) को पोस्टफिक्स में रूपांतरित कीजिए।',
  },

];
