import { BoardExamPaper } from '../types';

export const bsebExamPapers: BoardExamPaper[] = [
  {
    id: 'bseb-2024-pyq-12',
    title: 'BSEB Class 12 Computer Science (2024 Official Board Paper)',
    classGrade: '12',
    session: '2023-2024',
    type: 'pyq',
    officialSource: 'बिहार विद्यालय परीक्षा समिति, पटना (आधिकारिक बोर्ड परीक्षा 2024 प्रश्न पत्र)',
    totalMarks: 70,
    durationMins: 195, // 3 hours 15 mins
    markingSchemeTips: [
      'खंड-अ (Section A) में कुल 50% वस्तुनिष्ठ (Objective) प्रश्न OMR शीट पर हल करने होते हैं।',
      'खंड-ब (Section B) में लघु उत्तरीय प्रश्न (2 अंक) होते हैं। परिभाषा के साथ 1 उपयुक्त उदाहरण अवश्य दें।',
      'दीर्घ उत्तरीय प्रश्नों (5 अंक) में C++ प्रोग्राम का पूरा सिंटैक्स और जहाँ संभव हो वहाँ ब्लॉक डायग्राम बनाएँ।',
    ],
    objectiveQuestions: [
      {
        id: 'pyq24-1',
        question: 'C++ में एक क्लास के डेटा सदस्यों (Data Members) को बाहरी उपयोग से सुरक्षित रखने के लिए किस Access Specifier का प्रयोग किया जाता है?',
        options: ['public', 'private', 'protected', 'global'],
        correctIndex: 1,
        explanationHindi: 'private कीवर्ड क्लास के अंदर डेटा को कैप्सूलेट (सुरक्षित) करता है, जिससे बाहरी फ़ंक्शन उसे सीधे नहीं बदल सकते।',
        isPYQ: true,
        bsebYear: 'BSEB 2024',
      },
      {
        id: 'pyq24-2',
        question: 'RDBMS में टेबल के संबंध (Relation) में डुप्लिकेट पंक्तियों को रोकने के लिए किस कुंजी (Key) का उपयोग होता है?',
        options: ['Candidate Key', 'Primary Key', 'Foreign Key', 'Super Key'],
        correctIndex: 1,
        explanationHindi: 'Primary Key प्रत्येक रिकॉर्ड को विशिष्ट पहचान देती है और कभी डुप्लिकेट या NULL नहीं हो सकती।',
        isPYQ: true,
        bsebYear: 'BSEB 2024',
      },
      {
        id: 'pyq24-3',
        question: 'कंसोल इनपुट के लिए C++ में cin के साथ किस ऑपरेटर का उपयोग किया जाता है?',
        options: ['<<', '>>', '::', '->'],
        correctIndex: 1,
        explanationHindi: 'cin के साथ >> (Extraction Operator) और cout के साथ << (Insertion Operator) का प्रयोग होता है।',
        isPYQ: true,
        bsebYear: 'BSEB 2024',
      },
      {
        id: 'pyq24-4',
        question: 'Star Topology में सभी वर्कस्टेशन किस मुख्य उपकरण से जुड़े होते हैं?',
        options: ['Router', 'Hub या Switch', 'Gateway', 'Modem'],
        correctIndex: 1,
        explanationHindi: 'Star टोपोलॉजी में केंद्र में एक Hub या Switch होता है जिससे सभी कंप्यूटर तारे की तरह जुड़े होते हैं।',
        isPYQ: true,
        bsebYear: 'BSEB 2024',
      },
      {
        id: 'pyq24-5',
        question: 'C++ में फ़ाइल हैंडलिंग के लिए किस हेडर फ़ाइल को शामिल करना आवश्यक है?',
        options: ['<iostream>', '<fstream>', '<iomanip>', '<math.h>'],
        correctIndex: 1,
        explanationHindi: 'फ़ाइलों में पढ़ने (ifstream) और लिखने (ofstream) के लिए <fstream> हेडर फ़ाइल आवश्यक है।',
        isPYQ: true,
        bsebYear: 'BSEB 2024',
      },
    ],
    shortQuestions: [
      {
        question: 'Call by Value और Call by Reference में अंतर स्पष्ट करें।',
        marks: 2,
        answerHindi: 'Call by Value में फ़ंक्शन को चर की प्रतिलिपि (Copy) भेजी जाती है, जिससे फ़ंक्शन के अंदर बदलाव करने पर मुख्य चर में कोई परिवर्तन नहीं होता। जबकि Call by Reference में चर का पता (Address / &) भेजा जाता है, जिससे फ़ंक्शन में किया गया बदलाव मूल चर में भी परिलक्षित होता है।',
      },
      {
        question: 'DBMS में DDL और DML के दो-दो कमांड्स के नाम लिखें।',
        marks: 2,
        answerHindi: '1. DDL (Data Definition Language) कमांड्स: CREATE TABLE, ALTER TABLE\n2. DML (Data Manipulation Language) कमांड्स: INSERT INTO, SELECT',
      },
      {
        question: 'Transmission Media क्या है? Guided और Unguided मीडिया के एक-एक उदाहरण दें।',
        marks: 2,
        answerHindi: 'डेटा को एक कंप्यूटर से दूसरे कंप्यूटर तक ले जाने वाले माध्यम को Transmission Media कहते हैं। Guided (तार युक्त): ट्विस्टेड पेयर केबल या ऑप्टिकल फाइबर। Unguided (तार रहित): रेडियो तरंगें या वाई-फाई।',
      },
    ],
    longQuestions: [
      {
        question: 'Object Oriented Programming (OOP) की मुख्य विशेषताओं (Encapsulation, Inheritance, Polymorphism) की व्याख्या उदाहरण सहित करें।',
        marks: 5,
        answerHindi: `उत्तर प्रारूप (पूरे 5 अंक के लिए):
1. **Encapsulation (कैप्सूलीकरण):** डेटा और फ़ंक्शन को एक एकल इकाई (Class) में बाँधना। यह डेटा हाइडिंग में मदद करता है।
2. **Inheritance (विरासत):** एक क्लास द्वारा दूसरी क्लास के गुणों को प्राप्त करना। इससे कोड का दोहराव (Reusability) बचता है।
   - उदाहरण: Vehicle (Base Class) -> Car (Derived Class)।
3. **Polymorphism (बहुरूपता):** एक ही नाम का विभिन्न रूपों में कार्य करना, जैसे Function Overloading।`,
        codeSnippet: `class Shape {
public:
    virtual void draw() { cout << "आकृति बनाना" << endl; }
};
class Circle : public Shape {
public:
    void draw() override { cout << "वृत्त (Circle) बनाना" << endl; }
};`,
      },
      {
        question: 'SQL के विभिन्न Aggregate Functions (COUNT, SUM, AVG, MAX, MIN) का सचित्र और व्यावहारिक उदाहरण सहित वर्णन करें।',
        marks: 5,
        answerHindi: `Aggregate Functions कई पंक्तियों (Rows) पर गणना करके एक एकल मान लौटाते हैं:
1. **COUNT(*):** तालिका में कुल पंक्तियों की संख्या गिनता है। (उदा: SELECT COUNT(*) FROM STUDENT;)
2. **SUM(कॉलम):** दिए गए संख्यात्मक कॉलम का कुल जोड़ निकालता है। (उदा: SELECT SUM(Marks) FROM STUDENT;)
3. **AVG(कॉलम):** औसत मान निकालता है। (उदा: SELECT AVG(Marks) FROM STUDENT;)
4. **MAX(कॉलम):** सबसे बड़ा मान देता है।
5. **MIN(कॉलम):** सबसे छोटा मान देता है।`,
      },
    ],
  },

  {
    id: 'bseb-2025-model-paper',
    title: 'BSEB Official Model Paper (2025 New Pattern)',
    classGrade: '12',
    session: '2024-2025',
    type: 'model_paper',
    officialSource: 'बिहार विद्यालय परीक्षा समिति, पटना (वार्षिक परीक्षा मॉडल प्रश्न पत्र 2025)',
    totalMarks: 70,
    durationMins: 195,
    markingSchemeTips: [
      'BSEB मॉडल सेट का अभ्यास करने से 70% से अधिक प्रश्न सीधे बोर्ड परीक्षा में मिलते-जुलते आते हैं।',
      'OMR शीट भरते समय नीले या काले बॉल पेन का ही प्रयोग करें।',
    ],
    objectiveQuestions: [
      {
        id: 'mod25-1',
        question: 'SQL में टेबल की संरचना (Schema) देखने या बदलने के लिए किस प्रकार के कमांड का उपयोग होता है?',
        options: ['DML', 'DDL', 'DCL', 'TCL'],
        correctIndex: 1,
        explanationHindi: 'DDL (Data Definition Language) तालिका की संरचना बनाने या बदलने के लिए प्रयुक्त होता है।',
        isPYQ: false,
      },
      {
        id: 'mod25-2',
        question: 'C++ में डिफ़ॉल्ट रूप से क्लास के सभी सदस्य (Members) क्या होते हैं?',
        options: ['public', 'private', 'protected', 'global'],
        correctIndex: 1,
        explanationHindi: 'C++ क्लास में डिफ़ॉल्ट एक्सेस स्पेसिफायर private होता है, जबकि संरचना (struct) में डिफ़ॉल्ट public होता है।',
      },
      {
        id: 'mod25-3',
        question: 'LAN में दो कंप्यूटरों को जोड़ने के लिए सबसे अधिक किस केबल का उपयोग होता है?',
        options: ['Coaxial Cable', 'Twisted Pair Cable (CAT 6)', 'Optical Fiber', 'Power Cable'],
        correctIndex: 1,
        explanationHindi: 'कंप्यूटर लैब में ट्विस्टेड पेयर केबल (RJ45 कनेक्टर के साथ) सबसे सस्ती और लोकप्रिय होती है।',
      },
      {
        id: 'mod25-4',
        question: 'IPv4 पते (IP Address) की लंबाई कितने बिट्स की होती है?',
        options: ['16 बिट्स', '32 बिट्स', '64 बिट्स', '128 बिट्स'],
        correctIndex: 1,
        explanationHindi: 'IPv4 पता 32 बिट्स (4 बाइट्स) का होता है, जबकि IPv6 पता 128 बिट्स का होता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'डेटाबेस में Normalization का क्या उद्देश्य है?',
        marks: 2,
        answerHindi: 'Normalization का मुख्य उद्देश्य डेटाबेस से डेटा के अनावश्यक दोहराव (Redundancy) को कम करना और डेटा की विश्वसनीयता व अखंडता (Data Integrity) को सुनिश्चित करना है।',
      },
      {
        question: 'कंस्ट्रक्टर (Constructor) और साधारण सदस्य फ़ंक्शन में अंतर बताइए।',
        marks: 2,
        answerHindi: 'कंस्ट्रक्टर का नाम क्लास के नाम जैसा होता है और इसका कोई रिटर्न टाइप नहीं होता तथा यह ऑब्जेक्ट बनते ही स्वतः कॉल हो जाता है। जबकि साधारण फ़ंक्शन का नाम कुछ भी हो सकता है, इसका रिटर्न टाइप होता है और इसे स्पष्ट रूप से कॉल करना पड़ता है।',
      },
    ],
    longQuestions: [
      {
        question: 'Computer Networks में OSI Model की सातों लेयर्स (Seven Layers) का सचित्र और क्रमवार वर्णन कीजिए।',
        marks: 5,
        answerHindi: `OSI (Open Systems Interconnection) मॉडल की 7 लेयर्स (नीचे से ऊपर):
1. **Physical Layer:** बिट्स (0 और 1) का भौतिक तारों या तरंगों से संचरण।
2. **Data Link Layer:** फ्रेम्स का निर्माण और एरर चेकिंग (MAC Address)।
3. **Network Layer:** पैकेट राउटिंग और IP Address हैंडलिंग (Router का कार्य)।
4. **Transport Layer:** एंड-टू-एंड संचार और विश्वसनीयता (TCP/UDP)।
5. **Session Layer:** दो सिस्टम्स के बीच सेशन शुरू, बनाए रखना और बंद करना।
6. **Presentation Layer:** डेटा एन्क्रिप्शन, डिक्रिप्शन और कम्प्रेशन।
7. **Application Layer:** उपयोगकर्ता के साथ इंटरफ़ेस (HTTP, FTP, DNS)।`,
      },
    ],
  },

  {
    id: 'ai-practice-target-2026',
    title: 'AI Smart Target Practice Paper (2026 Board Focus)',
    classGrade: '12',
    session: '2025-2026',
    type: 'ai_practice',
    officialSource: 'AI-Generated Practice Set (बिहार बोर्ड के नवीनतम ब्लू-प्रिंट और परीक्षा प्रवृत्ति पर आधारित उच्च-संभावित अभ्यास प्रश्न)',
    totalMarks: 70,
    durationMins: 180,
    markingSchemeTips: [
      'सूचना: यह प्रश्न पत्र कृत्रिम बुद्धिमत्ता (AI) द्वारा बिहार बोर्ड के पिछले 10 वर्षों के प्रश्नों के गहन विश्लेषण पर तैयार किया गया उच्च-संभावित अभ्यास सेट है।',
      'प्रश्नों को वास्तविक परीक्षा समय (3 घंटे) में हल करने का अभ्यास करें।',
    ],
    objectiveQuestions: [
      {
        id: 'ai-1',
        question: 'C++ में एक ऑपरेटर को उसके मूल अर्थ के अलावा नया अर्थ देने की प्रक्रिया को क्या कहते हैं?',
        options: ['Function Overloading', 'Operator Overloading', 'Inheritance', 'Inline Function'],
        correctIndex: 1,
        explanationHindi: 'जब किसी मौजूदा ऑपरेटर (जैसे +) को उपयोगकर्ता-परिभाषित क्लास के साथ नया कार्य सौंपा जाता है, तो उसे Operator Overloading कहते हैं।',
      },
      {
        id: 'ai-2',
        question: 'SQL में किसी टेबल से किसी कॉलम को हटाने या नया कॉलम जोड़ने के लिए किस कमांड का प्रयोग होता है?',
        options: ['MODIFY TABLE', 'UPDATE TABLE', 'ALTER TABLE', 'CHANGE TABLE'],
        correctIndex: 2,
        explanationHindi: 'ALTER TABLE कमांड एक DDL कमांड है जिससे मौजूदा तालिका की संरचना बदली जा सकती है।',
      },
      {
        id: 'ai-3',
        question: 'Cloud Computing में IaaS का पूर्ण रूप क्या है?',
        options: ['Internet as a Service', 'Infrastructure as a Service', 'Information as a Service', 'Integrated App System'],
        correctIndex: 1,
        explanationHindi: 'IaaS का पूरा नाम Infrastructure as a Service होता है।',
      },
    ],
    shortQuestions: [
      {
        question: 'Artificial Intelligence (AI) और Machine Learning (ML) में मुख्य अंतर स्पष्ट करें।',
        marks: 2,
        answerHindi: 'AI एक व्यापक अवधारणा है जिसमें मशीनें मानव जैसी बुद्धिमत्ता का प्रदर्शन करती हैं। ML, AI का ही एक भाग (Subset) है जिसमें कंप्यूटर पुराने डेटा से सीखकर बिना अलग से कोड लिखे स्वयं भविष्यवाणी या निर्णय करता है।',
      },
    ],
    longQuestions: [
      {
        question: 'Cyber Security से क्या आशय है? सामान्य साइबर हमलों (Phishing, Malware, DDoS) से बचने के उपाय लिखिए।',
        marks: 5,
        answerHindi: `साइबर सुरक्षा इंटरनेट और कंप्यूटर नेटवर्क पर हमारे डेटा, सिस्टम और प्राइवेसी को अनाधिकृत पहुँच से बचाने की प्रक्रिया है।
बचाव के मुख्य उपाय:
1. मजबूत और अलग-अलग पासवर्ड का उपयोग करना।
2. अनजान लिंक्स या लॉटरी वाले ईमेल पर क्लिक न करना (Anti-Phishing)।
3. नियमित रूप से एंटीवायरस सॉफ्टवेयर अपडेट रखना।
4. टू-फैक्टर ऑथेंटिकेशन (2FA) का उपयोग करना।`,
      },
    ],
  },
];
