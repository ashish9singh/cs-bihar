import { CppProgramPreset } from '../types';

export const cppProgramPresets: CppProgramPreset[] = [
  {
    id: 'prog-1',
    title: 'Hello World',
    titleHindi: '1. पहला प्रोग्राम: हैलो वर्ल्ड',
    category: 'बुनियादी (Basics)',
    defaultInput: '',
    code: `#include <iostream>
using namespace std;

int main() {
    // स्क्रीन पर संदेश प्रदर्शित करना
    cout << "नमस्ते बिहार! Welcome to C++" << endl;
    cout << "सीखिए Computer Science अपनी भाषा में!" << endl;
    return 0;
}`,
    expectedOutput: `नमस्ते बिहार! Welcome to C++
सीखिए Computer Science अपनी भाषा में!`,
    descriptionHindi: 'यह C++ का सबसे पहला और बुनियादी प्रोग्राम है। इसमें cout और endl का उपयोग करके स्क्रीन पर टेक्स्ट प्रिंट किया जाता है।',
    lineByLine: [
      { line: '#include <iostream>', hindi: 'इनपुट और आउटपुट के लिए मानक iostream लाइब्रेरी को जोड़ता है।' },
      { line: 'using namespace std;', hindi: 'मानक C++ लाइब्रेरी के शब्दों (जैसे cout, endl) को सीधे प्रयोग करने की अनुमति देता है।' },
      { line: 'int main()', hindi: 'मुख्य फ़ंक्शन जहाँ से प्रोग्राम का निष्पादन शुरू होता है।' },
      { line: 'cout << "..." << endl;', hindi: 'स्क्रीन पर टेक्स्ट प्रिंट करता है और endl नई लाइन बनाता है।' },
      { line: 'return 0;', hindi: 'ऑपरेटिंग सिस्टम को प्रोग्राम की सफल समाप्ति का संकेत देता है।' },
    ],
    commonMistakes: [
      { mistake: 'सेमीकोलन (;) भूल जाना', solution: 'हर निर्देश (statement) के बाद सेमीकोलन अवश्य लगाएं।' },
      { mistake: 'cout के साथ >> लगाना', solution: 'cout के साथ हमेशा << (Insertion) और cin के साथ >> (Extraction) लगाएं।' },
    ],
  },

  {
    id: 'prog-2',
    title: 'Addition of Two Numbers',
    titleHindi: '2. दो संख्याओं का जोड़ (Addition)',
    category: 'बुनियादी (Basics)',
    defaultInput: '15 25',
    code: `#include <iostream>
using namespace std;

int main() {
    int a, b, sum;
    
    // मान लीजिए इनपुट 15 और 25 है
    cout << "पहली संख्या दर्ज करें: ";
    cin >> a;
    
    cout << "दूसरी संख्या दर्ज करें: ";
    cin >> b;
    
    sum = a + b;
    
    cout << "कुल जोड़ (Sum) = " << sum << endl;
    return 0;
}`,
    expectedOutput: `पहली संख्या दर्ज करें: 15
दूसरी संख्या दर्ज करें: 25
कुल जोड़ (Sum) = 40`,
    descriptionHindi: 'इस प्रोग्राम में दो पूर्णांक चरों (Variables) में मान लेकर उनका योगफल (Sum) ज्ञात किया जाता है।',
    lineByLine: [
      { line: 'int a, b, sum;', hindi: 'मेमोरी में 3 पूर्णांक (Integer) प्रकार के कंटेनर बनाता है।' },
      { line: 'cin >> a;', hindi: 'कीबोर्ड से पहला अंक इनपुट लेकर चर a में सुरक्षित करता है।' },
      { line: 'sum = a + b;', hindi: 'a और b के मानों को जोड़कर sum में संग्रहीत करता है।' },
    ],
    commonMistakes: [
      { mistake: 'चर (variable) को घोषित (declare) न करना', solution: 'प्रयोग करने से पहले int, float आदि लिखकर चर घोषित करें।' },
    ],
  },

  {
    id: 'prog-3',
    title: 'Even or Odd',
    titleHindi: '3. सम या विषम संख्या (Even or Odd)',
    category: 'निर्णय नियंत्रण (Conditionals)',
    defaultInput: '14',
    code: `#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "एक संख्या दर्ज करें: ";
    cin >> num;
    
    // मॉड्यूलो ऑपरेटर (%) 2 से भाग देने पर शेषफल बताता है
    if (num % 2 == 0) {
        cout << num << " एक सम संख्या (Even Number) है।" << endl;
    } else {
        cout << num << " एक विषम संख्या (Odd Number) है।" << endl;
    }
    
    return 0;
}`,
    expectedOutput: `एक संख्या दर्ज करें: 14
14 एक सम संख्या (Even Number) है।`,
    descriptionHindi: 'if-else का उपयोग करके यह जाँचना कि संख्या 2 से पूरी तरह विभाजित होती है या नहीं।',
    lineByLine: [
      { line: 'if (num % 2 == 0)', hindi: 'यदि num को 2 से भाग देने पर शेषफल 0 बचता है, तो संख्या सम है।' },
      { line: 'else', hindi: 'अन्यथा (यदि शेषफल 1 है), तो संख्या विषम है।' },
    ],
    commonMistakes: [
      { mistake: 'तुलना के लिए = लिखना', solution: 'तुलना (Comparison) के लिए हमेशा == ऑपरेटर का प्रयोग करें, = मान असाइन करने के लिए होता है।' },
    ],
  },

  {
    id: 'prog-4',
    title: 'Largest of Three Numbers',
    titleHindi: '4. तीन संख्याओं में सबसे बड़ी संख्या',
    category: 'निर्णय नियंत्रण (Conditionals)',
    defaultInput: '45 92 68',
    code: `#include <iostream>
using namespace std;

int main() {
    int n1, n2, n3;
    cout << "तीन संख्याएँ दर्ज करें: ";
    cin >> n1 >> n2 >> n3;
    
    if (n1 >= n2 && n1 >= n3) {
        cout << "सबसे बड़ी संख्या है: " << n1 << endl;
    } else if (n2 >= n1 && n2 >= n3) {
        cout << "सबसे बड़ी संख्या है: " << n2 << endl;
    } else {
        cout << "सबसे बड़ी संख्या है: " << n3 << endl;
    }
    
    return 0;
}`,
    expectedOutput: `तीन संख्याएँ दर्ज करें: 45 92 68
सबसे बड़ी संख्या है: 92`,
    descriptionHindi: 'तार्किक ऑपरेटर && (Logical AND) और if-else ladder का प्रयोग करके तीन में से सबसे बड़ा मान ज्ञात करना।',
    lineByLine: [
      { line: 'cin >> n1 >> n2 >> n3;', hindi: 'एक साथ तीन इनपुट लेना।' },
      { line: 'n1 >= n2 && n1 >= n3', hindi: 'जांचता है कि n1 दोनों से बड़ा या बराबर है या नहीं।' },
    ],
    commonMistakes: [
      { mistake: 'n1 > n2 > n3 लिखना', solution: 'C++ में एक साथ ऐसी तुलना नहीं होती, && ऑपरेटर का उपयोग करें।' },
    ],
  },

  {
    id: 'prog-5',
    title: 'Multiplication Table',
    titleHindi: '5. किसी भी संख्या का पहाड़ा (Multiplication Table)',
    category: 'लूप्स (Loops)',
    defaultInput: '7',
    code: `#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "जिस संख्या का पहाड़ा चाहिए, दर्ज करें: ";
    cin >> n;
    
    cout << "--- " << n << " का पहाड़ा ---" << endl;
    for (int i = 1; i <= 10; i++) {
        cout << n << " x " << i << " = " << (n * i) << endl;
    }
    
    return 0;
}`,
    expectedOutput: `जिस संख्या का पहाड़ा चाहिए, दर्ज करें: 7
--- 7 का पहाड़ा ---
7 x 1 = 7
7 x 2 = 14
7 x 3 = 21
7 x 4 = 28
7 x 5 = 35
7 x 6 = 42
7 x 7 = 49
7 x 8 = 56
7 x 9 = 63
7 x 10 = 70`,
    descriptionHindi: 'for loop का उपयोग करके 1 से 10 तक किसी भी संख्या का गुणात्मक पहाड़ा बनाना।',
    lineByLine: [
      { line: 'for (int i = 1; i <= 10; i++)', hindi: 'लूप i=1 से शुरू होकर i=10 तक 1-1 करके आगे बढ़ता है।' },
      { line: 'cout << n * i;', hindi: 'हर बार n और i का गुणनफल प्रिंट करता है।' },
    ],
    commonMistakes: [
      { mistake: 'for loop के बाद सेमीकोलन लगा देना: for(...);', solution: 'for(...) के बाद कभी सेमीकोलन न लगाएं अन्यथा लूप की बॉडी नहीं चलेगी!' },
    ],
  },

  {
    id: 'prog-6',
    title: 'Factorial',
    titleHindi: '6. फैक्टोरियल ज्ञात करना (Factorial of a Number)',
    category: 'लूप्स (Loops)',
    defaultInput: '5',
    code: `#include <iostream>
using namespace std;

int main() {
    int n;
    long long fact = 1;
    
    cout << "एक धनात्मक संख्या दर्ज करें: ";
    cin >> n;
    
    for (int i = 1; i <= n; i++) {
        fact = fact * i;
    }
    
    cout << n << " का फैक्टोरियल (" << n << "!) = " << fact << endl;
    return 0;
}`,
    expectedOutput: `एक धनात्मक संख्या दर्ज करें: 5
5 का फैक्टोरियल (5!) = 120`,
    descriptionHindi: 'गणित में 5! = 5 x 4 x 3 x 2 x 1 = 120 होता है। C++ में गुणन संचय का उपयोग करके इसे हल किया जाता है।',
    lineByLine: [
      { line: 'long long fact = 1;', hindi: 'फैक्टोरियल बड़ा हो सकता है इसलिए 1 से शुरुआत की जाती है (0 से नहीं)।' },
      { line: 'fact = fact * i;', hindi: 'प्रत्येक चरण में पिछली संख्या से गुणा किया जाता है।' },
    ],
    commonMistakes: [
      { mistake: 'fact = 0 से शुरुआत करना', solution: 'गुणा में 0 से शुरू करने पर पूरा उत्तर हमेशा 0 ही आएगा, अतः 1 से शुरू करें।' },
    ],
  },

  {
    id: 'prog-7',
    title: 'Fibonacci Series',
    titleHindi: '7. फिबोनाची श्रृंखला (Fibonacci Series)',
    category: 'लूप्स (Loops)',
    defaultInput: '8',
    code: `#include <iostream>
using namespace std;

int main() {
    int n = 8;
    int t1 = 0, t2 = 1, nextTerm;
    
    cout << "फिबोनाची श्रृंखला के पहले " << n << " पद: " << endl;
    for (int i = 1; i <= n; i++) {
        cout << t1 << " ";
        nextTerm = t1 + t2;
        t1 = t2;
        t2 = nextTerm;
    }
    cout << endl;
    return 0;
}`,
    expectedOutput: `फिबोनाची श्रृंखला के पहले 8 पद: 
0 1 1 2 3 5 8 13`,
    descriptionHindi: 'फिबोनाची श्रृंखला में अगला पद पिछले दो पदों का योग होता है (0 + 1 = 1, 1 + 1 = 2, 1 + 2 = 3 आदि)। BSEB बोर्ड का अत्यंत लोकप्रिय प्रश्न!',
    lineByLine: [
      { line: 'nextTerm = t1 + t2;', hindi: 'अगला पद = पिछले दो पदों का जोड़।' },
      { line: 't1 = t2; t2 = nextTerm;', hindi: 'पदों को एक कदम आगे खिसकाना।' },
    ],
    commonMistakes: [
      { mistake: 't1 और t2 का क्रम गलत बदलना', solution: 'पहले t1 को t2 का मान दें, फिर t2 को nextTerm दें।' },
    ],
  },

  {
    id: 'prog-8',
    title: 'Prime Number',
    titleHindi: '8. अभाज्य संख्या की जाँच (Prime Number Check)',
    category: 'लूप्स और लॉजिक',
    defaultInput: '17',
    code: `#include <iostream>
using namespace std;

int main() {
    int n = 17;
    bool isPrime = true;
    
    if (n <= 1) {
        isPrime = false;
    } else {
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                isPrime = false;
                break;
            }
        }
    }
    
    if (isPrime) {
        cout << n << " एक अभाज्य (Prime) संख्या है।" << endl;
    } else {
        cout << n << " एक भाज्य (Composite) संख्या है।" << endl;
    }
    
    return 0;
}`,
    expectedOutput: `17 एक अभाज्य (Prime) संख्या है।`,
    descriptionHindi: 'अभाज्य संख्या वह होती है जो केवल 1 और स्वयं से विभाजित होती है (जैसे 2, 3, 5, 7, 11, 13, 17)।',
    lineByLine: [
      { line: 'for (int i = 2; i * i <= n; i++)', hindi: '2 से वर्गमूल n तक भाग देकर जांचना (दक्षता हेतु)।' },
      { line: 'if (n % i == 0) break;', hindi: 'यदि किसी से भी भाग चला गया, तो break करके लूप रोक देना।' },
    ],
    commonMistakes: [
      { mistake: '1 को अभाज्य मान लेना', solution: '1 न तो अभाज्य है और न ही भाज्य संख्या।' },
    ],
  },

  {
    id: 'prog-9',
    title: 'Array Operations',
    titleHindi: '9. एरे ऑपरेशन्स: तत्वों का योग और औसत (Array Operations)',
    category: 'सरणी (Arrays)',
    defaultInput: '5',
    code: `#include <iostream>
using namespace std;

int main() {
    // 5 तत्वों का एरे
    int marks[5] = {85, 92, 78, 64, 88};
    int sum = 0;
    
    cout << "छात्र के 5 विषयों के अंक:" << endl;
    for (int i = 0; i < 5; i++) {
        cout << "विषय " << (i + 1) << ": " << marks[i] << endl;
        sum += marks[i];
    }
    
    float avg = (float)sum / 5;
    cout << "-----------------------" << endl;
    cout << "कुल अंक = " << sum << endl;
    cout << "औसत प्रतिशत = " << avg << "%" << endl;
    
    return 0;
}`,
    expectedOutput: `छात्र के 5 विषयों के अंक:
विषय 1: 85
विषय 2: 92
विषय 3: 78
विषय 4: 64
विषय 5: 88
-----------------------
कुल अंक = 407
औसत प्रतिशत = 81.4%`,
    descriptionHindi: 'एरे (Array) समान डेटा टाइप के कई मानों को एक ही नाम से क्रमवार मेमोरी में रखने का साधन है। इसका इंडेक्स 0 से शुरू होता है।',
    lineByLine: [
      { line: 'int marks[5] = {...};', hindi: '5 पूर्णांक मानों का एक एरे घोषित और प्रारंभ करता है।' },
      { line: 'marks[i]', hindi: 'एरे के i-वें तत्व का मान निकालता है (0 से 4 तक)।' },
    ],
    commonMistakes: [
      { mistake: 'इंडेक्स 1 से 5 तक चलाना', solution: 'C++ में एरे इंडेक्स हमेशा 0 से शुरू होता है (0 से size - 1)।' },
    ],
  },

  {
    id: 'prog-10',
    title: 'Functions',
    titleHindi: '10. फ़ंक्शंस का उपयोग: अधिकतम मान खोजना',
    category: 'फ़ंक्शंस (Functions)',
    defaultInput: '48 76',
    code: `#include <iostream>
using namespace std;

// उपयोगकर्ता-परिभाषित फ़ंक्शन (User Defined Function)
int findMax(int x, int y) {
    if (x > y)
        return x;
    else
        return y;
}

int main() {
    int num1 = 48, num2 = 76;
    
    // फ़ंक्शन को कॉल करना
    int maximum = findMax(num1, num2);
    
    cout << "संख्याएँ: " << num1 << " और " << num2 << endl;
    cout << "अधिकतम मान (Maximum) = " << maximum << endl;
    
    return 0;
}`,
    expectedOutput: `संख्याएँ: 48 और 76
अधिकतम मान (Maximum) = 76`,
    descriptionHindi: 'फ़ंक्शन किसी बड़े प्रोग्राम को छोटे-छोटे पुनः प्रयोज्य (Reusable) टुकड़ों में बाँटने का सबसे अच्छा तरीका है।',
    lineByLine: [
      { line: 'int findMax(int x, int y)', hindi: 'फ़ंक्शन की परिभाषा: यह 2 संख्याएं लेता है और एक संख्या लौटाता है।' },
      { line: 'int maximum = findMax(num1, num2);', hindi: 'मुख्य फ़ंक्शन से findMax को कॉल करना।' },
    ],
    commonMistakes: [
      { mistake: 'फ़ंक्शन का प्रोटोटाइप या रिटर्न टाइप भूलना', solution: 'यदि फ़ंक्शन कोई मान लौटाता है, तो int/float लिखें; नहीं तो void लिखें।' },
    ],
  },
];
